package net.createmod.catnip.config.ui;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;

import javax.annotation.Nullable;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.TriConsumer;
import org.lwjgl.opengl.GL30;

import com.mojang.blaze3d.systems.RenderSystem;
import net.createmod.catnip.gui.AbstractSimiScreen;
import net.createmod.catnip.gui.UIRenderHelper;
import net.createmod.catnip.gui.element.DelegatedStencilElement;
import net.createmod.catnip.gui.element.GuiGameElement;
import net.minecraft.class_1074;
import net.minecraft.class_2246;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_4587;
import net.minecraft.class_766;
import net.createmod.catnip.animation.Force;
import net.createmod.catnip.animation.PhysicalFloat;

public abstract class ConfigScreen extends AbstractSimiScreen {

	public static final List<UnaryOperator<String>> displayNameKeys = List.of(
			modID -> "catnip." + modID + ".display_name",
			modID -> "constants." + modID + ".mod_name",
			modID -> "itemGroup." + modID + ".base",
			modID -> "itemGroup." + modID + "." + modID
	);

	public static final Map<String, String> knownModDisplayNames = Map.ofEntries(
			Map.entry("forge", "Forge"),
			Map.entry("jei", "Just Enough Items"),
			Map.entry("computercraft", "ComputerCraft"),
			Map.entry("catnip", "Catnip"),
			Map.entry("ponder", "Ponder"),
			Map.entry("create", "Create"),
			Map.entry("flywheel", "Flywheel"),
			Map.entry("ae2", "Applied Energistics 2")
	);

	public static final Map<String, TriConsumer<class_437, class_332, Float>> backgrounds = new HashMap<>();
	public static final PhysicalFloat cogSpin = PhysicalFloat.create().withLimit(10f).withDrag(0.3).addForce(new Force.Static(.2f));
	@Nullable public static String modID = null;
	@Nullable protected final class_437 parent;

	public static class_2680 shadowState = class_2246.field_22426.method_9564();
	public static DelegatedStencilElement shadowElement = new DelegatedStencilElement(
			(graphics, x, y, alpha) -> renderCog(graphics),
			(graphics, x, y, alpha) -> graphics.method_25294(-200, -200, 200, 200, 0x60_000000)
	);

	private static final class_766 vanillaPanorama = new class_766(class_442.field_49508);

	public ConfigScreen(@Nullable class_437 parent) {
		this.parent = parent;
	}

	@Override
	public void method_25393() {
		super.method_25393();
		cogSpin.tick();
	}

	@Override
	public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {}

	@Override
	protected void renderWindowBackground(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		if (this.field_22787 != null && this.field_22787.field_1687 != null) {
			//in game
			graphics.method_25294(0, 0, this.field_22789, this.field_22790, 0xb0_282c34);
		} else {
			//in menus
			renderMenuBackground(graphics, partialTicks);
		}

		shadowElement
				.at(field_22789 * 0.5f, field_22790 * 0.5f, 0)
				.render(graphics);

		super.renderWindowBackground(graphics, mouseX, mouseY, partialTicks);

	}

	@Override
	protected void prepareFrame() {
		UIRenderHelper.swapAndBlitColor(field_22787.method_1522(), UIRenderHelper.framebuffer);
		RenderSystem.clear(GL30.GL_STENCIL_BUFFER_BIT | GL30.GL_DEPTH_BUFFER_BIT, class_310.field_1703);
	}

	@Override
	protected void endFrame() {
		UIRenderHelper.swapAndBlitColor(UIRenderHelper.framebuffer, field_22787.method_1522());
	}

	@Override
	protected void renderWindow(class_332 graphics, int mouseX, int mouseY, float partialTicks) {}

	@Override
	public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
		cogSpin.bump(3, -scrollY * 5);

		return super.method_25401(mouseX, mouseY, scrollX, scrollY);
	}

	@Override
	public boolean method_25421() {
		return true;
	}

	/**
	 * This method checks some language keys to see if the mod has declared a display name via lang.
	 * If none of those succeed, it checks a list of manually declared ones for compatibility.
	 */
	public static Optional<String> getModDisplayName(String modID) {
		Optional<String> displayNameFromLang = displayNameKeys
				.stream()
				.map(op -> op.apply(modID))
				.filter(class_1074::method_4663)
				.findFirst()
				.map(class_1074::method_4662);

		if (displayNameFromLang.isPresent())
			return displayNameFromLang;

		return Optional.ofNullable(knownModDisplayNames.get(modID));
	}

	public static String toHumanReadable(String key) {
		String s = key.replaceAll("_", " ");
		s = Arrays.stream(StringUtils.splitByCharacterTypeCamelCase(s)).map(StringUtils::capitalize).collect(Collectors.joining(" "));
		s = StringUtils.normalizeSpace(s);
		return s;
	}

	/**
	 * By default, ConfigScreens will render the Vanilla Panorama as
	 * their background when not opened ingame.
	 * If your mod wants to render something else, please add to the
	 * {@code backgrounds} Map in this Class with your modID as the key.
	 */
	protected void renderMenuBackground(class_332 graphics, float partialTicks) {
		TriConsumer<class_437, class_332, Float> customBackground = backgrounds.get(modID);
		if (customBackground != null) {
			customBackground.accept(this, graphics, partialTicks);
			return;
		}

		vanillaPanorama.method_3317(graphics, this.field_22789, this.field_22790, 1, partialTicks); // TODO - Checkover if the partialticks are correct

		graphics.method_25294(0, 0, this.field_22789, this.field_22790, 0x90_282c34);
	}

	protected static void renderCog(class_332 graphics) {
		float partialTicks = class_310.method_1551().method_60646().method_60637(false);
		class_4587 poseStack = graphics.method_51448();
		poseStack.method_22903();

		poseStack.method_46416(-100, 100, -100);
		poseStack.method_22905(200, 200, 1);
		GuiGameElement.of(shadowState)
			.rotateBlock(22.5, cogSpin.getValue(partialTicks), 22.5)
			.render(graphics);

		poseStack.method_22909();
	}
}
