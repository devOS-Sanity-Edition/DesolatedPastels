package net.createmod.catnip.config.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.annotation.Nullable;

import net.createmod.ponder.enums.PonderGuiTextures;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

import net.createmod.catnip.gui.ScreenOpener;
import net.createmod.catnip.gui.UIRenderHelper;
import net.createmod.catnip.gui.element.DelegatedStencilElement;
import net.createmod.catnip.gui.widget.AbstractSimiWidget;
import net.createmod.catnip.gui.widget.BoxWidget;
import net.createmod.catnip.platform.CatnipServices;
import net.createmod.catnip.lang.FontHelper;
import net.createmod.catnip.lang.FontHelper.Palette;

public class ConfigModListScreen extends ConfigScreen {

	@Nullable ConfigScreenList list;
	@Nullable HintableTextFieldWidget search;
	@Nullable BoxWidget goBack;
	List<ModEntry> allEntries = new ArrayList<>();

	public ConfigModListScreen(@Nullable class_437 parent) {
		super(parent);
	}

	@Override
	protected void method_25426() {
		super.method_25426();

		int listWidth = Math.min(field_22789 - 80, 300);

		list = new ConfigScreenList(field_22787, listWidth, field_22790 - 60, 15, 40);
		list.method_46421(this.field_22789 / 2 - list.method_25368() / 2);
		method_37063(list);

		allEntries = new ArrayList<>();
		CatnipServices.PLATFORM.getLoadedMods().forEach(id -> allEntries.add(new ModEntry(id, this)));
		allEntries.sort((e1, e2) -> {
			int empty = (e2.button.field_22763 ? 1 : 0) - (e1.button.field_22763 ? 1 : 0);
			if (empty != 0)
				return empty;

			return e1.id.compareToIgnoreCase(e2.id);
		});
		list.method_25396().clear();
		list.method_25396().addAll(allEntries);

		goBack = new BoxWidget(field_22789 / 2 - listWidth / 2 - 30, field_22790 / 2 + 65, 20, 20).withPadding(2, 2)
				.withCallback(() -> ScreenOpener.open(parent));
		goBack.showingElement(PonderGuiTextures.ICON_CONFIG_BACK.asStencil()
				.withElementRenderer(BoxWidget.gradientFactory.apply(goBack)));
		goBack.getToolTip()
				.add(class_2561.method_43470("Go Back"));
		method_37063(goBack);

		search = new HintableTextFieldWidget(field_22793, field_22789 / 2 - listWidth / 2, field_22790 - 35, listWidth, 20);
		search.method_1863(this::updateFilter);
		search.setHint("Ctrl + F to Search...");
		search.method_1870(false);
		method_37063(search);
	}

	@Override
	public boolean method_25402(double x, double y, int button) {
		if (search != null && !search.method_25405(x, y))
			search.method_25365(false);

		return super.method_25402(x, y, button);
	}

	@Override
	public boolean method_25404(int keyCode, int scanCode, int modifiers) {
		if (super.method_25404(keyCode, scanCode, modifiers))
			return true;

		if (search != null && class_437.method_25441()) {
			if (keyCode == GLFW.GLFW_KEY_F) {
				this.method_25395(search);
			}
		}

		if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
			ScreenOpener.open(parent);
		}
		return false;
	}

	private void updateFilter(String search) {
		assert list != null;
		assert this.search != null;

		list.method_25396().clear();
		//todo include display names in search
		for (ModEntry modEntry : allEntries) {
			if (modEntry.id.contains(search.toLowerCase(Locale.ROOT))) {
				list.method_25396().add(modEntry);
			}
		}

		list.method_25307(list.method_25341());
		if (!list.method_25396().isEmpty()) {
			this.search.method_1868(UIRenderHelper.COLOR_TEXT.getFirst().getRGB());
		} else {
			this.search.method_1868(AbstractSimiWidget.COLOR_FAIL.getFirst().getRGB());
		}
	}

	public static class ModEntry extends ConfigScreenList.LabeledEntry {

		protected BoxWidget button;
		protected String id;

		public ModEntry(String id, class_437 parent) {
			super(modName(id));
			this.id = id;

			button = new BoxWidget(0, 0, 35, 16)
					.showingElement(PonderGuiTextures.ICON_CONFIG_OPEN.asStencil().at(10, 0));
			button.modifyElement(e -> ((DelegatedStencilElement) e).withElementRenderer(BoxWidget.gradientFactory.apply(button)));

			if (ConfigHelper.hasAnyForgeConfig(id)) {
				button.withCallback(() -> ScreenOpener.open(new BaseConfigScreen(parent, id)));
			} else {
				button.field_22763 = false;
				button.updateGradientFromState();
				button.modifyElement(e -> ((DelegatedStencilElement) e).withElementRenderer(BaseConfigScreen.DISABLED_RENDERER));
				labelTooltip.add(class_2561.method_43470(modName(id)));
				labelTooltip.addAll(FontHelper.cutTextComponent(class_2561.method_43470("This Mod does not have any configs registered or is not using Forge's config system"), Palette.ALL_GRAY));
			}

			listeners.add(button);
		}

		private static String modName(String modID) {
			return getModDisplayName(modID).orElse(toHumanReadable(modID));
		}

		public String getId() {
			return id;
		}

		@Override
		public void tick() {
			super.tick();
			button.tick();
		}

		@Override
		public void method_25343(class_332 graphics, int index, int y, int x, int width, int height, int mouseX, int mouseY, boolean p_230432_9_, float partialTicks) {
			super.method_25343(graphics, index, y, x, width, height, mouseX, mouseY, p_230432_9_, partialTicks);

			button.method_46421(x + width - 108);
			button.method_46419(y + 10);
			button.method_53533(height - 20);
			button.method_25394(graphics, mouseX, mouseY, partialTicks);
		}

		@Override
		protected int getLabelWidth(int totalWidth) {
			return (int) (totalWidth * labelWidthMult) + 30;
		}
	}
}
