package net.createmod.catnip.config.ui;

import org.lwjgl.glfw.GLFW;

import net.createmod.catnip.gui.UIRenderHelper;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_5244;

public class HintableTextFieldWidget extends class_342 {

	protected class_327 font;
	protected String hint;

	public HintableTextFieldWidget(class_327 font, int x, int y, int width, int height) {
		super(font, x, y, width, height, class_5244.field_39003);
		this.font = font;
	}

	public void setHint(String hint) {
		this.hint = hint;
	}

	public void method_53533(int value) {
		this.field_22759 = value;
	}

	@Override
	public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		super.method_48579(graphics, mouseX, mouseY, partialTicks);

		if (hint == null || hint.isEmpty())
			return;

		if (!method_1882().isEmpty())
			return;

		graphics.method_25303(font, hint, method_46426() + 5, this.method_46427() + (this.field_22759 - 8) / 2, UIRenderHelper.COLOR_TEXT.getFirst().scaleAlpha(.75f).getRGB());
	}

	@Override
	public boolean method_25402(double x, double y, int button) {
		if (!method_25405(x, y))
			return false;

		if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT) {
			method_1852("");
			return true;
		} else
			return super.method_25402(x, y, button);
	}

	@Override
	public boolean method_25404(int keyCode, int scanCode, int modifiers) {
		if (class_310.method_1551().field_1690.field_1822.method_1417(keyCode, scanCode)) {
			return true;
		}

		return super.method_25404(keyCode, scanCode, modifiers);
	}
}
