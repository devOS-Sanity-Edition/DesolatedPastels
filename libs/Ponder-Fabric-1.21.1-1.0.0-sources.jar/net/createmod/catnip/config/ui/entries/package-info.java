@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package net.createmod.catnip.config.ui.entries;

import javax.annotation.ParametersAreNonnullByDefault;