package net.createmod.catnip.config.ui.entries;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.annotation.Nonnull;

import net.createmod.ponder.enums.PonderGuiTextures;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3674;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.ModConfigSpec;

import org.lwjgl.glfw.GLFW;
import net.createmod.catnip.config.ui.ConfigAnnotations;
import net.createmod.catnip.config.ui.ConfigHelper;
import net.createmod.catnip.config.ui.ConfigScreen;
import net.createmod.catnip.config.ui.ConfigScreenList;
import net.createmod.catnip.config.ui.SubMenuConfigScreen;
import net.createmod.catnip.gui.element.DelegatedStencilElement;
import net.createmod.catnip.gui.widget.BoxWidget;
import net.createmod.catnip.lang.FontHelper;
import net.createmod.catnip.lang.FontHelper.Palette;
import net.createmod.catnip.data.Pair;

public class ValueEntry<T> extends ConfigScreenList.LabeledEntry {

	protected static final int resetWidth = 28;//including 6px offset on either side

	public static final class_3674 clipboardHelper = new class_3674();

	protected ModConfigSpec.ConfigValue<T> value;
	protected ModConfigSpec.ValueSpec spec;
	protected BoxWidget resetButton;
	protected boolean editable = true;

	public ValueEntry(String label, ModConfigSpec.ConfigValue<T> value, ModConfigSpec.ValueSpec spec) {
		super(label);
		this.value = value;
		this.spec = spec;
		this.path = String.join(".", value.getPath());

		resetButton = new BoxWidget(0, 0, resetWidth - 12, 16)
				.showingElement(PonderGuiTextures.ICON_CONFIG_RESET.asStencil())
				.withCallback(() -> {
					setValue((T) spec.getDefault());
					this.onReset();
				});
		resetButton.modifyElement(e -> ((DelegatedStencilElement) e).withElementRenderer(BoxWidget.gradientFactory.apply(resetButton)));

		listeners.add(resetButton);

		List<String> path = value.getPath();
		labelTooltip.add(class_2561.method_43470(label).method_27692(class_124.field_1068));
		String comment = spec.getComment();
		if (comment == null || comment.isEmpty())
			return;

		List<String> commentLines = new ArrayList<>(Arrays.asList(comment.split("\n")));


		Pair<String, Map<String, String>> metadata = ConfigHelper.readMetadataFromComment(commentLines);
		if (metadata.getFirst() != null) {
			unit = metadata.getFirst();
		}
		if (metadata.getSecond() != null && !metadata.getSecond().isEmpty()) {
			annotations.putAll(metadata.getSecond());
		}
		// add comment to tooltip
		labelTooltip.addAll(commentLines.stream()
				.filter(s -> !s.startsWith("Range"))
				.map(s -> s.equals(".") ? " " : s)
				.map(str -> class_2561.method_43470(str))
				.flatMap(stc -> FontHelper.cutTextComponent(stc, Palette.ALL_GRAY).stream())
				.toList()
		);

		if (annotations.containsKey(ConfigAnnotations.RequiresRelog.TRUE.getName()))
			labelTooltip.addAll(FontHelper.cutTextComponent(class_2561.method_43470("Changing this value will require a _relog_ to take full effect"), Palette.GRAY_AND_GOLD));

		if (annotations.containsKey(ConfigAnnotations.RequiresRestart.CLIENT.getName()))
			labelTooltip.addAll(FontHelper.cutTextComponent(class_2561.method_43470("Changing this value will require a _restart_ to take full effect"), Palette.GRAY_AND_RED));

		labelTooltip.add(class_2561.method_43470(ConfigScreen.modID + ":" + path.get(path.size() - 1)).method_27692(class_124.field_1063));
	}

	@Override
	protected void setEditable(boolean b) {
		editable = b;
		resetButton.field_22763 = editable && !isCurrentValueDefault();
		resetButton.animateGradientFromState();
	}

	@Override
	public void tick() {
		super.tick();
		resetButton.tick();
	}

	@Override
	public boolean method_25402(double mouseX, double mouseY, int button) {
		if (super.method_25402(mouseX, mouseY, button))
			return true;

		if (button != GLFW.GLFW_MOUSE_BUTTON_1) {
			return false;
		}

		long handle = class_310.method_1551().method_22683().method_4490();
		if (!class_3675.method_15987(handle, GLFW.GLFW_KEY_LEFT_CONTROL)) {
			return false;
		}

		// workaround while config type isn't available here yet.
		ModConfig.Type configType = ModConfig.Type.CLIENT;
		class_437 screen = class_310.method_1551().field_1755;
		if (screen instanceof SubMenuConfigScreen subMenuScreen) {
			configType = subMenuScreen.type;
		}


		// ctrl-click to copy the full path to clipboard
		this.annotations.put("highlight", ":)");
		clipboardHelper.method_15979(handle, ConfigScreen.modID + ":" + configType.extension() + "." + path);

		return true;
	}

	@Override
	public void method_25343(class_332 graphics, int index, int y, int x, int width, int height, int mouseX, int mouseY, boolean p_230432_9_, float partialTicks) {
		super.method_25343(graphics, index, y, x, width, height, mouseX, mouseY, p_230432_9_, partialTicks);

		resetButton.method_46421(x + width - resetWidth + 6);
		resetButton.method_46421(y + 10);
		resetButton.method_25394(graphics, mouseX, mouseY, partialTicks);
	}

	@Override
	protected int getLabelWidth(int totalWidth) {
		return (int) (totalWidth * labelWidthMult) + 30;
	}

	public void setValue(@Nonnull T value) {
		ConfigHelper.setValue(path, this.value, value, annotations);
		onValueChange(value);
	}

	@Nonnull
	public T getValue() {
		return ConfigHelper.getValue(path, this.value);
	}

	protected boolean isCurrentValueDefault() {
		return spec.getDefault().equals(getValue());
	}

	public void onReset() {
		onValueChange(getValue());
	}

	public void onValueChange() {
		onValueChange(getValue());
	}
	public void onValueChange(T newValue) {
		resetButton.field_22763 = editable && !isCurrentValueDefault();
		resetButton.animateGradientFromState();
	}

	protected void bumpCog() {bumpCog(10f);}
	protected void bumpCog(float force) {
		ConfigScreen.cogSpin.bump(3, force);
	}
}
