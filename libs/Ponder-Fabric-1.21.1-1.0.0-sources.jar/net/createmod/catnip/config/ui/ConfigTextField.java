package net.createmod.catnip.config.ui;

import net.minecraft.class_327;

public class ConfigTextField extends HintableTextFieldWidget {

	public ConfigTextField(class_327 font, int x, int y, int width, int height) {
		super(font, x, y, width, height);
	}

	@Override
	public boolean method_25402(double x, double y, int button) {
		if (!method_25405(x, y))
			method_25365(false);
		return super.method_25402(x, y, button);
	}

	@Override
	public void method_25348(double pMouseX, double pMouseY) {
		super.method_25348(pMouseX, pMouseY);
		method_25365(true);
	}

	@Override
	public void method_25365(boolean focus) {
		super.method_25365(focus);

		if (!focus) {
			if (ConfigScreenList.currentText == this)
				ConfigScreenList.currentText = null;

			return;
		}

		if (ConfigScreenList.currentText != null && ConfigScreenList.currentText != this)
			ConfigScreenList.currentText.method_25365(false);

		ConfigScreenList.currentText = this;
	}
}
