package net.createmod.catnip.config.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

import javax.annotation.Nullable;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;

import net.createmod.catnip.gui.TickableGuiEventListener;
import net.createmod.catnip.gui.UIRenderHelper;
import net.createmod.catnip.gui.element.TextStencilElement;
import net.createmod.catnip.animation.LerpedFloat;
import net.createmod.catnip.theme.Color;
import net.minecraft.class_1041;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_364;
import net.minecraft.class_4280;
import net.minecraft.class_5244;
import net.minecraft.class_5250;

public class ConfigScreenList extends class_4280<ConfigScreenList.Entry> implements TickableGuiEventListener {

	@Nullable public static class_342 currentText;

	public ConfigScreenList(class_310 client, int width, int height, int top, int elementHeight) {
		super(client, width, height, top, elementHeight);
		currentText = null;
		field_22748 = 3;
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		Color c = new Color(0x60_000000);
		UIRenderHelper.angledGradient(graphics, 90, method_46426() + field_22758 / 2, method_46427(), field_22758, 5, c, Color.TRANSPARENT_BLACK);
		UIRenderHelper.angledGradient(graphics, -90, method_46426() + field_22758 / 2, method_55443(), field_22758, 5, c, Color.TRANSPARENT_BLACK);
		UIRenderHelper.angledGradient(graphics, 0, method_46426(), method_46427() + field_22759 / 2, field_22759, 5, c, Color.TRANSPARENT_BLACK);
		UIRenderHelper.angledGradient(graphics, 180, method_55442(), method_46427() + field_22759 / 2, field_22759, 5, c, Color.TRANSPARENT_BLACK);

		super.method_25394(graphics, mouseX, mouseY, partialTicks);
	}

	@Override
	protected void method_25311(class_332 graphics, int mouseX, int mouseY, float partialTick) {
		class_1041 window = field_22740.method_22683();
		double d0 = window.method_4495();
		RenderSystem.enableScissor((int) (method_46426() * d0), (int) (window.method_4506() - (method_55443() * d0)), (int) (this.field_22758 * d0), (int) (this.field_22759 * d0));
		super.method_25311(graphics, mouseX, mouseY, partialTick);
		RenderSystem.disableScissor();
	}

	@Override
	public boolean method_25402(double x, double y, int button) {
		//children().stream().filter(e -> e instanceof NumberEntry<?>).forEach(e -> e.mouseClicked(x, y, button));

		return super.method_25402(x, y, button);
	}

	@Override
	public int method_25322() {
		return field_22758 - 16;
	}

	public int method_25368() {
		return field_22758;
	}

	@Override
	protected int method_25329() {
		return method_46426() + this.field_22758 - 6;
	}

	@Override
	public void tick() {
		/*for(int i = 0; i < getItemCount(); ++i) {
			int top = this.getRowTop(i);
			int bot = top + itemHeight;
			if (bot >= this.y0 && top <= this.y1)
				this.getEntry(i).tick();
		}*/
		method_25396().forEach(Entry::tick);

	}

	public boolean search(String query) {
		if (query == null || query.isEmpty()) {
			method_25307(0);
			return true;
		}

		String q = query.toLowerCase(Locale.ROOT);
		Optional<Entry> first = method_25396().stream().filter(entry -> {
			if (entry.path == null)
				return false;

			String[] split = entry.path.split("\\.");
			String key = split[split.length - 1].toLowerCase(Locale.ROOT);
			return key.contains(q);
		}).findFirst();

		if (first.isEmpty()) {
			method_25307(0);
			return false;
		}

		Entry e = first.get();
		e.annotations.put("highlight", "(:");
		method_25324(e);
		return true;
	}

	public void bumpCog(float force) {
		ConfigScreen.cogSpin.bump(3, force);
	}

	public static abstract class Entry extends class_4280.class_4281<Entry> implements TickableGuiEventListener {
		protected List<class_364> listeners;
		protected Map<String, String> annotations;
		@Nullable protected String path;

		protected Entry() {
			listeners = new ArrayList<>();
			annotations = new HashMap<>();
		}

		@Override
		public boolean method_25402(double x, double y, int button) {
			return getGuiListeners().stream().anyMatch(l -> l.method_25402(x, y, button));
		}

		@Override
		public boolean method_25404(int code, int keyPressed_2_, int keyPressed_3_) {
			return getGuiListeners().stream().anyMatch(l -> l.method_25404(code, keyPressed_2_, keyPressed_3_));
		}

		@Override
		public boolean method_25400(char ch, int code) {
			for (class_364 l : getGuiListeners()) {
				if (l.method_25400(ch, code)) {
					return true;
				}
			}

			return false;
		}

		@Override
		public void tick() {}

		public List<class_364> getGuiListeners() {
			return listeners;
		}

		protected void setEditable(boolean b) {}

		protected boolean isCurrentValueChanged() {
			if (path == null) {
				return false;
			}
			return ConfigHelper.changes.containsKey(path);
		}
	}

	public static class LabeledEntry extends Entry {

		protected static final float labelWidthMult = 0.4f;

		protected TextStencilElement label;
		protected List<class_2561> labelTooltip;
		@Nullable protected String unit = null;
		protected LerpedFloat differenceAnimation = LerpedFloat.linear().startWithValue(0);
		protected LerpedFloat highlightAnimation = LerpedFloat.linear().startWithValue(0);

		public LabeledEntry(String label) {
			this.label = new TextStencilElement(class_310.method_1551().field_1772, label);
			this.label.withElementRenderer((graphics, width, height, alpha) -> UIRenderHelper.angledGradient(graphics, 0, 0, height / 2, height, width, UIRenderHelper.COLOR_TEXT_STRONG_ACCENT));
			labelTooltip = new ArrayList<>();
		}

		public LabeledEntry(String label, String path) {
			this(label);
			this.path = path;
		}

		@Override
		public void tick() {
			differenceAnimation.tickChaser();
			highlightAnimation.tickChaser();
			super.tick();
		}

		@Override
		public void method_25343(class_332 graphics, int index, int y, int x, int width, int height, int mouseX, int mouseY, boolean p_230432_9_, float partialTicks) {
			if (isCurrentValueChanged()) {
				if (differenceAnimation.getChaseTarget() != 1)
					differenceAnimation.chase(1, .5f, LerpedFloat.Chaser.EXP);
			} else {
				if (differenceAnimation.getChaseTarget() != 0)
					differenceAnimation.chase(0, .6f, LerpedFloat.Chaser.EXP);
			}

			float animation = differenceAnimation.getValue(partialTicks);
			if (animation > .1f) {
				int offset = (int) (30 * (1 - animation));

				if (annotations.containsKey(ConfigAnnotations.RequiresRestart.CLIENT.getName())) {
					UIRenderHelper.streak(graphics, 180, x + width + 10 + offset, y + height / 2, height - 6, 110, new Color(0x50_601010));
				} else if (annotations.containsKey(ConfigAnnotations.RequiresRelog.TRUE.getName())) {
					UIRenderHelper.streak(graphics, 180, x + width + 10 + offset, y + height / 2, height - 6, 110, new Color(0x40_eefb17));
				}

				UIRenderHelper.breadcrumbArrow(graphics, x - 10 - offset, y + 6, 0, -20, 24, -18, new Color(0x70_ffffff), Color.TRANSPARENT_BLACK);
			}

			UIRenderHelper.streak(graphics, 0, x - 10, y + height / 2, height - 6, width / 8 * 7, new Color(0xdd_000000));
			UIRenderHelper.streak(graphics, 180, x + (int) (width * 1.35f) + 10, y + height / 2, height - 6, width / 8 * 7, new Color(0xdd_000000));
			class_5250 component = label.getComponent();
			class_327 font = class_310.method_1551().field_1772;
			if (font.method_27525(component) > getLabelWidth(width) - 10) {
				label.withText(font.method_1714(component, getLabelWidth(width) - 15).getString() + "...");
			}
			if (unit != null) {
				int unitWidth = font.method_1727(unit);
				graphics.method_25303(font, unit, x + getLabelWidth(width) - unitWidth - 5, y + height / 2 + 2, UIRenderHelper.COLOR_TEXT_DARKER.getFirst().getRGB());
				label.at(x + 10, y + height / 2 - 10, 0).render(graphics);
			} else {
				label.at(x + 10, y + height / 2 - 4, 0).render(graphics);
			}

			if (annotations.containsKey("highlight")) {
				highlightAnimation.startWithValue(1).chase(0, 0.1f, LerpedFloat.Chaser.LINEAR);
				annotations.remove("highlight");
			}

			animation = highlightAnimation.getValue(partialTicks);
			if (animation > .01f) {
				Color highlight = new Color(0xa0_ffffff).scaleAlpha(animation);
				UIRenderHelper.streak(graphics, 0, x - 10, y + height / 2, height - 6, 5, highlight);
				UIRenderHelper.streak(graphics, 180, x + width, y + height / 2, height - 6, 5, highlight);
				UIRenderHelper.streak(graphics, 90, x + width / 2 - 5, y + 3, width + 10, 5, highlight);
				UIRenderHelper.streak(graphics, -90, x + width / 2 - 5, y + height - 3, width + 10, 5, highlight);
			}


			if (mouseX > x && mouseX < x + getLabelWidth(width) && mouseY > y + 5 && mouseY < y + height - 5) {
				List<class_2561> tooltip = getLabelTooltip();
				if (tooltip.isEmpty())
					return;

				RenderSystem.disableScissor();
				graphics.method_51448().method_22903();
				graphics.method_51434(font, tooltip, mouseX, mouseY);
				graphics.method_51452();
				//RemovedGuiUtils.drawHoveringText(ms, tooltip, mouseX, mouseY, screen.width, screen.height, 300, font);
				graphics.method_51448().method_22909();
				GlStateManager._enableScissorTest();
			}
		}



		public List<class_2561> getLabelTooltip() {
			return labelTooltip;
		}

		protected int getLabelWidth(int totalWidth) {
			return totalWidth;
		}

		// TODO 1.17
		@Override
		public class_2561 method_37006() {
			return class_5244.field_39003;
		}
	}
}
