@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package net.createmod.catnip.config;

import javax.annotation.ParametersAreNonnullByDefault;