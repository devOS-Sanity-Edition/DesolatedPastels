@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package net.createmod.catnip.math;

import javax.annotation.ParametersAreNonnullByDefault;
