package net.createmod.catnip.math;

import net.minecraft.class_2338;
import net.minecraft.class_3341;

public class BBHelper {

	public static class_3341 encapsulate(class_3341 bb, class_2338 pos) {
		return new class_3341(Math.min(bb.method_35415(), pos.method_10263()), Math.min(bb.method_35416(), pos.method_10264()),
			Math.min(bb.method_35417(), pos.method_10260()), Math.max(bb.method_35418(), pos.method_10263()), Math.max(bb.method_35419(), pos.method_10264()),
			Math.max(bb.method_35420(), pos.method_10260()));
	}

	public static class_3341 encapsulate(class_3341 bb, class_3341 bb2) {
		return new class_3341(Math.min(bb.method_35415(), bb2.method_35415()), Math.min(bb.method_35416(), bb2.method_35416()),
			Math.min(bb.method_35417(), bb2.method_35417()), Math.max(bb.method_35418(), bb2.method_35418()), Math.max(bb.method_35419(), bb2.method_35419()),
			Math.max(bb.method_35420(), bb2.method_35420()));
	}

}
