package net.createmod.catnip.math;

import net.createmod.catnip.lang.Lang;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2350.class_2352;
import net.minecraft.class_3542;

public enum Pointing implements class_3542 {
	UP(0), LEFT(270), DOWN(180), RIGHT(90);

	private final int xRotation;

	private Pointing(int xRotation) {
		this.xRotation = xRotation;
	}

	@Override
	public String method_15434() {
		return Lang.asId(name());
	}

	public int getXRotation() {
		return xRotation;
	}

	public class_2350 getCombinedDirection(class_2350 direction) {
		class_2351 axis = direction.method_10166();
		class_2350 top = axis == class_2351.field_11052 ? class_2350.field_11035 : class_2350.field_11036;
		int rotations = direction.method_10171() == class_2352.field_11060 ? 4 - ordinal() : ordinal();
		for (int i = 0; i < rotations; i++)
			top = top.method_35833(axis);
		return top;
	}

}
