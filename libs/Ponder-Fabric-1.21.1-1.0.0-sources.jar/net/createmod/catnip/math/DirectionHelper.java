package net.createmod.catnip.math;

import static net.minecraft.class_2350.field_11033;
import static net.minecraft.class_2350.field_11034;
import static net.minecraft.class_2350.field_11043;
import static net.minecraft.class_2350.field_11035;
import static net.minecraft.class_2350.field_11036;
import static net.minecraft.class_2350.field_11039;

import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;

/**
 * A bunch of methods that got stripped out of Direction in 1.15
 *
 * @author Mojang
 */
public class DirectionHelper {

	public static class_2350 rotateAround(class_2350 dir, class_2350.class_2351 axis) {
		switch (axis) {
		case field_11048:
			if (dir != field_11039 && dir != field_11034) {
				return rotateX(dir);
			}

			return dir;
		case field_11052:
			if (dir != field_11036 && dir != field_11033) {
				return dir.method_10170();
			}

			return dir;
		case field_11051:
			if (dir != field_11043 && dir != field_11035) {
				return rotateZ(dir);
			}

			return dir;
		default:
			throw new IllegalStateException("Unable to get CW facing for axis " + axis);
		}
	}

	public static class_2350 rotateX(class_2350 dir) {
		return switch (dir) {
			case field_11043 -> field_11033;
			case field_11034, field_11039 -> throw new IllegalStateException("Unable to get X-rotated facing of " + dir);
			case field_11035 -> field_11036;
			case field_11036 -> field_11043;
			case field_11033 -> field_11035;
		};
	}

	public static class_2350 rotateZ(class_2350 dir) {
		return switch (dir) {
			case field_11034 -> field_11033;
			case field_11035, field_11043 -> throw new IllegalStateException("Unable to get Z-rotated facing of " + dir);
			case field_11039 -> field_11036;
			case field_11036 -> field_11034;
			case field_11033 -> field_11039;
		};
	}

	public static class_2350 getPositivePerpendicular(class_2351 horizontalAxis) {
		return horizontalAxis == class_2351.field_11048 ? field_11035 : field_11034;
	}

}
