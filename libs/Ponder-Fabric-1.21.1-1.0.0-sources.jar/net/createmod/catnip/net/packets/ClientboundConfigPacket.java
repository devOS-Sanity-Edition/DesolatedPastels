package net.createmod.catnip.net.packets;

import io.netty.buffer.ByteBuf;
import net.createmod.catnip.config.ui.ConfigHelper;
import net.createmod.catnip.net.CatnipPackets;
import net.createmod.catnip.net.base.ClientboundPacketPayload;
import net.createmod.ponder.Ponder;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.neoforged.fml.config.ModConfig;

public record ClientboundConfigPacket(String path, String value) implements ClientboundPacketPayload {
	public static final class_9139<ByteBuf, ClientboundConfigPacket> STREAM_CODEC = class_9139.method_56435(
		class_9135.field_48554, ClientboundConfigPacket::path,
		class_9135.field_48554, ClientboundConfigPacket::value,
		ClientboundConfigPacket::new
	);

	@Override
	public PacketTypeProvider getTypeProvider() {
		return CatnipPackets.CLIENTBOUND_CONFIG;
	}

	@Override
	public void handle(class_746 player) {
		if (class_310.method_1551().field_1724 == null) {
			return;
		}

		ConfigHelper.ConfigPath path;

		try {
			path = ConfigHelper.ConfigPath.parse(this.path);
		} catch (IllegalArgumentException e) {
			player.method_7353(Ponder.lang().text(e.getMessage()).component(), false);
			return;
		}

		if (path.getType() != ModConfig.Type.CLIENT) {
			Ponder.LOGGER.warn("Received type-mismatched config packet on client");
			return;
		}

		try {
			ConfigHelper.setConfigValue(path, value);
			player.method_7353(class_2561.method_43470("Great Success!"), false);
		} catch (ConfigHelper.InvalidValueException e) {
			player.method_7353(class_2561.method_43470("Config could not be set the the specified value!"), false);
		} catch (Exception e) {
			player.method_7353(class_2561.method_43470("Something went wrong while trying to set config value. Check the client logs for more information"), false);
			Ponder.LOGGER.warn("Exception during client-side config value set:", e);
		}

	}
}
