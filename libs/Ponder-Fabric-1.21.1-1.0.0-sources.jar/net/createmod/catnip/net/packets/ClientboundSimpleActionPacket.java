package net.createmod.catnip.net.packets;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Supplier;

import io.netty.buffer.ByteBuf;
import net.createmod.catnip.net.CatnipPackets;
import net.createmod.catnip.net.SimpleCatnipActions;
import net.createmod.catnip.net.base.ClientboundPacketPayload;
import net.createmod.ponder.Ponder;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ClientboundSimpleActionPacket(String action, String value) implements ClientboundPacketPayload {
	public static final class_9139<ByteBuf, ClientboundSimpleActionPacket> STREAM_CODEC = class_9139.method_56435(
		class_9135.field_48554, ClientboundSimpleActionPacket::action,
		class_9135.field_48554, ClientboundSimpleActionPacket::value,
		ClientboundSimpleActionPacket::new
	);

	private static final Map<String, Supplier<Consumer<String>>> actions = new HashMap<>();

	public static void addAction(String name, Supplier<Consumer<String>> action) {
		actions.put(name, action);
	}

	static {
		addAction("test", () -> System.out::println);
		addAction("configScreen", () -> SimpleCatnipActions::configScreen);
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return CatnipPackets.CLIENTBOUND_SIMPLE_ACTION;
	}

	@Override
	public void handle(class_746 player) {
		if (!actions.containsKey(action)) {
			Ponder.LOGGER.warn("Received ClientboundSimpleActionPacket with invalid Action {}, ignoring the packet", action);
			return;
		}

		class_310.method_1551().execute(() -> actions.get(action).get().accept(value));
	}
}
