package net.createmod.catnip.net;

import java.util.Locale;

import net.createmod.catnip.net.base.BasePacketPayload;
import net.createmod.catnip.net.base.CatnipPacketRegistry;
import net.createmod.catnip.net.packets.ClientboundConfigPacket;
import net.createmod.catnip.net.packets.ClientboundSimpleActionPacket;
import net.createmod.catnip.net.packets.ServerboundConfigPacket;
import net.createmod.ponder.Ponder;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public enum CatnipPackets implements BasePacketPayload.PacketTypeProvider {
	// C2S
	SERVERBOUND_CONFIG(ServerboundConfigPacket.class, ServerboundConfigPacket.STREAM_CODEC),

	// S2C
	CLIENTBOUND_SIMPLE_ACTION(ClientboundSimpleActionPacket.class, ClientboundSimpleActionPacket.STREAM_CODEC),
	CLIENTBOUND_CONFIG(ClientboundConfigPacket.class, ClientboundConfigPacket.STREAM_CODEC);

	private final CatnipPacketRegistry.PacketType<?> type;

	<T extends BasePacketPayload> CatnipPackets(Class<T> clazz, class_9139<? super class_9129, T> codec) {
		String name = this.name().toLowerCase(Locale.ROOT);
		this.type = new CatnipPacketRegistry.PacketType<>(
			new class_8710.class_9154<>(Ponder.asResource(name)),
			clazz, codec
		);
	}


	@Override
	public <T extends class_8710> class_8710.class_9154<T> getType() {
		//noinspection unchecked
		return (class_8710.class_9154<T>) type.type();
	}

	public static void register() {
		CatnipPacketRegistry registry = new CatnipPacketRegistry(Ponder.MOD_ID, 1);

		for (CatnipPackets packet : values()) {
			registry.registerPacket(packet.type);
		}

		registry.registerAllPackets();
	}
}
