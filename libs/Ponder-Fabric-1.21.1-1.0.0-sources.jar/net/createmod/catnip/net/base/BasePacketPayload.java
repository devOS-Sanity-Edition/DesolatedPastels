package net.createmod.catnip.net.base;

import net.minecraft.class_8710;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

public sealed interface BasePacketPayload extends class_8710 permits ClientboundPacketPayload, ServerboundPacketPayload {
	PacketTypeProvider getTypeProvider();

	@Override
	@ApiStatus.NonExtendable
	default @NotNull class_9154<? extends class_8710> method_56479() {
		return this.getTypeProvider().getType();
	}

	interface PacketTypeProvider {
		<T extends class_8710> class_9154<T> getType();
	}
}
