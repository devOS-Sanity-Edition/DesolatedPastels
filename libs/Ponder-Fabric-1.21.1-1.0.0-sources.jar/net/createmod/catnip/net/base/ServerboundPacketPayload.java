package net.createmod.catnip.net.base;

import net.minecraft.class_3222;

public non-sealed interface ServerboundPacketPayload extends BasePacketPayload {
	/**
	 * Called on the main client thread.
	 */
	void handle(class_3222 player);
}
