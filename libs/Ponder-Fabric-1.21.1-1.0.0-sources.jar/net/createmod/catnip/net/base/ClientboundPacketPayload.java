package net.createmod.catnip.net.base;

import net.minecraft.class_1657;
import net.minecraft.class_746;

public non-sealed interface ClientboundPacketPayload extends BasePacketPayload {
	// TODO - Something
	/**
	 * Called on the main client thread.
	 * Make sure that implementations are also annotated, or else servers may crash.
	 */
	void handle(class_746 player);

	default void handleInternal(class_1657 player) {
		if (player instanceof class_746 localPlayer)
			handle(localPlayer);
	}
}
