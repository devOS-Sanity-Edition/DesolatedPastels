package net.createmod.catnip.net;

import net.createmod.catnip.config.ui.ConfigHelper;
import net.createmod.catnip.config.ui.ConfigModListScreen;
import net.createmod.catnip.config.ui.SubMenuConfigScreen;
import net.createmod.catnip.gui.ScreenOpener;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class SimpleCatnipActions {

	public static void configScreen(String value) {
		if (value.equals("")) {
			ScreenOpener.open(new ConfigModListScreen(null));
			return;
		}

		class_746 player = class_310.method_1551().field_1724;

		if (player == null)
			return;

		ConfigHelper.ConfigPath configPath;
		try {
			configPath = ConfigHelper.ConfigPath.parse(value);
		} catch (IllegalArgumentException e) {
			player.method_7353(class_2561.method_43470(e.getMessage()), false);
			return;
		}

		try {
			ScreenOpener.open(SubMenuConfigScreen.find(configPath));
		} catch (Exception e) {
			player.method_7353(class_2561.method_43470("Unable to find the specified config"), false);
		}
	}

}
