package net.createmod.catnip.command;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.createmod.ponder.Ponder;
import net.minecraft.class_1656;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2696;
import net.minecraft.class_3222;

public class FlySpeedCommand {

	public static ArgumentBuilder<class_2168, ?> register() {
		return class_2170.method_9247("flySpeed")
			.requires(cs -> cs.method_9259(2))
			.then(class_2170.method_9244("speed", FloatArgumentType.floatArg(0))
				.then(class_2170.method_9244("target", class_2186.method_9305())
					.executes(ctx -> sendFlySpeedUpdate(ctx, class_2186.method_9315(ctx, "target"),
						FloatArgumentType.getFloat(ctx, "speed"))))
				.executes(ctx -> sendFlySpeedUpdate(ctx, ctx.getSource()
					.method_9207(), FloatArgumentType.getFloat(ctx, "speed"))))
			.then(class_2170.method_9247("reset")
				.then(class_2170.method_9244("target", class_2186.method_9305())
					.executes(ctx -> sendFlySpeedUpdate(ctx, class_2186.method_9315(ctx, "target"), 0.05f)))
				.executes(ctx -> sendFlySpeedUpdate(ctx, ctx.getSource()
					.method_9207(), 0.05f))

			);
	}

	private static int sendFlySpeedUpdate(CommandContext<class_2168> ctx, class_3222 player, float speed) {
		class_1656 abilities = player.method_31549();
		abilities.method_7248(speed);
		player.field_13987.method_14364(new class_2696(abilities));
		ctx.getSource().method_9226(() ->
				Ponder.lang()
						.text("Temporarily set ")
						.add(player.method_5477().method_27661())
						.text("'s Flying Speed to " + speed)
						.component(),
				true
		);

		return Command.SINGLE_SUCCESS;
	}

}
