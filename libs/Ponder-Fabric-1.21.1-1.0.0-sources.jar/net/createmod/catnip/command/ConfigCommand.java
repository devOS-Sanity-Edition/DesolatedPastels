package net.createmod.catnip.command;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;

import net.createmod.catnip.config.ui.ConfigHelper;
import net.createmod.catnip.net.ConfigPathArgument;
import net.createmod.catnip.net.packets.ClientboundConfigPacket;
import net.createmod.catnip.net.packets.ClientboundSimpleActionPacket;
import net.createmod.catnip.platform.CatnipServices;
import net.createmod.ponder.Ponder;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.neoforged.fml.config.ModConfig;

/**
 * Examples:
 * /catnip config client - to open Catnip's ConfigGui with the client config already selected
 * /catnip config "botania:common" - to open Catnip's ConfigGui with Botania's common config already selected
 * /catnip config "create:client.client.rainbowDebug" set false - to disable Create's rainbow debug for the sender
 */
public class ConfigCommand {

	public static ArgumentBuilder<class_2168, ?> register() {
		return class_2170.method_9247("config")
				.executes(ctx -> {
					class_3222 player = ctx.getSource().method_9207();
					CatnipServices.NETWORK.sendToClient(player,
							new ClientboundSimpleActionPacket("configScreen", ""));

					return Command.SINGLE_SUCCESS;
				})
				.then(class_2170.method_9244("path", ConfigPathArgument.path())
						.executes(ctx -> {
							class_3222 player = ctx.getSource().method_9207();

							CatnipServices.NETWORK.sendToClient(player,
									new ClientboundSimpleActionPacket("configScreen", ConfigPathArgument.getPath(ctx, "path").toString()));

							return Command.SINGLE_SUCCESS;
						})
						.then(class_2170.method_9247("set")
								.requires(cs -> cs.method_9259(2))
								.then(class_2170.method_9244("value", StringArgumentType.string())
										.executes(ctx -> {
											ConfigHelper.ConfigPath path = ConfigPathArgument.getPath(ctx, "path");
											String value = StringArgumentType.getString(ctx, "value");

											if (path.getType() == ModConfig.Type.CLIENT) {
												class_3222 player = ctx.getSource().method_9207();

												CatnipServices.NETWORK.sendToClient(player,
														new ClientboundConfigPacket(path.toString(), value));

												return Command.SINGLE_SUCCESS;
											}

											try {
												ConfigHelper.setConfigValue(path, value);
												ctx.getSource().method_9226(() -> class_2561.method_43470("Great Success!"), false);
												return Command.SINGLE_SUCCESS;
											} catch (ConfigHelper.InvalidValueException e) {
												ctx.getSource().method_9213(class_2561.method_43470("Config could not be set the the specified value!"));
												return 0;
											} catch (Exception e) {
												ctx.getSource().method_9213(class_2561.method_43470("Something went wrong while trying to set config value. Check the server logs for more information"));
												Ponder.LOGGER.warn("Exception during server-side config value set:", e);
												return 0;
											}
										})
								)
						)
				);
	}

}
