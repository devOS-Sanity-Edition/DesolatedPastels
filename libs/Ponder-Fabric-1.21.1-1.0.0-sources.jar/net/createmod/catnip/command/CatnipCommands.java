package net.createmod.catnip.command;

import java.util.Collections;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.tree.CommandNode;
import com.mojang.brigadier.tree.LiteralCommandNode;

public class CatnipCommands {

	public static void register(CommandDispatcher<class_2168> dispatcher) {

		LiteralCommandNode<class_2168> util = buildUtilityCommands();

		LiteralCommandNode<class_2168> catnipRoot = class_2170.method_9247("catnip")
				.requires(cs -> cs.method_9259(0))
				.then(ConfigCommand.register())
				.then(util)
				.build();

		catnipRoot.addChild(buildRedirect("u", util));

		dispatcher.getRoot().addChild(catnipRoot);

		//add all of Catnip's commands to /c if it already exists, otherwise create the shortcut
		createOrAddToShortcut(dispatcher, "c", catnipRoot);
	}

	private static LiteralCommandNode<class_2168> buildUtilityCommands() {

		return class_2170.method_9247("util")
				.then(FlySpeedCommand.register())
				.build();

	}

	/**
	 * *****
	 * <a href="https://github.com/VelocityPowered/Velocity/blob/8abc9c80a69158ebae0121fda78b55c865c0abad/proxy/src/main/java/com/velocitypowered/proxy/util/BrigadierUtils.java#L38">Source</a>
	 * *****
	 * <p>
	 * Returns a literal node that redirects its execution to
	 * the given destination node.
	 *
	 * @param alias       the command alias
	 * @param destination the destination node
	 *
	 * @return the built node
	 */
	public static LiteralCommandNode<class_2168> buildRedirect(final String alias, final LiteralCommandNode<class_2168> destination) {
		// Redirects only work for nodes with children, but break the top argument-less command.
		// Manually adding the root command after setting the redirect doesn't fix it.
		// See https://github.com/Mojang/brigadier/issues/46). Manually clone the node instead.
		LiteralArgumentBuilder<class_2168> builder = LiteralArgumentBuilder
				.<class_2168>literal(alias)
				.requires(destination.getRequirement())
				.forward(destination.getRedirect(), destination.getRedirectModifier(), destination.isFork())
				.executes(destination.getCommand());
		for (CommandNode<class_2168> child : destination.getChildren()) {
			builder.then(child);
		}
		return builder.build();
	}

	public static void createOrAddToShortcut(CommandDispatcher<class_2168> dispatcher, String shortcut, LiteralCommandNode<class_2168> createRoot) {
		CommandNode<class_2168> node = dispatcher.findNode(Collections.singleton(shortcut));
		if (node != null) {
			for (CommandNode<class_2168> child : createRoot.getChildren()) {
				node.addChild(child);
			}
			return;
		}

		dispatcher.getRoot().addChild(CatnipCommands.buildRedirect(shortcut, createRoot));
	}
}
