package net.createmod.catnip.registry;

import javax.annotation.Nullable;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1842;
import net.minecraft.class_1865;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2396;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_7923;

public class RegisteredObjectsHelper {
	public static <V> class_2960 getKeyOrThrow(class_2378<V> registry, V value) {
		class_2960 key = registry.method_10221(value);
		if (key == null) {
			throw new IllegalArgumentException("Could not get key for value " + value + "!");
		}
		return key;
	}

	public static class_2960 getKeyOrThrow(class_2248 value) {
		return getKeyOrThrow(class_7923.field_41175, value);
	}

	public static class_2960 getKeyOrThrow(class_1792 value) {
		return getKeyOrThrow(class_7923.field_41178, value);
	}

	public static class_2960 getKeyOrThrow(class_3611 value) {
		return getKeyOrThrow(class_7923.field_41173, value);
	}

	public static class_2960 getKeyOrThrow(class_1299<?> value) {
		return getKeyOrThrow(class_7923.field_41177, value);
	}

	public static class_2960 getKeyOrThrow(class_2591<?> value) {
		return getKeyOrThrow(class_7923.field_41181, value);
	}

	public static class_2960 getKeyOrThrow(class_1842 value) {
		return getKeyOrThrow(class_7923.field_41179, value);
	}

	public static class_2960 getKeyOrThrow(class_2396<?> value) {
		return getKeyOrThrow(class_7923.field_41180, value);
	}

	public static class_2960 getKeyOrThrow(class_1865<?> value) {
		return getKeyOrThrow(class_7923.field_41189, value);
	}

	public static class_1792 getItem(class_2960 location) {
		return class_7923.field_41178.method_10223(location);
	}

	public static class_2248 getBlock(class_2960 location) {
		return class_7923.field_41175.method_10223(location);
	}

	@Nullable
	public static class_1935 getItemOrBlock(class_2960 location) {
		class_1792 item = getItem(location);
		if (item != class_1802.field_8162)
			return item;

		class_2248 block = getBlock(location);
		if (block != class_2246.field_10124)
			return block;

		return null;
	}

	public static class_2960 getKeyOrThrow(class_1935 itemLike) {
		if (itemLike instanceof class_1792 item) {
			return getKeyOrThrow(item);
		} else if (itemLike instanceof class_2248 block) {
			return getKeyOrThrow(block);
		}

		throw new IllegalArgumentException("Could not get key for itemLike " + itemLike + "!");
	}

}
