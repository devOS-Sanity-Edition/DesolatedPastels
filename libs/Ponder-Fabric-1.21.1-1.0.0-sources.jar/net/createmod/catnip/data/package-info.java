@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package net.createmod.catnip.data;

import javax.annotation.ParametersAreNonnullByDefault;
