package net.createmod.catnip.data;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;

public class Iterate {

	public static final boolean[] trueAndFalse = { true, false };
	public static final boolean[] falseAndTrue = { false, true };
	public static final int[] zeroAndOne = { 0, 1 };
	public static final int[] positiveAndNegative = { 1, -1 };
	public static final class_2350[] directions = class_2350.values();
	public static final class_2350[] horizontalDirections = getHorizontals();
	public static final class_2351[] axes = class_2351.values();
	public static final EnumSet<class_2350.class_2351> axisSet = EnumSet.allOf(class_2350.class_2351.class);

	private static class_2350[] getHorizontals() {
		class_2350[] directions = new class_2350[4];
		for (int i = 0; i < 4; i++)
			directions[i] = class_2350.method_10139(i);
		return directions;
	}

	public static class_2350[] directionsInAxis(class_2351 axis) {
		switch (axis) {
		case field_11048:
			return new class_2350[] { class_2350.field_11034, class_2350.field_11039 };
		case field_11052:
			return new class_2350[] { class_2350.field_11036, class_2350.field_11033 };
		default:
		case field_11051:
			return new class_2350[] { class_2350.field_11035, class_2350.field_11043 };
		}
	}

	public static List<class_2338> hereAndBelow(class_2338 pos) {
		return Arrays.asList(pos, pos.method_10074());
	}

	public static List<class_2338> hereBelowAndAbove(class_2338 pos) {
		return Arrays.asList(pos, pos.method_10074(), pos.method_10084());
	}

	public static <T> T cycleValue(List<T> list, T current) {
		int currentIndex = list.indexOf(current);
		if (currentIndex == -1) {
			throw new IllegalArgumentException("Current value not found in list");
		}
		int nextIndex = (currentIndex + 1) % list.size();
		return list.get(nextIndex);
	}

}
