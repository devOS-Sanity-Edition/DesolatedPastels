package net.createmod.catnip.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import io.netty.buffer.ByteBuf;
import java.util.Comparator;
import java.util.function.Function;
import net.minecraft.class_2487;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class LongAttached<V> extends Pair<Long, V> {
	protected LongAttached(Long first, V second) {
		super(first, second);
	}

	public static <V> LongAttached<V> with(long number, V value) {
		return new LongAttached<>(number, value);
	}

	public static <V> LongAttached<V> withZero(V value) {
		return new LongAttached<>(0L, value);
	}

	public boolean isZero() {
		return first == 0;
	}

	public boolean exceeds(long value) {
		return first > value;
	}

	public boolean isOrBelowZero() {
		return first <= 0;
	}

	public void increment() {
		first++;
	}

	public void decrement() {
		first--;
	}

	public V getValue() {
		return getSecond();
	}

	public class_2487 serializeNBT(Function<V, class_2487> serializer) {
		class_2487 nbt = new class_2487();
		nbt.method_10566("Item", serializer.apply(getValue()));
		nbt.method_10544("Location", getFirst());
		return nbt;
	}

	public static Comparator<? super LongAttached<?>> comparator() {
		return (i1, i2) -> Long.compare(i2.getFirst(), i1.getFirst());
	}

	public static <T> LongAttached<T> read(class_2487 nbt, Function<class_2487, T> deserializer) {
		return LongAttached.with(nbt.method_10537("Location"), deserializer.apply(nbt.method_10562("Item")));
	}

	public static <T> Codec<LongAttached<T>> codec(Codec<T> codec) {
		return RecordCodecBuilder.create(instance -> instance.group(
			Codec.LONG.fieldOf("first").forGetter(LongAttached::getFirst),
			codec.fieldOf("second").forGetter(LongAttached::getSecond)
		).apply(instance, LongAttached::new));
	}

	public static <B extends ByteBuf, T> class_9139<B, LongAttached<T>> streamCodec(class_9139<? super B, T> codec) {
		return class_9139.method_56435(
			class_9135.field_48551, Pair::getFirst,
			codec, Pair::getSecond,
			LongAttached::new
		);
	}
}
