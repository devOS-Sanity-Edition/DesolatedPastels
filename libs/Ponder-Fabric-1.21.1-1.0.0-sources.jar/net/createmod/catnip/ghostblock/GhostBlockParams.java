package net.createmod.catnip.ghostblock;

import java.util.function.Supplier;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class GhostBlockParams {

	protected final class_2680 state;
	protected class_2338 pos;
	protected Supplier<Float> alphaSupplier;

	private GhostBlockParams(class_2680 state) {
		this.state = state;
		this.pos = class_2338.field_10980;
		this.alphaSupplier = () -> 1f;
	}

	public static GhostBlockParams of(class_2680 state) {
		return new GhostBlockParams(state);
	}

	public static GhostBlockParams of(class_2248 block) {
		return of(block.method_9564());
	}

	public GhostBlockParams at(class_2338 pos) {
		this.pos = pos;
		return this;
	}

	public GhostBlockParams at(int x, int y, int z) {
		return this.at(new class_2338(x, y, z));
	}

	public GhostBlockParams alpha(Supplier<Float> alphaSupplier) {
		this.alphaSupplier = alphaSupplier;
		return this;
	}

	public GhostBlockParams alpha(float alpha) {
		return this.alpha(() -> alpha);
	}

	public GhostBlockParams breathingAlpha() {
		return this.alpha(() -> (float) GhostBlocks.getBreathingAlpha());
	}
}
