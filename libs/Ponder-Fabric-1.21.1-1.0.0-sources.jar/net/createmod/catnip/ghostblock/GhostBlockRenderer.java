package net.createmod.catnip.ghostblock;

import java.util.List;

import javax.annotation.Nullable;
import net.createmod.catnip.placement.PlacementClient;
import net.createmod.catnip.platform.CatnipClientServices;
import net.createmod.catnip.render.SuperRenderTypeBuffer;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_5819;
import net.minecraft.class_761;
import net.minecraft.class_776;
import net.minecraft.class_777;

public abstract class GhostBlockRenderer {

	private static final GhostBlockRenderer STANDARD = new DefaultGhostBlockRenderer();

	public static GhostBlockRenderer standard() {
		return STANDARD;
	}

	private static final GhostBlockRenderer TRANSPARENT = new TransparentGhostBlockRenderer();

	public static GhostBlockRenderer transparent() {
		return TRANSPARENT;
	}

	public abstract void render(class_4587 ms, SuperRenderTypeBuffer buffer, class_243 camera, GhostBlockParams params);

	private static class DefaultGhostBlockRenderer extends GhostBlockRenderer {

		@Override
		public void render(class_4587 ms, SuperRenderTypeBuffer buffer, class_243 camera, GhostBlockParams params) {
			ms.method_22903();

			class_776 dispatcher = class_310.method_1551().method_1541();

			class_2680 state = params.state;
			class_1087 model = dispatcher.method_3349(state);
			class_2338 pos = params.pos;

			ms.method_22904(pos.method_10263() - camera.field_1352, pos.method_10264() - camera.field_1351, pos.method_10260() - camera.field_1350);

			CatnipClientServices.CLIENT_HOOKS.renderVirtualBlockStateModel(model, ms, state, buffer::getEarlyBuffer);

			ms.method_22909();
		}

	}

	private static class TransparentGhostBlockRenderer extends GhostBlockRenderer {

		@Override
		public void render(class_4587 ms, SuperRenderTypeBuffer buffer, class_243 camera, GhostBlockParams params) {
			ms.method_22903();

			class_310 mc = class_310.method_1551();
			class_776 dispatcher = mc.method_1541();

			class_1087 model = dispatcher.method_3349(params.state);

			class_1921 layer = class_1921.method_23583();
			class_4588 vb = buffer.getEarlyBuffer(layer);

			class_2338 pos = params.pos;
			ms.method_22904(pos.method_10263() - camera.field_1352, pos.method_10264() - camera.field_1351, pos.method_10260() - camera.field_1350);

			ms.method_22904(.5, .5, .5);
			ms.method_22905(.85f, .85f, .85f);
			ms.method_22904(-.5, -.5, -.5);

			float alpha = params.alphaSupplier.get() * .75f * PlacementClient.getCurrentAlpha();
			renderModel(ms.method_23760(), vb, params.state, model, 1f, 1f, 1f, alpha,
				class_761.method_23794(mc.field_1687, pos), class_4608.field_21444);

			ms.method_22909();
		}

		// ModelBlockRenderer
		public void renderModel(class_4587.class_4665 pose, class_4588 consumer,
			@Nullable class_2680 state, class_1087 model, float red, float green, float blue,
			float alpha, int packedLight, int packedOverlay) {
			class_5819 random = class_5819.method_43047();

			for (class_2350 direction : class_2350.values()) {
				random.method_43052(42L);
				renderQuadList(pose, consumer, red, green, blue, alpha,
					model.method_4707(state, direction, random), packedLight, packedOverlay);
			}

			random.method_43052(42L);
			renderQuadList(pose, consumer, red, green, blue, alpha,
				model.method_4707(state, null, random), packedLight, packedOverlay);
		}

		// ModelBlockRenderer
		private static void renderQuadList(class_4587.class_4665 pose, class_4588 consumer,
			float red, float green, float blue, float alpha, List<class_777> quads,
			int packedLight, int packedOverlay) {
			for (class_777 quad : quads) {
				float f;
				float f1;
				float f2;
				if (quad.method_3360()) {
					f = class_3532.method_15363(red, 0.0F, 1.0F);
					f1 = class_3532.method_15363(green, 0.0F, 1.0F);
					f2 = class_3532.method_15363(blue, 0.0F, 1.0F);
				} else {
					f = 1.0F;
					f1 = 1.0F;
					f2 = 1.0F;
				}

				CatnipClientServices.CLIENT_HOOKS.vertexConsumerPutBulkDataWithAlpha(consumer, pose, quad, f, f1, f2, alpha, packedLight, packedOverlay);
			}

		}

	}

}
