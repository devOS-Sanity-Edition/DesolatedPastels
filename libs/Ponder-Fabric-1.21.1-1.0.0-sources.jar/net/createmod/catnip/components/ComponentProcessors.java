package net.createmod.catnip.components;

import net.minecraft.class_1799;
import net.minecraft.class_9331;
import net.minecraft.class_9334;
import net.minecraft.class_9336;

public class ComponentProcessors {
	public static class_1799 withUnsafeComponentsDiscarded(class_1799 stack) {
		if (stack.method_57380().method_57848())
			return stack;
		class_1799 copy = stack.method_7972();
		stack.method_57353()
				.method_57833()
				.filter(ComponentProcessors::isUnsafeItemComponent)
				.map(class_9336::comp_2443)
				.forEach(copy::method_57381);
		return copy;
	}

	public static boolean isUnsafeItemComponent(class_9336<?> component) {
		return isUnsafeItemComponent(component.comp_2443());
	}

	public static boolean isUnsafeItemComponent(class_9331<?> component) {
		if (component.equals(class_9334.field_49633))
			return false;
		if (component.equals(class_9334.field_49651))
			return false;
		if (component.equals(class_9334.field_49629))
			return false;
		if (component.equals(class_9334.field_49631))
			return false;
		return true;
	}
}
