@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package net.createmod.catnip.animation;

import javax.annotation.ParametersAreNonnullByDefault;
