package net.createmod.catnip.animation;

import net.minecraft.class_3532;

public class AnimationFunctions {
	// Approximations of some Web animation functions

	public static float easeOut(float t) {
		return class_3532.method_15374(class_3532.field_29845 * t);
	}

	public static float easeInOut(float t) {
		return (float) Math.pow(class_3532.method_15374(class_3532.field_29845 * t), 2);
	}

	public static float easeIn(float t) {
		return (float) Math.pow(t, 1.7);
	}
}
