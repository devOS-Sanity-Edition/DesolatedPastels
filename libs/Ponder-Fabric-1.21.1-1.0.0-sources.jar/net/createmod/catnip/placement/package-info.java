@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package net.createmod.catnip.placement;

import javax.annotation.ParametersAreNonnullByDefault;
