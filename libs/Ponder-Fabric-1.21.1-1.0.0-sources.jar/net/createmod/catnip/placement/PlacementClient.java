package net.createmod.catnip.placement;

import com.mojang.blaze3d.systems.RenderSystem;
import net.createmod.catnip.math.VecHelper;
import net.createmod.catnip.animation.LerpedFloat;
import net.createmod.catnip.math.AngleHelper;
import net.createmod.ponder.config.CClient;
import net.createmod.ponder.enums.PonderConfig;
import net.createmod.ponder.enums.PonderGuiTextures;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_638;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import org.joml.Matrix4f;

import javax.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class PlacementClient {

	static final LerpedFloat angle = LerpedFloat.angular()
		.chase(0, 0.25f, LerpedFloat.Chaser.EXP);
	@Nullable static class_2338 target = null;
	@Nullable static class_2338 lastTarget = null;
	static int animationTick = 0;

	public static void tick() {
		setTarget(null);
		checkHelpers();

		if (target == null) {
			if (animationTick > 0)
				animationTick = Math.max(animationTick - 2, 0);

			return;
		}

		if (animationTick < 10)
			animationTick++;

	}

	private static void checkHelpers() {
		class_310 mc = class_310.method_1551();
		class_638 world = mc.field_1687;

		if (world == null)
			return;

		if (!(mc.field_1765 instanceof class_3965 ray))
			return;

		if (mc.field_1724 == null)
			return;

		if (mc.field_1724.method_5715())// for now, disable all helpers when sneaking TODO add helpers that respect
										// sneaking but still show position
			return;

		for (class_1268 hand : class_1268.values()) {

			class_1799 heldItem = mc.field_1724.method_5998(hand);

			List<IPlacementHelper> filteredForHeldItem = new ArrayList<>();
			for (IPlacementHelper helper : PlacementHelpers.getHelpersView()) {
				if (helper.matchesItem(heldItem))
					filteredForHeldItem.add(helper);
			}

			if (filteredForHeldItem.isEmpty())
				continue;

			class_2338 pos = ray.method_17777();
			class_2680 state = world.method_8320(pos);

			List<IPlacementHelper> filteredForState = new ArrayList<>();
			for (IPlacementHelper helper : filteredForHeldItem) {
				if (helper.matchesState(state))
					filteredForState.add(helper);
			}

			if (filteredForState.isEmpty())
				continue;

			boolean atLeastOneMatch = false;
			for (IPlacementHelper h : filteredForState) {
				PlacementOffset offset = h.getOffset(mc.field_1724, world, state, pos, ray, heldItem);

				if (offset.isSuccessful()) {
					h.renderAt(pos, state, ray, offset);
					setTarget(offset.getBlockPos());
					atLeastOneMatch = true;
					break;
				}

			}

			// at least one helper activated, no need to check the offhand if we are still
			// in the mainhand
			if (atLeastOneMatch)
				return;

		}
	}

	static void setTarget(@Nullable class_2338 target) {
		PlacementClient.target = target;

		if (target == null)
			return;

		if (lastTarget == null) {
			lastTarget = target;
			return;
		}

		if (!lastTarget.equals(target))
			lastTarget = target;
	}

	public static void onRenderCrosshairOverlay(class_332 graphics, float partialTicks) {
		class_310 mc = class_310.method_1551();
		class_1657 player = mc.field_1724;

		if (player != null && animationTick > 0) {
			float screenY = graphics.method_51443() / 2f;
			float screenX = graphics.method_51421() / 2f;
			float progress = getCurrentAlpha();

			drawDirectionIndicator(graphics, partialTicks, screenX, screenY, progress);
		}
	}

	public static float getCurrentAlpha() {
		return Math.min(animationTick / 10f/* + event.getPartialTicks() */, 1f);
	}

	private static void drawDirectionIndicator(class_332 graphics, float partialTicks, float centerX, float centerY,
		float progress) {
		float r = .8f;
		float g = .8f;
		float b = .8f;
		float a = progress * progress;

		class_243 projTarget = VecHelper.projectToPlayerView(VecHelper.getCenterOf(lastTarget), partialTicks);

		class_243 target = new class_243(projTarget.field_1352, projTarget.field_1351, 0);
		if (projTarget.field_1350 > 0)
			target = target.method_22882();

		class_243 norm = target.method_1029();
		class_243 ref = new class_243(0, 1, 0);
		float targetAngle = AngleHelper.deg(-Math.acos(norm.method_1026(ref)));

		if (norm.field_1352 < 0)
			targetAngle = 360 - targetAngle;

		if (animationTick < 10)
			angle.setValue(targetAngle);

		angle.chase(targetAngle, .25f, LerpedFloat.Chaser.EXP);
		angle.tickChaser();

		float snapSize = 22.5f;
		float snappedAngle = (snapSize * Math.round(angle.getValue(0f) / snapSize)) % 360f;

		float length = 10;

		CClient.PlacementIndicatorSetting mode = PonderConfig.client().placementIndicator.get();
		class_4587 poseStack = graphics.method_51448();
		if (mode == CClient.PlacementIndicatorSetting.TRIANGLE)
			fadedArrow(poseStack, centerX, centerY, r, g, b, a, length, snappedAngle);
		else if (mode == CClient.PlacementIndicatorSetting.TEXTURE)
			textured(poseStack, centerX, centerY, a, snappedAngle);
	}

	private static void fadedArrow(class_4587 ms, float centerX, float centerY, float r, float g, float b, float a,
		float length, float snappedAngle) {
		//RenderSystem.disableTexture();
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.setShader(class_757::method_34540);

		ms.method_22903();
		ms.method_46416(centerX, centerY, 5);
		ms.method_22907(class_7833.field_40718.rotationDegrees(angle.getValue(0)));
		// RenderSystem.rotatef(snappedAngle, 0, 0, 1);
		double scale = PonderConfig.client().indicatorScale.get();
		ms.method_22905((float) scale, (float) scale, 1);

		class_289 tesselator = class_289.method_1348();
		class_287 bufferbuilder = tesselator.method_60827(class_293.class_5596.field_27381, class_290.field_1576);

		Matrix4f mat = ms.method_23760().method_23761();

		bufferbuilder.method_22918(mat, 0, -(10 + length), 0).method_22915(r, g, b, a);

		bufferbuilder.method_22918(mat, -9, -3, 0).method_22915(r, g, b, 0f);
		bufferbuilder.method_22918(mat, -6, -6, 0).method_22915(r, g, b, 0f);
		bufferbuilder.method_22918(mat, -3, -8, 0).method_22915(r, g, b, 0f);
		bufferbuilder.method_22918(mat, 0, -8.5f, 0).method_22915(r, g, b, 0f);
		bufferbuilder.method_22918(mat, 3, -8, 0).method_22915(r, g, b, 0f);
		bufferbuilder.method_22918(mat, 6, -6, 0).method_22915(r, g, b, 0f);
		bufferbuilder.method_22918(mat, 9, -3, 0).method_22915(r, g, b, 0f);

		class_286.method_43433(bufferbuilder.method_60800());
		RenderSystem.disableBlend();
		//RenderSystem.enableTexture();
		ms.method_22909();
	}

	public static void textured(class_4587 ms, float centerX, float centerY, float alpha, float snappedAngle) {
		//RenderSystem.enableTexture();
		PonderGuiTextures.PLACEMENT_INDICATOR_SHEET.bind();
		RenderSystem.enableDepthTest();
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.setShader(class_757::method_34543);

		ms.method_22903();
		ms.method_46416(centerX, centerY, 50);
		float scale = PonderConfig.client().indicatorScale.get()
			.floatValue() * .75f;
		ms.method_22905(scale, scale, 1);
		ms.method_22905(12, 12, 1);

		float index = snappedAngle / 22.5f;
		float tex_size = 16f / 256f;

		float tx = 0;
		float ty = index * tex_size;
		float tw = 1f;
		float th = tex_size;

		class_289 tesselator = class_289.method_1348();
		class_287 buffer = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1575);

		Matrix4f mat = ms.method_23760().method_23761();
		buffer.method_22918(mat, -1, -1, 0).method_22915(1f, 1f, 1f, alpha).method_22913(tx, ty);
		buffer.method_22918(mat, -1,  1, 0).method_22915(1f, 1f, 1f, alpha).method_22913(tx, ty + th);
		buffer.method_22918(mat,  1,  1, 0).method_22915(1f, 1f, 1f, alpha).method_22913(tx + tw, ty + th);
		buffer.method_22918(mat,  1, -1, 0).method_22915(1f, 1f, 1f, alpha).method_22913(tx + tw, ty);

		class_286.method_43433(buffer.method_60800());

		RenderSystem.disableBlend();
		ms.method_22909();
	}
}
