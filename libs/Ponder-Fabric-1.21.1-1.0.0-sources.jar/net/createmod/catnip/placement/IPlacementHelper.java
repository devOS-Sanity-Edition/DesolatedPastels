package net.createmod.catnip.placement;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

import net.createmod.catnip.data.Iterate;
import net.createmod.catnip.data.Pair;
import net.createmod.catnip.math.VecHelper;

import net.createmod.catnip.ghostblock.GhostBlocks;
import net.createmod.catnip.outliner.Outliner;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public interface IPlacementHelper {

	/**
	 * used as an identifier in SuperGlueHandler to skip blocks placed by helpers
	 */
	class_2680 ID = new class_2680(class_2246.field_10124, null, null);

	/**
	 * @return a predicate that gets tested with the items held in the players hands<br>
	 * should return true if this placement helper is active with the given item
	 */
	Predicate<class_1799> getItemPredicate();

	/**
	 * @return a predicate that gets tested with the blockstate the player is looking at<br>
	 * should return true if this placement helper is active with the given blockstate
	 */
	Predicate<class_2680> getStatePredicate();

	/**
	 *
	 * @param player the player that activated the placement helper
	 * @param world the world that the placement helper got activated in
	 * @param state the Blockstate of the Block that the player is looking at or clicked on
	 * @param pos the position of the Block the player is looking at or clicked on
	 * @param ray the exact raytrace result
	 *
	 * @return the PlacementOffset object describing where to place the new block.<br>
	 *     Use {@link PlacementOffset#fail} when no new position could be found.<br>
	 *     Use {@link PlacementOffset#success(class_2382)} with the new BlockPos to indicate a success
	 *     and call {@link PlacementOffset#withTransform(Function)} if the blocks default state has to be modified before it is placed
	 */
	PlacementOffset getOffset(class_1657 player, class_1937 world, class_2680 state, class_2338 pos, class_3965 ray);

	//sets the offset's ghost state with the default state of the held block item, this is used in PlacementHelpers and can be ignored in most cases
	default PlacementOffset getOffset(class_1657 player, class_1937 world, class_2680 state, class_2338 pos, class_3965 ray, class_1799 heldItem) {
		PlacementOffset offset = getOffset(player, world, state, pos, ray);
		if (heldItem.method_7909() instanceof class_1747 blockItem) {
			offset = offset.withGhostState(blockItem.method_7711().method_9564());
		}
		return offset;
	}

	/**
	 * overwrite this method if your placement helper needs a different rendering than the default ghost state
	 *
	 * @param pos the position of the Block the player is looking at or clicked on
	 * @param state the Blockstate of the Block that the player is looking at or clicked on
	 * @param ray the exact raytrace result
	 * @param offset the PlacementOffset returned by {@link #getOffset(class_1657, class_1937, class_2680, class_2338, class_3965)}<br>
	 *               the offset will always be successful if this method is called
	 */
	default void renderAt(class_2338 pos, class_2680 state, class_3965 ray, PlacementOffset offset) {
		displayGhost(offset);
	}

	//RIP
	static void renderArrow(class_243 center, class_243 target, class_2350 arrowPlane) {
		renderArrow(center, target, arrowPlane, 1D);
	}

	static void renderArrow(class_243 center, class_243 target, class_2350 arrowPlane, double distanceFromCenter) {
		class_243 direction = target.method_1020(center).method_1029();
		class_243 facing = class_243.method_24954(arrowPlane.method_10163());
		class_243 start = center.method_1019(direction);
		class_243 offset = direction.method_1021(distanceFromCenter - 1);
		class_243 offsetA = direction.method_1036(facing).method_1029().method_1021(.25);
		class_243 offsetB = facing.method_1036(direction).method_1029().method_1021(.25);
		class_243 endA = center.method_1019(direction.method_1021(.75)).method_1019(offsetA);
		class_243 endB = center.method_1019(direction.method_1021(.75)).method_1019(offsetB);
		Outliner.getInstance().showLine("placementArrowA" + center + target, start.method_1019(offset), endA.method_1019(offset)).lineWidth(1 / 16f);
		Outliner.getInstance().showLine("placementArrowB" + center + target, start.method_1019(offset), endB.method_1019(offset)).lineWidth(1 / 16f);
	}

	default void displayGhost(PlacementOffset offset) {
		if (!offset.hasGhostState())
			return;

		GhostBlocks.getInstance().showGhostState(this, offset.getTransform().apply(offset.getGhostState()))
				.at(offset.getBlockPos())
				.breathingAlpha();
	}

	static List<class_2350> orderedByDistanceOnlyAxis(class_2338 pos, class_243 hit, class_2350.class_2351 axis) {
		return orderedByDistance(pos, hit, dir -> dir.method_10166() == axis);
	}

	static List<class_2350> orderedByDistanceOnlyAxis(class_2338 pos, class_243 hit, class_2350.class_2351 axis, Predicate<class_2350> includeDirection) {
		return orderedByDistance(pos, hit, ((Predicate<class_2350>) dir -> dir.method_10166() == axis).and(includeDirection));
	}

	static List<class_2350> orderedByDistanceExceptAxis(class_2338 pos, class_243 hit, class_2350.class_2351 axis) {
		return orderedByDistance(pos, hit, dir -> dir.method_10166() != axis);
	}

	static List<class_2350> orderedByDistanceExceptAxis(class_2338 pos, class_243 hit, class_2350.class_2351 axis, Predicate<class_2350> includeDirection) {
		return orderedByDistance(pos, hit, ((Predicate<class_2350>) dir -> dir.method_10166() != axis).and(includeDirection));
	}

	static List<class_2350> orderedByDistanceExceptAxis(class_2338 pos, class_243 hit, class_2350.class_2351 first, class_2350.class_2351 second) {
		return orderedByDistanceExceptAxis(pos, hit, first, d -> d.method_10166() != second);
	}

	static List<class_2350> orderedByDistanceExceptAxis(class_2338 pos, class_243 hit, class_2350.class_2351 first, class_2350.class_2351 second, Predicate<class_2350> includeDirection) {
		return orderedByDistanceExceptAxis(pos, hit, first, ((Predicate<class_2350>) d -> d.method_10166() != second).and(includeDirection));
	}

	static List<class_2350> orderedByDistance(class_2338 pos, class_243 hit) {
		return orderedByDistance(pos, hit, _$ -> true);
	}

	static List<class_2350> orderedByDistance(class_2338 pos, class_243 hit, Predicate<class_2350> includeDirection) {
		List<class_2350> directions = new ArrayList<>();

		for (class_2350 dir : Iterate.directions) {
			if (includeDirection.test(dir)) {
				directions.add(dir);
			}
		}

		return orderedByDistance(pos, hit, directions);
	}

	static List<class_2350> orderedByDistance(class_2338 pos, class_243 hit, Collection<class_2350> directions) {
		class_243 centerToHit = hit.method_1020(VecHelper.getCenterOf(pos));

		List<Pair<class_2350, Double>> distances = new ArrayList<>();
		for (class_2350 dir : directions) {
			distances.add(Pair.of(dir, class_243.method_24954(dir.method_10163()).method_1022(centerToHit)));
		}

		distances.sort(Comparator.comparingDouble(Pair::getSecond));

		List<class_2350> sortedDirections = new ArrayList<>();
		for (Pair<class_2350, Double> p : distances) {
			sortedDirections.add(p.getFirst());
		}

		return sortedDirections;
	}

	default boolean matchesItem(class_1799 item) {
		return getItemPredicate().test(item);
	}

	default boolean matchesState(class_2680 state) {
		return getStatePredicate().test(state);
	}
}
