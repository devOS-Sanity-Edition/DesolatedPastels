@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package net.createmod.catnip.theme;

import javax.annotation.ParametersAreNonnullByDefault;
