package net.createmod.catnip.codecs.stream;

import java.lang.reflect.Array;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_2371;
import net.minecraft.class_2378;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_8703;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.mojang.datafixers.util.Pair;

import io.netty.buffer.ByteBuf;

public interface CatnipStreamCodecBuilders {
    static <T extends ByteBuf, S extends Enum<S>> class_9139<T, S> ofEnum(Class<S> clazz) {
        return new class_9139<>() {
            public @NotNull S decode(@NotNull T buffer) {
                return clazz.getEnumConstants()[class_8703.method_53016(buffer)];
            }

            public void encode(@NotNull T buffer, @NotNull S value) {
                class_8703.method_53017(buffer, value.ordinal());
            }
        };
    }

    static <B extends ByteBuf, L, R> class_9139<B, Pair<L, R>> pair(class_9139<B, L> codecL, class_9139<B, R> codecR) {
        return new class_9139<>() {
            @Override
            public @NotNull Pair<L, R> decode(B buffer) {
                L l = codecL.decode(buffer);
                R r = codecR.decode(buffer);
                return Pair.of(l, r);
            }

            @Override
            public void encode(B buffer, Pair<L, R> value) {
                codecL.encode(buffer, value.getFirst());
                codecR.encode(buffer, value.getSecond());
            }
        };
    }

    static <B extends ByteBuf, V> class_9139.class_9140<B, V, Optional<V>> optional() {
        return class_9135::method_56382;
    }

    static <B extends ByteBuf, V> class_9139<B, @Nullable V> nullable(class_9139<B, V> base) {
        return new class_9139<>() {
            @Override
            @SuppressWarnings("NullableProblems")
            public @Nullable V decode(@NotNull B buffer) {
				return class_2540.method_56893(buffer, base);
            }

            @Override
            public void encode(@NotNull B buffer, @Nullable V value) {
				class_2540.method_56892(buffer, value, base);
            }
        };
    }

    static <B extends ByteBuf, V> class_9139.class_9140<B, V, @Nullable V> nullable() {
        return CatnipStreamCodecBuilders::nullable;
    }

    static <B extends ByteBuf, V> class_9139<B, List<V>> list(class_9139<B, V> base) {
        return base.method_56433(class_9135.method_56363());
    }

    static <B extends ByteBuf, V> class_9139<B, List<V>> list(class_9139<B, V> base, int maxSize) {
        return base.method_56433(class_9135.method_58000(maxSize));
    }

    static <B extends ByteBuf, V> class_9139.class_9140<B, V, class_2371<V>> nonNullList() {
        return streamCodec -> class_9135.method_56376(class_2371::method_37434, streamCodec);
    }

    static <B extends ByteBuf, V> class_9139.class_9140<B, V, class_2371<V>> nonNullList(int maxSize) {
        return streamCodec -> class_9135.method_57991(class_2371::method_37434, streamCodec, maxSize);
    }

    static <B extends ByteBuf, V> class_9139<B, class_2371<V>> nonNullList(class_9139<B, V> base) {
        return base.method_56433(nonNullList());
    }

    static <B extends ByteBuf, V> class_9139<B, class_2371<V>> nonNullList(class_9139<B, V> base, int maxSize) {
        return base.method_56433(nonNullList(maxSize));
    }

    static <B extends class_2540, V> class_9139<B, V[]> array(class_9139<? super B, V> base, Class<?> clazz) {
        return new class_9139<>() {
            @Override
            public V @NotNull [] decode(@NotNull B buffer) {
                int size = buffer.method_10816();
                @SuppressWarnings("unchecked")
                V[] array = (V[]) Array.newInstance(clazz, size);
                for (int i = 0; i < size; i++) {
                    array[i] = base.decode(buffer);
                }
                return array;
            }

            @Override
            public void encode(@NotNull B buffer, @NotNull V[] value) {
                buffer.method_10804(value.length);
                for (V v : value) {
                    base.encode(buffer, v);
                }
            }
        };
    }

    static <B extends class_2540, V> class_9139.class_9140<B, V, V[]> array(Class<?> clazz) {
        return streamCodec -> array(streamCodec, clazz);
    }

	static <T> class_9139<ByteBuf, class_6862<T>> tagKey(class_5321<? extends class_2378<T>> registry) {
		return class_2960.field_48267.method_56432(id -> class_6862.method_40092(registry, id), class_6862::comp_327);
	}
}
