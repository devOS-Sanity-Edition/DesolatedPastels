package net.createmod.catnip.event;

import net.createmod.catnip.lang.LangNumberFormat;
import net.createmod.ponder.PonderClient;
import net.minecraft.class_3300;
import net.minecraft.class_4013;

public class ClientResourceReloadListener implements class_4013 {

	@Override
	public void method_14491(class_3300 resourceManager) {
		LangNumberFormat.numberFormat.update();
		PonderClient.invalidateRenderers();
	}

}
