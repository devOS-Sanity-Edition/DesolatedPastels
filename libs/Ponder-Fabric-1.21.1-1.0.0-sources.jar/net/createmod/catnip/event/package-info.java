@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package net.createmod.catnip.event;

import javax.annotation.ParametersAreNonnullByDefault;