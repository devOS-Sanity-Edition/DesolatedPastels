package net.createmod.catnip.render;

import java.util.function.Supplier;

import org.jetbrains.annotations.UnknownNullability;

import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
import net.fabricmc.fabric.api.renderer.v1.mesh.MutableQuadView;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_5819;

public final class BlendModeFilteringBakedModel extends ForwardingBakedModel {
	private static final ThreadLocal<BlendModeFilteringBakedModel> INSTANCE = ThreadLocal.withInitial(BlendModeFilteringBakedModel::new);

	public static class_1087 wrap(class_1087 model, BlendMode blendMode) {
		BlendModeFilteringBakedModel wrapper = INSTANCE.get();
		wrapper.wrapped = model;
		wrapper.blendMode = blendMode;
		return wrapper;
	}

	@UnknownNullability
	private BlendMode blendMode;

	private BlendModeFilteringBakedModel() {
	}

	private boolean transform(MutableQuadView quad) {
		return quad.material().blendMode() == this.blendMode;
	}

	@Override
	public boolean isVanillaAdapter() {
		return false;
	}

	@Override
	public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
		context.pushTransform(this::transform);
		super.emitBlockQuads(blockView, state, pos, randomSupplier, context);
		context.popTransform();
	}

	@Override
	public void emitItemQuads(class_1799 stack, Supplier<class_5819> randomSupplier, RenderContext context) {
		context.pushTransform(this::transform);
		super.emitItemQuads(stack, randomSupplier, context);
		context.popTransform();
	}
}
