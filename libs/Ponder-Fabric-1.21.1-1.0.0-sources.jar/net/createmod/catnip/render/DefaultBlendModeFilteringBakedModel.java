package net.createmod.catnip.render;

import java.util.function.Supplier;

import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadView;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_5819;

public final class DefaultBlendModeFilteringBakedModel extends ForwardingBakedModel {
	private static final ThreadLocal<DefaultBlendModeFilteringBakedModel> INSTANCE = ThreadLocal.withInitial(DefaultBlendModeFilteringBakedModel::new);

	public static class_1087 wrap(class_1087 model) {
		DefaultBlendModeFilteringBakedModel wrapper = INSTANCE.get();
		wrapper.wrapped = model;
		return wrapper;
	}

	public static boolean hasDefaultBlendMode(QuadView quad) {
		return quad.material().blendMode() == BlendMode.DEFAULT;
	}

	private DefaultBlendModeFilteringBakedModel() {
	}

	@Override
	public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
		context.pushTransform(DefaultBlendModeFilteringBakedModel::hasDefaultBlendMode);
		super.emitBlockQuads(blockView, state, pos, randomSupplier, context);
		context.popTransform();
	}

	@Override
	public void emitItemQuads(class_1799 stack, Supplier<class_5819> randomSupplier, RenderContext context) {
		context.pushTransform(DefaultBlendModeFilteringBakedModel::hasDefaultBlendMode);
		super.emitItemQuads(stack, randomSupplier, context);
		context.popTransform();
	}
}
