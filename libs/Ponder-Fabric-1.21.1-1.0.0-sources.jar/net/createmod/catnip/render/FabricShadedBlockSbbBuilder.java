package net.createmod.catnip.render;

import java.util.function.Supplier;
import org.jetbrains.annotations.Nullable;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import net.createmod.ponder.mixin.client.accessor.BufferBuilderAccessor;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_5819;
import net.minecraft.class_9799;
import net.minecraft.class_9801;

public class FabricShadedBlockSbbBuilder implements ShadedBlockSbbBuilder {
	private final WrapperModel wrapperModel = new WrapperModel();
	private final class_9799 byteBufferBuilder = new class_9799(512);
	private final IntList shadeSwapVertices = new IntArrayList();

	private class_287 bufferBuilder;
	private boolean currentShade;

	@Override
	public class_287 getBuffer(boolean shade) {
		this.swapShade(shade);
		return this.bufferBuilder;
	}

	@Override
	public void begin() {
		this.bufferBuilder = new class_287(this.byteBufferBuilder, class_293.class_5596.field_27382, class_290.field_1590);
		this.shadeSwapVertices.clear();
		this.currentShade = true;
	}

	@Override
	public void bufferBlock(class_1920 blockView, class_1087 model, class_2680 state, class_2338 pos, class_4587 stack, class_5819 random) {
		stack.method_22903();
		stack.method_46416(pos.method_10263(), pos.method_10264(), pos.method_10260());
		this.wrapperModel.setWrapped(model);
		class_310.method_1551().method_1541().method_3350()
			.method_3374(blockView, this.wrapperModel, state, pos, stack, this.bufferBuilder, true, random, state.method_26190(pos), class_4608.field_21444);
		stack.method_22909();
	}

	@Override
	public SuperByteBuffer end() {
		this.wrapperModel.setWrapped(null);

		class_9801 data = this.bufferBuilder.method_60794();
		TemplateMesh mesh;
		if (data != null) {
			mesh = new MutableTemplateMesh(data);
			data.close();
		} else {
			mesh = new TemplateMesh(0);
		}

		return new ShadeSeparatingSuperByteBuffer(mesh, this.shadeSwapVertices.toIntArray());
	}

	private void swapShade(boolean shade) {
		if (shade != this.currentShade) {
			this.shadeSwapVertices.add(((BufferBuilderAccessor) this.bufferBuilder).catnip$getVertices());
			this.currentShade = shade;
		}
	}

	private void prepareForGeometry(RenderMaterial material) {
		this.swapShade(!material.disableDiffuse());
	}

	private final class WrapperModel extends ForwardingBakedModel {
		private void setWrapped(@Nullable class_1087 wrapped) {
			this.wrapped = wrapped;
		}

		@Override
		public boolean isVanillaAdapter() {
			return false;
		}

		@Override
		public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
			context.pushTransform(quad -> {
				FabricShadedBlockSbbBuilder.this.prepareForGeometry(quad.material());
				return true;
			});
			super.emitBlockQuads(blockView, state, pos, randomSupplier, context);
			context.popTransform();
		}
	}
}
