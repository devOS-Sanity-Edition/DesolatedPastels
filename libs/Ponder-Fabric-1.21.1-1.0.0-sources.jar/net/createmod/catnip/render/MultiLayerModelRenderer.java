package net.createmod.catnip.render;

import java.util.function.Function;
import java.util.function.Supplier;

import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.UnknownNullability;
import dev.engine_room.flywheel.lib.model.baked.EmptyVirtualBlockGetter;
import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_4696;
import net.minecraft.class_5819;
import net.minecraft.class_777;

public class MultiLayerModelRenderer implements class_4588 {
	private static final ThreadLocal<MultiLayerModelRenderer> INSTANCE = ThreadLocal.withInitial(MultiLayerModelRenderer::new);

	public static void render(class_1087 model, class_4587 ms, class_2680 state, Function<class_1921, class_4588> bufferMap) {
		MultiLayerModelRenderer instance = INSTANCE.get();
		instance.prepare(bufferMap, class_4696.method_23679(state));

		class_310.method_1551().method_1541().method_3350()
			.method_3374(EmptyVirtualBlockGetter.FULL_BRIGHT, instance.wrapModel(model), state, class_2338.field_10980, ms, instance, false, class_5819.method_43047(), 42L, class_4608.field_21444);

		instance.clear();
	}

	private final WrapperModel wrapperModel = new WrapperModel();
	@UnknownNullability
	private Function<class_1921, class_4588> bufferMap;
	@UnknownNullability
	private class_1921 defaultLayer;

	@UnknownNullability
	private class_4588 bufferDelegate;

	private void prepare(Function<class_1921, class_4588> bufferMap, class_1921 defaultLayer) {
		this.bufferMap = bufferMap;
		this.defaultLayer = defaultLayer;
	}

	private void clear() {
		this.wrapperModel.setWrapped(null);
	}

	private class_1087 wrapModel(class_1087 model) {
		this.wrapperModel.setWrapped(model);
		return this.wrapperModel;
	}

	private void prepareForGeometry(RenderMaterial material) {
		BlendMode blendMode = material.blendMode();
		this.bufferDelegate = this.bufferMap.apply(blendMode == BlendMode.DEFAULT ? this.defaultLayer : blendMode.blockRenderLayer);
	}

	public class_4588 method_22912(float x, float y, float z) {
		this.bufferDelegate.method_22912(x, y, z);
		return this;
	}

	public class_4588 method_1336(int red, int green, int blue, int alpha) {
		this.bufferDelegate.method_1336(red, green, blue, alpha);
		return this;
	}

	public class_4588 method_22913(float u, float v) {
		this.bufferDelegate.method_22913(u, v);
		return this;
	}

	public class_4588 method_60796(int u, int v) {
		this.bufferDelegate.method_60796(u, v);
		return this;
	}

	public class_4588 method_22921(int u, int v) {
		this.bufferDelegate.method_22921(u, v);
		return this;
	}

	public class_4588 method_22914(float x, float y, float z) {
		this.bufferDelegate.method_22914(x, y, z);
		return this;
	}

	public void method_23919(float x, float y, float z, int color, float u, float v, int packedOverlay, int packedLight, float normalX, float normalY, float normalZ) {
		this.bufferDelegate.method_23919(x, y, z, color, u, v, packedOverlay, packedLight, normalX, normalY, normalZ);
	}

	public void method_22919(class_4587.class_4665 pose, class_777 quad, float red, float green, float blue, float alpha, int packedLight, int packedOverlay) {
		this.bufferDelegate.method_22919(pose, quad, red, green, blue, alpha, packedLight, packedOverlay);
	}

	public void method_22920(class_4587.class_4665 pose, class_777 quad, float[] brightness, float red, float green, float blue, float alpha, int[] lightmap, int packedOverlay, boolean readAlpha) {
		this.bufferDelegate.method_22920(pose, quad, brightness, red, green, blue, alpha, lightmap, packedOverlay, readAlpha);
	}

	private final class WrapperModel extends ForwardingBakedModel {
		private void setWrapped(@Nullable class_1087 wrapped) {
			this.wrapped = wrapped;
		}

		@Override
		public boolean isVanillaAdapter() {
			return false;
		}

		@Override
		public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
			context.pushTransform(quad -> {
				MultiLayerModelRenderer.this.prepareForGeometry(quad.material());
				return true;
			});
			super.emitBlockQuads(blockView, state, pos, randomSupplier, context);
			context.popTransform();
		}
	}
}
