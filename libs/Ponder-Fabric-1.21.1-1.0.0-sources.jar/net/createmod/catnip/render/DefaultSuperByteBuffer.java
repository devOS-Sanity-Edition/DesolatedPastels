package net.createmod.catnip.render;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import javax.annotation.Nullable;
import net.minecraft.class_1920;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_761;
import net.minecraft.class_9801;
import org.joml.Matrix3f;
import org.joml.Matrix3fc;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionfc;
import org.joml.Vector3f;
import org.joml.Vector4f;
import it.unimi.dsi.fastutil.longs.Long2IntMap;
import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;

@SuppressWarnings("unchecked")
public class DefaultSuperByteBuffer implements SuperByteBuffer {

	protected ByteBuffer template;
	protected int formatSize;

	// Vertex Position
	protected class_4587 transforms;

	// Vertex Coloring
	protected boolean shouldColor;
	protected int r, g, b, a;
	protected boolean disableDiffuse;

	// Vertex Texture Coordinates
	@Nullable protected SpriteShiftFunc spriteShiftFunc;

	// Vertex Overlay Color
	protected boolean hasOverlay;
	protected int overlay = class_4608.field_21444;

	// Vertex Lighting
	protected boolean useWorldLight;
	@Nullable protected Matrix4f lightTransform;
	protected boolean hasCustomLight;
	protected int packedLightCoordinates;
	protected boolean hybridLight;

	// Vertex Normals
	protected boolean fullNormalTransform;

	// Temporary
	protected static final Long2IntMap WORLD_LIGHT_CACHE = new Long2IntOpenHashMap();

	private final ShiftOutput shiftOutput = new ShiftOutput();


	public DefaultSuperByteBuffer(class_9801 data) {
		ByteBuffer rendered = data.method_60818();
		class_9801.class_4574 drawState = data.method_60822();

		// Vanilla issue, endianness does not carry over into sliced buffers - fixed by forge only
		rendered.order(ByteOrder.nativeOrder());

		drawState.comp_749().method_1362();
		formatSize = drawState.comp_749().method_1362();
		int size = drawState.comp_750() * formatSize;

		template = ByteBuffer.allocateDirect(size).order(ByteOrder.nativeOrder());
		template.order(rendered.order());
		template.limit(rendered.limit());
		template.put(rendered);

		transforms = new class_4587();
		transforms.method_22903();
	}

	@Override
	public void renderInto(class_4587 ms, class_4588 consumer) {
		if (isEmpty())
			return;

		Matrix4f modelMatrix = new Matrix4f(ms.method_23760().method_23761());
		Matrix4f localTransforms = transforms.method_23760().method_23761();
		modelMatrix.mul(localTransforms);

		Matrix3f normalMatrix;
		if (fullNormalTransform) {
			normalMatrix = new Matrix3f(ms.method_23760().method_23762());
			normalMatrix.mul(transforms.method_23760().method_23762());
		} else {
			normalMatrix = new Matrix3f(transforms.method_23760().method_23762());
		}

		for (int i = 0; i < vertexCount(); i++) {
			float x = getX(i);
			float y = getY(i);
			float z = getZ(i);

			float normalX = getNX(i);
			float normalY = getNY(i);
			float normalZ = getNZ(i);

			Vector4f pos = new Vector4f(x, y, z, 1F);
			Vector3f normal = new Vector3f(normalX, normalY, normalZ);
			Vector4f lightPos = new Vector4f(x, y, z, 1F);
			pos.mul(modelMatrix);
			normal.mul(normalMatrix);
			lightPos.mul(localTransforms);

			consumer.method_22912(pos.x(), pos.y(), pos.z());

			byte r, g, b, a;
			if (shouldColor) {
				r = (byte) this.r;
				g = (byte) this.g;
				b = (byte) this.b;
				a = (byte) this.a;
			} else {
				r = getR(i);
				g = getG(i);
				b = getB(i);
				a = getA(i);
			}
			if (disableDiffuse) {
				consumer.method_1336(r, g, b, a);
			} else {
				// missing flywheel's diffuse calc stuff
				consumer.method_1336(r, g, b, a);
			}
			float u = getU(i);
			float v = getV(i);

			if (spriteShiftFunc != null) {
				spriteShiftFunc.shift(u, v, shiftOutput);
				u = shiftOutput.u;
				v = shiftOutput.v;
			}

			consumer.method_22913(u, v);

			int light;
			if (useWorldLight) {
				lightPos.set(((x - .5f) * 15 / 16f) + .5f, (y - .5f) * 15 / 16f + .5f, (z - .5f) * 15 / 16f + .5f, 1f);
				lightPos.mul(localTransforms);
				if (lightTransform != null) {
					lightPos.mul(lightTransform);
				}

				light = getLight(class_310.method_1551().field_1687, lightPos);
				if (hasCustomLight) {
					light = SuperByteBuffer.maxLight(light, packedLightCoordinates);
				}
			} else if (hasCustomLight) {
				light = packedLightCoordinates;
			} else {
				light = getLight(i);
			}

			if (hybridLight) {
				consumer.method_60803(SuperByteBuffer.maxLight(light, getLight(i)));
			} else {
				consumer.method_60803(light);
			}

			consumer.method_22914(normal.x(), normal.y(), normal.z());
		}

		reset();

	}

	@Override
	public DefaultSuperByteBuffer reset() {
		while (!transforms.method_22911())
			transforms.method_22909();

		transforms.method_22903();

		shouldColor = false;
		r = 0;
		g = 0;
		b = 0;
		a = 0;
		disableDiffuse = false;
		spriteShiftFunc = null;
		hasOverlay = false;
		overlay = class_4608.field_21444;
		useWorldLight = false;
		lightTransform = null;
		hasCustomLight = false;
		packedLightCoordinates = 0;
		hybridLight = false;
		fullNormalTransform = false;

		WORLD_LIGHT_CACHE.clear();

		return this;
	}

	@Override
	public boolean isEmpty() {
		return template.limit() == 0;
	}

	@Override
	public class_4587 getTransforms() {
		return transforms;
	}

	@Override
	public DefaultSuperByteBuffer translate(float x, float y, float z) {
		transforms.method_46416(x, y, z);
		return this;
	}

	@Override
	public DefaultSuperByteBuffer translate(double x, double y, double z) {
		transforms.method_22904(x, y, z);
		return this;
	}

	@Override
	public DefaultSuperByteBuffer scale(float factorX, float factorY, float factorZ) {
		transforms.method_22905(factorX, factorY, factorZ);

		return this;
	}

	@Override
	public DefaultSuperByteBuffer pushPose() {
		transforms.method_22903();
		return this;
	}

	@Override
	public DefaultSuperByteBuffer popPose() {
		transforms.method_22909();
		return this;
	}

	@Override
	public DefaultSuperByteBuffer mulPose(Matrix4fc matrix4fc) {
		transforms.method_23760().method_23761().mul(matrix4fc);
		return this;
	}

	@Override
	public DefaultSuperByteBuffer mulNormal(Matrix3fc matrix3fc) {
		transforms.method_23760().method_23762().mul(matrix3fc);
		return this;
	}

	@Override
	public DefaultSuperByteBuffer transform(class_4587 ms) {
		transforms.method_23760()
				.method_23761()
				.mul(ms.method_23760().method_23761());
		transforms.method_23760()
				.method_23762()
				.mul(ms.method_23760().method_23762());
		return this;
	}

	@Override
	public DefaultSuperByteBuffer color(int color) {
		shouldColor = true;
		r = ((color >> 16) & 0xFF);
		g = ((color >> 8) & 0xFF);
		b = (color & 0xFF);
		a = 255;
		return this;
	}

	@Override
	public DefaultSuperByteBuffer color(int r, int g, int b, int a) {
		shouldColor = true;
		this.r = r;
		this.g = g;
		this.b = b;
		this.a = a;
		return this;
	}

	@Override
	public DefaultSuperByteBuffer disableDiffuse() {
		disableDiffuse = true;
		return this;
	}

	@Override
	public DefaultSuperByteBuffer shiftUV(SpriteShiftEntry entry) {
		spriteShiftFunc = (u, v, output) -> output.accept(entry.getTargetU(u), entry.getTargetV(v));
		return this;
	}

	@Override
	public DefaultSuperByteBuffer shiftUVScrolling(SpriteShiftEntry entry, float scrollU, float scrollV) {
		spriteShiftFunc = (u, v, output) -> {
			float targetU = u - entry.getOriginal()
				.method_4594() + entry.getTarget()
				.method_4594()
				+ scrollU;
			float targetV = v - entry.getOriginal()
				.method_4593() + entry.getTarget()
				.method_4593()
				+ scrollV;
			output.accept(targetU, targetV);
		};
		return this;
	}

	@Override
	public DefaultSuperByteBuffer shiftUVtoSheet(SpriteShiftEntry entry, float uTarget, float vTarget, int sheetSize) {
		spriteShiftFunc = (u, v, output) -> {
			float targetU = entry.getTarget()
				.method_4580((SpriteShiftEntry.getUnInterpolatedU(entry.getOriginal(), u) / sheetSize) + uTarget);
			float targetV = entry.getTarget()
				.method_4570((SpriteShiftEntry.getUnInterpolatedV(entry.getOriginal(), v) / sheetSize) + vTarget);
			output.accept(targetU, targetV);
		};
		return this;
	}

	@Override
	public DefaultSuperByteBuffer overlay(int overlay) {
		hasOverlay = true;
		this.overlay = overlay;
		return this;
	}

	@Override
	public DefaultSuperByteBuffer useLevelLight(class_1920 level) {
		return this;
	}

	@Override
	public DefaultSuperByteBuffer useLevelLight(class_1920 level, Matrix4f lightTransform) {
		return this;
	}

	@Override
	public DefaultSuperByteBuffer light(int packedLight) {
		hasCustomLight = true;
		this.packedLightCoordinates = packedLight;
		return this;
	}

	//

	protected int vertexCount() {
		return template.limit() / formatSize;
	}

	protected int getBufferPosition(int vertexIndex) {
		return vertexIndex * formatSize;
	}

	protected float getX(int index) {
		return template.getFloat(getBufferPosition(index));
	}

	protected float getY(int index) {
		return template.getFloat(getBufferPosition(index) + 4);
	}

	protected float getZ(int index) {
		return template.getFloat(getBufferPosition(index) + 8);
	}

	protected byte getR(int index) {
		return template.get(getBufferPosition(index) + 12);
	}

	protected byte getG(int index) {
		return template.get(getBufferPosition(index) + 13);
	}

	protected byte getB(int index) {
		return template.get(getBufferPosition(index) + 14);
	}

	protected byte getA(int index) {
		return template.get(getBufferPosition(index) + 15);
	}

	protected float getU(int index) {
		return template.getFloat(getBufferPosition(index) + 16);
	}

	protected float getV(int index) {
		return template.getFloat(getBufferPosition(index) + 20);
	}

	protected int getLight(int index) {
		return template.getInt(getBufferPosition(index) + 24);
	}

	protected byte getNX(int index) {
		return template.get(getBufferPosition(index) + 28);
	}

	protected byte getNY(int index) {
		return template.get(getBufferPosition(index) + 29);
	}

	protected byte getNZ(int index) {
		return template.get(getBufferPosition(index) + 30);
	}

	private static int getLight(class_1937 world, Vector4f lightPos) {
		class_2338 pos = class_2338.method_49637(lightPos.x(), lightPos.y(), lightPos.z());
		return WORLD_LIGHT_CACHE.computeIfAbsent(pos.method_10063(), $ -> class_761.method_23794(world, pos));
	}

	@Override
	public SuperByteBuffer rotate(Quaternionfc quaternionfc) {
		return null;
	}
}
