package net.createmod.catnip.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_2960;

public interface BindableTexture {

	default void bind() {
		RenderSystem.setShaderTexture(0, getLocation());
	}

	class_2960 getLocation();

}
