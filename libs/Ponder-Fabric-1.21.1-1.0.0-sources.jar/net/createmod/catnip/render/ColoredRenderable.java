package net.createmod.catnip.render;

import net.createmod.catnip.theme.Color;
import net.minecraft.class_332;

public interface ColoredRenderable {

	void render(class_332 graphics, int x, int y, Color c);

}
