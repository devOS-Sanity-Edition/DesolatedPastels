package net.createmod.catnip.render;

import java.util.function.BiFunction;
import net.createmod.ponder.Ponder;
import net.createmod.ponder.enums.PonderSpecialTextures;
import net.createmod.ponder.mixin.client.accessor.RenderTypeAccessor;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4668;

public abstract class PonderRenderTypes extends class_1921 {

	private static final class_1921 OUTLINE_SOLID =
		RenderTypeAccessor.catnip$create(createLayerName("outline_solid"), class_290.field_1580, class_293.class_5596.field_27382, 256, false, false, class_1921.class_4688.method_23598()
			.method_34578(field_29450)
			.method_34577(new class_4668.class_4683(PonderSpecialTextures.BLANK.getLocation(), false, false))
			.method_23603(field_21344)
			.method_23608(field_21383)
			.method_23611(field_21385)
			.method_23617(false));

	private static final BiFunction<class_2960, Boolean, class_1921> OUTLINE_TRANSLUCENT = class_156.method_34865((texture, cull) ->
		RenderTypeAccessor.catnip$create(createLayerName("outline_translucent" + (cull ? "_cull" : "")), class_290.field_1580, class_293.class_5596.field_27382, 256, false, true, class_4688.method_23598()
			.method_34578(cull ? field_29406 : field_29407)
			.method_34577(new class_4683(texture, false, false))
			.method_23615(field_21370)
			.method_23603(cull ? field_21344 : field_21345)
			.method_23608(field_21383)
			.method_23611(field_21385)
			.method_23616(field_21350)
			.method_23617(false)));

	private static final class_1921 FLUID =
		RenderTypeAccessor.catnip$create(createLayerName("fluid"), class_290.field_1590, class_293.class_5596.field_27382, 256, false, true, class_1921.class_4688.method_23598()
			.method_34578(field_29446)
			.method_34577(field_21376)
			.method_23615(field_21370)
			.method_23608(field_21383)
			//.setOverlayState(NO_OVERLAY)
			.method_23617(true));

	public static class_1921 outlineSolid() {
		return OUTLINE_SOLID;
	}

	public static class_1921 outlineTranslucent(class_2960 texture, boolean cull) {
		return OUTLINE_TRANSLUCENT.apply(texture, cull);
	}

	//TODO vanilla uses the translucent render type for fluids, need to investigate if this is even needed
	public static class_1921 fluid() {
		return FLUID;
	}

	private static String createLayerName(String name) {
		return Ponder.MOD_ID + ":" + name;
	}

	private PonderRenderTypes(String name, class_293 format, class_293.class_5596 mode, int bufferSize, boolean affectsCrumbling, boolean sortOnUpload, Runnable setupState, Runnable clearState) {
		super(name, format, mode, bufferSize, affectsCrumbling, sortOnUpload, setupState, clearState);
	}
}
