package net.createmod.catnip.render;

import net.createmod.catnip.platform.CatnipClientServices;
import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_287;
import net.minecraft.class_4587;
import net.minecraft.class_5819;

public interface ShadedBlockSbbBuilder {
	static ShadedBlockSbbBuilder create() {
		return CatnipClientServices.CLIENT_HOOKS.createSbbBuilder();
	}


	class_287 getBuffer(boolean shade);

	void begin();
	void bufferBlock(class_1920 blockView, class_1087 model, class_2680 state, class_2338 pos, class_4587 stack, class_5819 random);
	SuperByteBuffer end();
}
