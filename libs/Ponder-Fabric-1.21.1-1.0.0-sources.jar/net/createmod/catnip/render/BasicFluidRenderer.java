package net.createmod.catnip.render;

import net.createmod.catnip.platform.CatnipServices;
import net.minecraft.class_1058;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3611;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_9326;
import net.createmod.catnip.data.Iterate;
import org.jetbrains.annotations.Nullable;

public class BasicFluidRenderer {

	public static class_4588 getFluidBuilder(class_4597 buffer) {
		return buffer.getBuffer(PonderRenderTypes.fluid());
	}

	public static void renderFluidBox(class_3611 fluid, long amount, float xMin, float yMin, float zMin, float xMax,
									  float yMax, float zMax, class_4597 buffer, class_4587 ms, int light, boolean renderBottom, boolean invertGasses) {
		renderFluidBox(fluid, amount, xMin, yMin, zMin, xMax, yMax, zMax, getFluidBuilder(buffer), ms, light, renderBottom, invertGasses, null);
	}

	public static void renderFluidBox(class_3611 fluid, long amount, float xMin, float yMin, float zMin, float xMax,
									  float yMax, float zMax, class_4588 builder, class_4587 ms, int light, boolean renderBottom, boolean invertGasses) {
		renderFluidBox(fluid, amount, xMin, yMin, zMin, xMax, yMax, zMax, builder, ms, light, renderBottom, invertGasses, null);
	}

	public static void renderFluidBox(class_3611 fluid, long amount, float xMin, float yMin, float zMin, float xMax,
									  float yMax, float zMax, class_4597 buffer, class_4587 ms, int light, boolean renderBottom, boolean invertGasses, @Nullable class_9326 fluidData) {
		renderFluidBox(fluid, amount, xMin, yMin, zMin, xMax, yMax, zMax, getFluidBuilder(buffer), ms, light, renderBottom, invertGasses, fluidData);
	}

	public static void renderFluidBox(class_3611 fluid, long amount, float xMin, float yMin, float zMin, float xMax,
			float yMax, float zMax, class_4588 builder, class_4587 ms, int light, boolean renderBottom, boolean invertGasses, @Nullable class_9326 fluidData) {
		class_1058 fluidTexture = CatnipServices.FLUID_HELPER.getStillTexture(fluid, amount, fluidData);
		if (fluidTexture == null)
			return;

		int color = CatnipServices.FLUID_HELPER.getColor(fluid, amount, fluidData);
		int blockLightIn = (light >> 4) & 0xF;
		int luminosity = Math.max(blockLightIn, CatnipServices.FLUID_HELPER.getLuminosity(fluid, amount, fluidData));
		light = (light & 0xF00000) | luminosity << 4;

		class_243 center = new class_243(xMin + (xMax - xMin) / 2, yMin + (yMax - yMin) / 2, zMin + (zMax - zMin) / 2);
		ms.method_22903();
		if (invertGasses && CatnipServices.FLUID_HELPER.isLighterThanAir(fluid)) {
			ms.method_22904(center.field_1352, center.field_1351, center.field_1350);
			ms.method_22907(class_7833.field_40714.rotationDegrees(180));
			ms.method_22904(-center.field_1352, -center.field_1351, -center.field_1350);
		}

		for (class_2350 side : Iterate.directions) {
			if (side == class_2350.field_11033 && !renderBottom)
				continue;

			boolean positive = side.method_10171() == class_2350.class_2352.field_11056;
			if (side.method_10166()
				.method_10179()) {
				if (side.method_10166() == class_2350.class_2351.field_11048) {
					renderStillTiledFace(side, zMin, yMin, zMax, yMax, positive ? xMax : xMin,
						builder, ms, light, color, fluidTexture);
				} else {
					renderStillTiledFace(side, xMin, yMin, xMax, yMax, positive ? zMax : zMin,
						builder, ms, light, color, fluidTexture);
				}
			} else {
				renderStillTiledFace(side, xMin, zMin, xMax, zMax, positive ? yMax : yMin,
					builder, ms, light, color, fluidTexture);
			}
		}

		ms.method_22909();
	}

	public static void renderStillTiledFace(class_2350 dir, float left, float down, float right, float up,
											float depth, class_4588 builder, class_4587 ms, int light, int color, class_1058 texture) {
		renderTiledFace(dir, left, down, right, up, depth, builder, ms, light, color, texture, 1);
	}

	public static void renderTiledFace(class_2350 dir, float left, float down, float right, float up,
									   float depth, class_4588 builder, class_4587 ms, int light, int color, class_1058 texture,
									   float textureScale) {
		boolean positive = dir.method_10171() == class_2350.class_2352.field_11056;
		boolean horizontal = dir.method_10166().method_10179();
		boolean x = dir.method_10166() == class_2350.class_2351.field_11048;

		float shrink = texture.method_23842() * 0.25f * textureScale;
		float centerU = texture.method_4594() + (texture.method_4577() - texture.method_4594()) * 0.5f * textureScale;
		float centerV = texture.method_4593() + (texture.method_4575() - texture.method_4593()) * 0.5f * textureScale;

		float f;
		float x2 = 0;
		float y2 = 0;
		float u1, u2;
		float v1, v2;
		for (float x1 = left; x1 < right; x1 = x2) {
			f = class_3532.method_15375(x1);
			x2 = Math.min(f + 1, right);
			if (dir == class_2350.field_11043 || dir == class_2350.field_11034) {
				f = class_3532.method_15386(x2);
				u1 = texture.method_4580((f - x2) * textureScale);
				u2 = texture.method_4580((f - x1) * textureScale);
			} else {
				u1 = texture.method_4580((x1 - f) * textureScale);
				u2 = texture.method_4580((x2 - f) * textureScale);
			}
			u1 = class_3532.method_16439(shrink, u1, centerU);
			u2 = class_3532.method_16439(shrink, u2, centerU);
			for (float y1 = down; y1 < up; y1 = y2) {
				f = class_3532.method_15375(y1);
				y2 = Math.min(f + 1, up);
				if (dir == class_2350.field_11036) {
					v1 = texture.method_4570((y1 - f) * textureScale);
					v2 = texture.method_4570((y2 - f) * textureScale);
				} else {
					f = class_3532.method_15386(y2);
					v1 = texture.method_4570((f - y2) * textureScale);
					v2 = texture.method_4570((f - y1) * textureScale);
				}
				v1 = class_3532.method_16439(shrink, v1, centerV);
				v2 = class_3532.method_16439(shrink, v2, centerV);

				if (horizontal) {
					if (x) {
						putVertex(builder, ms, depth, y2, positive ? x2 : x1, color, u1, v1, dir, light);
						putVertex(builder, ms, depth, y1, positive ? x2 : x1, color, u1, v2, dir, light);
						putVertex(builder, ms, depth, y1, positive ? x1 : x2, color, u2, v2, dir, light);
						putVertex(builder, ms, depth, y2, positive ? x1 : x2, color, u2, v1, dir, light);
					} else {
						putVertex(builder, ms, positive ? x1 : x2, y2, depth, color, u1, v1, dir, light);
						putVertex(builder, ms, positive ? x1 : x2, y1, depth, color, u1, v2, dir, light);
						putVertex(builder, ms, positive ? x2 : x1, y1, depth, color, u2, v2, dir, light);
						putVertex(builder, ms, positive ? x2 : x1, y2, depth, color, u2, v1, dir, light);
					}
				} else {
					putVertex(builder, ms, x1, depth, positive ? y1 : y2, color, u1, v1, dir, light);
					putVertex(builder, ms, x1, depth, positive ? y2 : y1, color, u1, v2, dir, light);
					putVertex(builder, ms, x2, depth, positive ? y2 : y1, color, u2, v2, dir, light);
					putVertex(builder, ms, x2, depth, positive ? y1 : y2, color, u2, v1, dir, light);
				}
			}
		}
	}

	protected static void putVertex(class_4588 builder, class_4587 ms, float x, float y, float z, int color, float u,
									float v, class_2350 face, int light) {

		class_2382 normal = face.method_10163();
		class_4587.class_4665 peek = ms.method_23760();
		int a = color >> 24 & 0xff;
		int r = color >> 16 & 0xff;
		int g = color >> 8 & 0xff;
		int b = color & 0xff;

		builder.method_22918(peek.method_23761(), x, y, z)
			.method_1336(r, g, b, a)
			.method_22913(u, v)
			//.overlayCoords(OverlayTexture.NO_OVERLAY)
			.method_60803(light)
			.method_60831(peek.method_56822(), normal.method_10263(), normal.method_10264(), normal.method_10260())
		;
	}

	}
