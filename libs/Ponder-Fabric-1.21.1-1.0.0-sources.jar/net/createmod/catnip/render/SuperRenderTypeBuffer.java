package net.createmod.catnip.render;

import net.minecraft.class_1921;
import net.minecraft.class_4588;
import net.minecraft.class_4597;

public interface SuperRenderTypeBuffer extends class_4597 {
	class_4588 getEarlyBuffer(class_1921 type);

	class_4588 getBuffer(class_1921 type);

	class_4588 getLateBuffer(class_1921 type);

	void draw();

	void draw(class_1921 type);
}
