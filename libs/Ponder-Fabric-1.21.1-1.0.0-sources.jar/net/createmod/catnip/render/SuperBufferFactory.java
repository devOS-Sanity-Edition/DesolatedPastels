package net.createmod.catnip.render;

import javax.annotation.Nullable;
import net.minecraft.class_1087;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_5819;
import net.minecraft.class_9801;
import dev.engine_room.flywheel.lib.model.baked.EmptyVirtualBlockGetter;

public class SuperBufferFactory {

	private static final ThreadLocal<ThreadLocalObjects> THREAD_LOCAL_OBJECTS = ThreadLocal.withInitial(ThreadLocalObjects::new);

	public static final SuperBufferFactory INSTANCE = new SuperBufferFactory();

	public SuperByteBuffer create(class_9801 data) {
		return new DefaultSuperByteBuffer(data);
	}

	public SuperByteBuffer createForBlock(class_2680 renderedState) {
		return createForBlock(class_310.method_1551().method_1541().method_3349(renderedState), renderedState);
	}

	public SuperByteBuffer createForBlock(class_1087 model, class_2680 referenceState) {
		return createForBlock(model, referenceState, new class_4587());
	}

	public SuperByteBuffer createForBlock(class_1087 model, class_2680 state, @Nullable class_4587 poseStack) {
		ThreadLocalObjects objects = THREAD_LOCAL_OBJECTS.get();

		if (poseStack == null) {
			poseStack = objects.identityPoseStack;
		}
		class_5819 random = objects.random;

		ShadedBlockSbbBuilder sbbBuilder = objects.sbbBuilder;
		sbbBuilder.begin();
		sbbBuilder.bufferBlock(EmptyVirtualBlockGetter.FULL_DARK, model, state, class_2338.field_10980, poseStack, random);
		return sbbBuilder.end();
	}

	private static class ThreadLocalObjects {
		public final class_4587 identityPoseStack = new class_4587();
		public final class_5819 random = class_5819.method_43053();
		public final ShadedBlockSbbBuilder sbbBuilder = ShadedBlockSbbBuilder.create();
	}
}
