@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package net.createmod.catnip.lang;

import javax.annotation.ParametersAreNonnullByDefault;
