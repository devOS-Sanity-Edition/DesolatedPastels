package net.createmod.catnip.lang;

import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.google.common.base.Strings;

import net.createmod.catnip.platform.CatnipClientServices;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_5250;
import net.createmod.catnip.data.Couple;

public final class FontHelper {

	public static final int MAX_WIDTH_PER_LINE = 200;

	private FontHelper() {}

	public static class_2583 styleFromColor(class_124 color) {
		return class_2583.field_24360.method_27706(color);
	}

	public static class_2583 styleFromColor(int hex) {
		return class_2583.field_24360.method_36139(hex);
	}

	public static List<class_2561> cutStringTextComponent(String s, Palette palette) {
		return cutTextComponent(class_2561.method_43470(s), palette);
	}

	public static List<class_2561> cutTextComponent(class_2561 c, Palette palette) {
		return cutTextComponent(c, palette.primary(), palette.highlight());
	}

	public static List<class_2561> cutStringTextComponent(String s, class_2583 primaryStyle,
														 class_2583 highlightStyle) {
		return cutTextComponent(class_2561.method_43470(s), primaryStyle, highlightStyle);
	}

	public static List<class_2561> cutTextComponent(class_2561 c, class_2583 primaryStyle,
												   class_2583 highlightStyle) {
		return cutTextComponent(c, primaryStyle, highlightStyle, 0);
	}

	public static List<class_2561> cutStringTextComponent(String c, class_2583 primaryStyle,
														 class_2583 highlightStyle, int indent) {
		return cutTextComponent(class_2561.method_43470(c), primaryStyle, highlightStyle, indent);
	}

	public static List<class_2561> cutTextComponent(class_2561 c, class_2583 primaryStyle,
												   class_2583 highlightStyle, int indent) {
		String s = c.getString();

		// Split words
		List<String> words = new LinkedList<>();
		BreakIterator iterator = BreakIterator.getLineInstance(CatnipClientServices.CLIENT_HOOKS.getCurrentLocale());
		iterator.setText(s);
		int start = iterator.first();
		for (int end = iterator.next(); end != BreakIterator.DONE; start = end, end = iterator.next()) {
			String word = s.substring(start, end);
			words.add(word);
		}

		// Apply hard wrap
		class_327 font = class_310.method_1551().field_1772;
		List<String> lines = new LinkedList<>();
		StringBuilder currentLine = new StringBuilder();
		int width = 0;
		for (String word : words) {
			int newWidth = font.method_1727(word.replaceAll("_", ""));
			if (width + newWidth > MAX_WIDTH_PER_LINE) {
				if (width > 0) {
					String line = currentLine.toString();
					lines.add(line);
					currentLine = new StringBuilder();
					width = 0;
				} else {
					lines.add(word);
					continue;
				}
			}
			currentLine.append(word);
			width += newWidth;
		}
		if (width > 0) {
			lines.add(currentLine.toString());
		}

		// Format
		class_5250 lineStart = class_2561.method_43470(Strings.repeat(" ", indent));
		lineStart.method_27696(primaryStyle);
		List<class_2561> formattedLines = new ArrayList<>(lines.size());
		Couple<class_2583> styles = Couple.create(highlightStyle, primaryStyle);

		boolean currentlyHighlighted = false;
		for (String string : lines) {
			class_5250 currentComponent = lineStart.method_27662();
			String[] split = string.split("_");
			for (String part : split) {
				currentComponent.method_10852(class_2561.method_43470(part).method_27696(styles.get(currentlyHighlighted)));
				currentlyHighlighted = !currentlyHighlighted;
			}

			formattedLines.add(currentComponent);
			currentlyHighlighted = !currentlyHighlighted;
		}

		return formattedLines;
	}

	public record Palette(class_2583 primary, class_2583 highlight) {
		public static final Palette STANDARD_CREATE = new Palette(styleFromColor(0xC9974C), styleFromColor(0xF1DD79));

		public static final Palette BLUE = ofColors(class_124.field_1078, class_124.field_1075);
		public static final Palette GREEN = ofColors(class_124.field_1077, class_124.field_1060);
		public static final Palette YELLOW = ofColors(class_124.field_1065, class_124.field_1054);
		public static final Palette RED = ofColors(class_124.field_1079, class_124.field_1061);
		public static final Palette PURPLE = ofColors(class_124.field_1064, class_124.field_1076);
		public static final Palette GRAY = ofColors(class_124.field_1063, class_124.field_1080);

		public static final Palette ALL_GRAY = ofColors(class_124.field_1080, class_124.field_1080);
		public static final Palette GRAY_AND_BLUE = ofColors(class_124.field_1080, class_124.field_1078);
		public static final Palette GRAY_AND_WHITE = ofColors(class_124.field_1080, class_124.field_1068);
		public static final Palette GRAY_AND_GOLD = ofColors(class_124.field_1080, class_124.field_1065);
		public static final Palette GRAY_AND_RED = ofColors(class_124.field_1080, class_124.field_1061);

		public static Palette ofColors(class_124 primary, class_124 highlight) {
			return new Palette(styleFromColor(primary), styleFromColor(highlight));
		}
	}

}
