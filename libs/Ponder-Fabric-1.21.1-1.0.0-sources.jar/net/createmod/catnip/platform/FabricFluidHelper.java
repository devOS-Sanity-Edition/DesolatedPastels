package net.createmod.catnip.platform;

import org.jetbrains.annotations.Nullable;

import net.createmod.catnip.platform.services.ModFluidHelper;
import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRendering;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributes;
import net.minecraft.class_1058;
import net.minecraft.class_3611;
import net.minecraft.class_9326;

public class FabricFluidHelper implements ModFluidHelper {
	@Override
	public int getColor(class_3611 fluid, long amount, @Nullable class_9326 fluidData) {
		return FluidVariantRendering.getColor(FluidVariant.of(fluid, fluidData));
	}

	@Override
	public int getLuminosity(class_3611 fluid, long amount, @Nullable class_9326 fluidData) {
		return FluidVariantAttributes.getLuminance(FluidVariant.of(fluid, fluidData));
	}

	@Override
	@Nullable
	public class_1058 getStillTexture(class_3611 fluid, long amount, @Nullable class_9326 fluidData) {
		// handle sprites[0] being null, FluidVariantRendering.getSprite runs Objects.requireNonNull on it.
		class_1058[] sprites = FluidVariantRendering.getSprites(FluidVariant.of(fluid, fluidData));
		return sprites != null ? sprites[0] : null;
	}

	@Override
	public boolean isLighterThanAir(class_3611 fluid) {
		return FluidVariantAttributes.isLighterThanAir(FluidVariant.of(fluid));
	}
}
