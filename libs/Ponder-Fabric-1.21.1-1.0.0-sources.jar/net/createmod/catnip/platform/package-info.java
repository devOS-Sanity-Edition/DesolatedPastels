@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package net.createmod.catnip.platform;

import javax.annotation.ParametersAreNonnullByDefault;
