package net.createmod.catnip.platform;

import net.createmod.catnip.net.base.CatnipPacketRegistry;
import net.createmod.catnip.net.base.ClientboundPacketPayload;
import net.createmod.catnip.net.base.ServerboundPacketPayload;
import net.createmod.catnip.platform.services.NetworkHelper;
import net.createmod.ponder.FabricPonder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_1923;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_3215;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import org.jetbrains.annotations.ApiStatus;

public class FabricNetworkHelper implements NetworkHelper {
	@ApiStatus.Internal
	@Override
	public void registerPackets(CatnipPacketRegistry packetRegistry) {
		for (CatnipPacketRegistry.PacketType<?> type : packetRegistry.packetsView) {
			boolean clientbound = ClientboundPacketPayload.class.isAssignableFrom(type.clazz());
			boolean serverbound = ServerboundPacketPayload.class.isAssignableFrom(type.clazz());
			if (clientbound && serverbound) {
				throw new IllegalStateException("Packet class is both clientbound and serverbound: " + type.clazz());
			} else if (clientbound) {
				CatnipPacketRegistry.PacketType<ClientboundPacketPayload> casted = (CatnipPacketRegistry.PacketType<ClientboundPacketPayload>) type;
				PayloadTypeRegistry.playS2C().register(casted.type(), casted.codec());
				ClientPlayNetworking.registerGlobalReceiver(casted.type(), (payload, ctx) -> payload.handle(ctx.player()));
			} else if (serverbound) {
				CatnipPacketRegistry.PacketType<ServerboundPacketPayload> casted = (CatnipPacketRegistry.PacketType<ServerboundPacketPayload>) type;
				PayloadTypeRegistry.playC2S().register(casted.type(), casted.codec());
				ServerPlayNetworking.registerGlobalReceiver(casted.type(), ((payload, ctx) -> payload.handle(ctx.player())));
			}
		}
	}

	@Environment(EnvType.CLIENT)
	@Override
	public void sendToServer(class_8710 payload) {
		ClientPlayNetworking.send(payload);
	}

	@Override
	public void sendToClient(class_3222 player, class_8710 payload) {
		ServerPlayNetworking.send(player, payload);
	}

	@Override
	public void sendToAllClients(class_8710 payload) {
		class_2596<?> packet = ServerPlayNetworking.createS2CPacket(payload);
		FabricPonder.getServer().method_3760().method_14581(packet);
	}

	@Override
	public void sendToClientsTrackingAndSelf(class_1297 entity, class_8710 payload) {
		class_2596<?> packet = ServerPlayNetworking.createS2CPacket(payload);
		if (entity.method_37908().method_8398() instanceof class_3215 chunkCache) {
			chunkCache.method_18751(entity, packet);
		} else {
			throw new IllegalStateException("Cannot send clientbound payloads on the client");
		}
	}

	@Override
	public void sendToClientsTrackingEntity(class_1297 entity, class_8710 payload) {
		class_2596<?> packet = ServerPlayNetworking.createS2CPacket(payload);
		if (entity.method_37908().method_8398() instanceof class_3215 chunkCache) {
			chunkCache.method_18754(entity, packet);
		} else {
			throw new IllegalStateException("Cannot send clientbound payloads on the client");
		}
	}

	@Override
	public void sendToClientsTrackingChunk(class_3218 serverLevel, class_1923 chunk, class_8710 payload) {
		for (class_3222 player : serverLevel.method_14178().field_17254.method_17210(chunk, false)) {
			sendToClient(player, payload);
		}
	}

	@Override
	public void sendToClientsAround(class_3218 serverLevel, class_243 pos, double radius, class_8710 payload) {
		class_2596<?> packet = ServerPlayNetworking.createS2CPacket(payload);
		serverLevel.method_8503().method_3760().method_14605(null, pos.method_10216(), pos.method_10214(), pos.method_10215(), radius, serverLevel.method_27983(), packet);
	}
}
