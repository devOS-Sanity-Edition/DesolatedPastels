@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package net.createmod.catnip.platform.services;

import javax.annotation.ParametersAreNonnullByDefault;
