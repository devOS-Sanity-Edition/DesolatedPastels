package net.createmod.catnip.platform.services;

import net.minecraft.class_1058;
import net.minecraft.class_3611;
import net.minecraft.class_9326;
import org.jetbrains.annotations.Nullable;

public interface ModFluidHelper {
	int getColor(class_3611 fluid, long amount, @Nullable class_9326 fluidData);

	int getLuminosity(class_3611 fluid, long amount, @Nullable class_9326 fluidData);

	@Nullable
	class_1058 getStillTexture(class_3611 fluid, long amount, @Nullable class_9326 fluidData);

	boolean isLighterThanAir(class_3611 fluid);
}
