package net.createmod.catnip.platform.services;

import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_4538;

public interface ModHooksHelper {

	/**
	 * Attempts to place a single Block as a Player, and should fire according events
	 *
	 * @return True if the event got canceled or the Block was not be placed, False otherwise
	 */
	boolean playerPlaceSingleBlock(class_1657 player, class_1937 level, class_2338 pos, class_2680 newState);

	default class_1799 getCloneItemFromBlockstate(class_2680 state, class_239 target, class_4538 level, class_2338 pos, class_1657 player) {
		return state.method_26204().method_9574(level, pos, state);
	}

	boolean isPlayerFake(class_3222 player);

}
