package net.createmod.catnip.platform.services;

import java.util.Locale;
import java.util.function.Function;

import org.jetbrains.annotations.Nullable;
import net.createmod.catnip.render.ShadedBlockSbbBuilder;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2394;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_276;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3610;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_776;
import net.minecraft.class_777;

public interface ModClientHooksHelper {

	Locale getCurrentLocale();

	void enableStencilBuffer(class_276 renderTarget);

	ShadedBlockSbbBuilder createSbbBuilder();

	@Nullable class_1087 filterModelForRenderType(class_2680 state, class_1087 model, class_1921 layer);

	void renderVirtualBlockStateModel(class_1087 model, class_4587 ms, class_2680 state, Function<class_1921, class_4588> bufferMap);

	void renderFullFluidState(class_4587 ms, class_4597.class_4598 buffer, class_3610 fluid);

	void vertexConsumerPutBulkDataWithAlpha(class_4588 consumer, class_4587.class_4665 pose, class_777 quad, float red,
											float green, float blue, float alpha, int packedLight, int packedOverlay);

	void renderGuiGameElementModel(class_776 blockRenderer, class_4597.class_4598 buffer,
								   class_4587 ms, class_2680 state, class_1087 blockModel, int color, @Nullable class_2586 BEWithModelData);

	<T extends class_2394> class_703 createParticleFromData(T data, class_638 level, double x, double y, double z,
																double mx, double my, double mz);

	class_310 getMinecraftFromScreen(class_437 screen);

	default boolean isKeyPressed(class_304 mapping) {
		return mapping.method_1434();
	}

	default class_776 getBlockRenderDispatcher() {
		return class_310.method_1551().method_1541();
	}
}
