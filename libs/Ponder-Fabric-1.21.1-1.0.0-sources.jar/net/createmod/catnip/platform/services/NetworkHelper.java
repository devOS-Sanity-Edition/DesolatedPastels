package net.createmod.catnip.platform.services;

import net.createmod.catnip.net.base.CatnipPacketRegistry;
import net.createmod.catnip.net.packets.ClientboundSimpleActionPacket;
import net.minecraft.class_1297;
import net.minecraft.class_1923;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import org.jetbrains.annotations.ApiStatus;

public interface NetworkHelper {
	@ApiStatus.Internal
	void registerPackets(CatnipPacketRegistry packetRegistry);

	void sendToServer(class_8710 payload);

	void sendToClient(class_3222 player, class_8710 payload);

	default void sendToClients(Iterable<class_3222> players, class_8710 payload) {
		for (class_3222 player : players) {
			sendToClient(player, payload);
		}
	}

	void sendToAllClients(class_8710 payload);

	void sendToClientsTrackingAndSelf(class_1297 entity, class_8710 payload);

	void sendToClientsTrackingEntity(class_1297 entity, class_8710 payload);

	void sendToClientsTrackingChunk(class_3218 serverLevel, class_1923 chunk, class_8710 payload);

	void sendToClientsAround(class_3218 serverLevel, class_243 pos, double radius, class_8710 payload);

	default void sendToClientsAround(class_3218 serverLevel, class_2382 pos, double radius, class_8710 payload) {
		sendToClientsAround(serverLevel, new class_243(pos.method_10263(), pos.method_10264(), pos.method_10260()), radius, payload);
	}

	default void simpleActionToClient(class_3222 player, String action, String value) {
		sendToClient(player, new ClientboundSimpleActionPacket(action, value));
	}
}
