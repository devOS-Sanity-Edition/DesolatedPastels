package net.createmod.catnip.platform;

import net.createmod.catnip.platform.services.ModHooksHelper;
import net.fabricmc.fabric.api.block.BlockPickInteractionAware;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_4538;

public class FabricHooksHelper implements ModHooksHelper {
	@Override
	public boolean playerPlaceSingleBlock(class_1657 player, class_1937 level, class_2338 pos, class_2680 newState) {
		level.method_8501(pos, newState);
		return false;
	}

	@Override
	public class_1799 getCloneItemFromBlockstate(class_2680 state, class_239 target, class_4538 level, class_2338 pos, class_1657 player) {
		if (state.method_26204() instanceof BlockPickInteractionAware blockPickInteractionAware)
			return blockPickInteractionAware.getPickedStack(state, level, pos, player, target);
		return ModHooksHelper.super.getCloneItemFromBlockstate(state, target, level, pos, player);
	}

	@Override
	public boolean isPlayerFake(class_3222 player) {
		return player instanceof FakePlayer;
	}
}
