package net.createmod.catnip.platform;

import java.util.Locale;
import java.util.function.Function;

import org.jetbrains.annotations.Nullable;
import net.createmod.catnip.platform.services.ModClientHooksHelper;
import net.createmod.catnip.render.BasicFluidRenderer;
import net.createmod.catnip.render.BlendModeFilteringBakedModel;
import net.createmod.catnip.render.FabricShadedBlockSbbBuilder;
import net.createmod.catnip.render.FixedColorTintingBakedModel;
import net.createmod.catnip.render.MultiLayerModelRenderer;
import net.createmod.catnip.render.RenderTargetExtensions;
import net.createmod.catnip.render.ShadedBlockSbbBuilder;
import net.createmod.ponder.mixin.client.ParticleEngineAccessor;
import net.createmod.ponder.utility.VertexUtils;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
import net.minecraft.class_1076;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2394;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_276;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3610;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4696;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_765;
import net.minecraft.class_776;
import net.minecraft.class_777;

public class FabricClientHooksHelper implements ModClientHooksHelper {
	@Override
	public Locale getCurrentLocale() {
		class_1076 languageManager = class_310.method_1551().method_1526();
		String[] split = languageManager.method_4669().split("_", 2);
		return split.length == 1 ? new Locale(split[0]) : new Locale(split[0], split[1]);
	}

	@Override
	public void enableStencilBuffer(class_276 renderTarget) {
		((RenderTargetExtensions) renderTarget).catnip$enableStencil();
	}

	@Override
	public ShadedBlockSbbBuilder createSbbBuilder() {
		return new FabricShadedBlockSbbBuilder();
	}

	@Override
	@Nullable
	public class_1087 filterModelForRenderType(class_2680 state, class_1087 model, class_1921 layer) {
		if (model.isVanillaAdapter()) {
			if (class_4696.method_23679(state) != layer)
				model = null;
		} else {
			model = BlendModeFilteringBakedModel.wrap(model, BlendMode.fromRenderLayer(layer));
		}

		return model;
	}

	@Override
	public void renderVirtualBlockStateModel(class_1087 model, class_4587 ms, class_2680 state, Function<class_1921, class_4588> bufferMap) {
		MultiLayerModelRenderer.render(model, ms, state, bufferMap);
	}

	@Override
	public void renderFullFluidState(class_4587 ms, class_4597.class_4598 buffer, class_3610 fluid) {
		BasicFluidRenderer.renderFluidBox(fluid.method_15772(), 1000, 0, 0, 0, 1, 1, 1, buffer, ms, class_765.field_32767, false, true);
	}

	@Override
	public void vertexConsumerPutBulkDataWithAlpha(class_4588 consumer, class_4587.class_4665 pose, class_777 quad, float red, float green, float blue, float alpha, int packedLight, int packedOverlay) {
		VertexUtils.putBulkData(consumer, pose, quad, red, green, blue, alpha, packedLight, packedOverlay);
	}

	@Override
	public void renderGuiGameElementModel(class_776 blockRenderer, class_4597.class_4598 bufferSource,
										  class_4587 ms, class_2680 state, class_1087 model, int color, class_2586 BEwithModelData) {
		int blockColor = class_310.method_1551()
				.method_1505()
				.method_1697(state, null, null, 0);
		model = FixedColorTintingBakedModel.wrap(model, blockColor == -1 ? color : blockColor);

		MultiLayerModelRenderer.render(model, ms, state, bufferSource::getBuffer);
	}

	@Override
	public <T extends class_2394> class_703 createParticleFromData(T data, class_638 level, double x, double y, double z, double mx, double my, double mz) {
		return ((ParticleEngineAccessor) class_310.method_1551().field_1713).catnip$makeParticle(data, x, y, z, mx, my, mz);
	}

	@Override
	public class_310 getMinecraftFromScreen(class_437 screen) {
		return Screens.getClient(screen);
	}

	@Override
	public boolean isKeyPressed(class_304 mapping) {
		int keyCode = KeyBindingHelper.getBoundKeyOf(mapping).method_1444();
		long window = class_310.method_1551().method_22683().method_4490();
		return class_3675.method_15987(window, keyCode);
	}
}
