@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package net.createmod.catnip.nbt;

import javax.annotation.ParametersAreNonnullByDefault;
