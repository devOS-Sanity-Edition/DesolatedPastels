package net.createmod.catnip.levelWrappers;

import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1845;
import net.minecraft.class_1863;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_22;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_269;
import net.minecraft.class_2791;
import net.minecraft.class_2802;
import net.minecraft.class_2806;
import net.minecraft.class_2818;
import net.minecraft.class_2874;
import net.minecraft.class_3194;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3568;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_3695;
import net.minecraft.class_5269;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_5577;
import net.minecraft.class_5712;
import net.minecraft.class_6754;
import net.minecraft.class_6756;
import net.minecraft.class_6880;
import net.minecraft.class_7134;
import net.minecraft.class_7699;
import net.minecraft.class_7924;
import net.minecraft.class_8527;
import net.minecraft.class_8921;
import net.minecraft.class_9209;
import org.jetbrains.annotations.Nullable;

public class SchematicChunkSource extends class_2802 {
	private final class_1937 fallbackWorld;

	public SchematicChunkSource(class_1937 world) {
		fallbackWorld = world;
	}

	@Nullable
	@Override
	public class_8527 method_12246(int x, int z) {
		return getChunk(x, z);
	}

	@Override
	public class_1937 method_16399() {
		return fallbackWorld;
	}

	@Nullable
	@Override
	public class_2791 method_12121(int x, int z, class_2806 status, boolean p_212849_4_) {
		return getChunk(x, z);
	}

	public class_2791 getChunk(int x, int z) {
		return new EmptierChunk(fallbackWorld.method_30349());
	}

	@Override
	public String method_12122() {
		return "WrappedChunkProvider";
	}

	@Override
	public class_3568 method_12130() {
		return fallbackWorld.method_22336();
	}

	@Override
	public void method_12127(BooleanSupplier p_202162_, boolean p_202163_) {}

	@Override
	public int method_14151() {
		return 0;
	}

	public static class EmptierChunk extends class_2818 {

		private static final class DummyLevel extends class_1937 {
			private DummyLevel(class_5269 pLevelData, class_5321<class_1937> pDimension,
							   class_5455 pRegistryAccess, class_6880<class_2874> pDimensionTypeRegistration,
							   Supplier<class_3695> pProfiler, boolean pIsClientSide, boolean pIsDebug, long pBiomeZoomSeed,
							   int pMaxChainedNeighborUpdates) {
				super(pLevelData, pDimension, pRegistryAccess, pDimensionTypeRegistration, pProfiler, pIsClientSide, pIsDebug,
					  pBiomeZoomSeed, pMaxChainedNeighborUpdates);
				access = pRegistryAccess;
			}

			private final class_5455 access;

			private DummyLevel(class_5455 access) {
				this(null, null, access, access.method_30530(class_7924.field_41241)
						.method_40290(class_7134.field_37666), null, false, false, 0, 0);
			}

			@Override
			public class_2802 method_8398() {
				return null;
			}

			@Override
			public void method_8444(class_1657 pPlayer, int pType, class_2338 pPos, int pData) {}

			@Override
			public void method_43275(@Nullable class_1297 entity, class_6880<class_5712> gameEvent, class_243 pos) {}

			@Override
			public void method_32888(class_6880<class_5712> holder, class_243 vec3, class_5712.class_7397 context) {}

			@Override
			public class_5455 method_30349() {
				return access;
			}

			@Override
			public class_1845 method_59547() {
				return null;
			}

			@Override
			public List<? extends class_1657> method_18456() {
				return null;
			}

			@Override
			public class_6880<class_1959> method_22387(int pX, int pY, int pZ) {
				return null;
			}

			@Override
			public float method_24852(class_2350 pDirection, boolean pShade) {
				return 0;
			}

			@Override
			public void method_8413(class_2338 pPos, class_2680 pOldState, class_2680 pNewState, int pFlags) {}

			@Override
			public void method_43128(class_1657 pPlayer, double pX, double pY, double pZ, class_3414 pSound,
				class_3419 pCategory, float pVolume, float pPitch) {}

			@Override
			public void method_43129(class_1657 pPlayer, class_1297 pEntity, class_3414 pEvent, class_3419 pCategory,
				float pVolume, float pPitch) {}

			@Override
			public void method_8465(class_1657 pPlayer, double pX, double pY, double pZ, class_6880<class_3414> pSound,
										class_3419 pSource, float pVolume, float pPitch, long pSeed) {}

			@Override
			public void method_47967(class_1657 p_220363_, double p_220364_, double p_220365_, double p_220366_,
										class_3414 p_220367_, class_3419 p_220368_, float p_220369_, float p_220370_, long p_220371_) {}

			@Override
			public void method_8449(class_1657 p_220372_, class_1297 p_220373_, class_6880<class_3414> p_220374_, class_3419 p_220375_,
										float p_220376_, float p_220377_, long p_220378_) {}

			@Override
			public String method_31419() {
				return null;
			}

			@Override
			public class_1297 method_8469(int pId) {
				return null;
			}

			@Nullable
			@Override
			public class_22 method_17891(class_9209 mapId) {
				return null;
			}

			@Override
			public void method_17890(class_9209 mapId, class_22 mapItemSavedData) {}

			@Override
			public class_9209 method_17889() {
				return new class_9209(0);
			}

			@Override
			public void method_8517(int pBreakerId, class_2338 pPos, int pProgress) {}

			@Override
			public class_269 method_8428() {
				return null;
			}

			@Override
			public class_1863 method_8433() {
				return null;
			}

			@Override
			protected class_5577<class_1297> method_31592() {
				return null;
			}

			@Override
			public class_6756<class_2248> method_8397() {
				return class_6754.method_39362();
			}

			@Override
			public class_6756<class_3611> method_8405() {
				return class_6754.method_39362();
			}

			@Override
			public class_7699 method_45162() {
				return class_7699.method_45397();
			}

			@Override
			public class_8921 method_54719() {
				return null;
			}

			// Neo's patched methods
			public void setDayTimeFraction(float var1) {}

			public float getDayTimeFraction() { return 0; }

			public float getDayTimePerTick() { return 0; }

			public void setDayTimePerTick(float var1) {}
		}

		public EmptierChunk(class_5455 registryAccess) {
			super(new DummyLevel(registryAccess), class_1923.field_35107);
		}

		public class_2680 method_8320(class_2338 p_180495_1_) {
			return class_2246.field_10243.method_9564();
		}

		@Nullable
		public class_2680 method_12010(class_2338 p_177436_1_, class_2680 p_177436_2_, boolean p_177436_3_) {
			return null;
		}

		public class_3610 method_8316(class_2338 p_204610_1_) {
			return class_3612.field_15906.method_15785();
		}

		public int method_8317(class_2338 p_217298_1_) {
			return 0;
		}

		@Nullable
		public class_2586 method_12201(class_2338 p_177424_1_, class_2819 p_177424_2_) {
			return null;
		}

		public void method_12216(class_2586 p_150813_1_) {}

		public void method_12007(class_2586 p_177426_2_) {}

		public void method_12041(class_2338 p_177425_1_) {}

		public void markUnsaved() {}

		public boolean method_12223() {
			return true;
		}

		public boolean method_12228(int p_76606_1_, int p_76606_2_) {
			return true;
		}

		public class_3194 method_12225() {
			return class_3194.field_44855;
		}
	}
}
