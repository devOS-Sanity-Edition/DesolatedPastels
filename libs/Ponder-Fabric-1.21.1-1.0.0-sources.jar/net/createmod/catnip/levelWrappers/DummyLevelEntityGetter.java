package net.createmod.catnip.levelWrappers;

import java.util.Collections;
import java.util.UUID;
import java.util.function.Consumer;
import net.minecraft.class_238;
import net.minecraft.class_5568;
import net.minecraft.class_5575;
import net.minecraft.class_5577;
import net.minecraft.class_7927;

public class DummyLevelEntityGetter<T extends class_5568> implements class_5577<T> {

	@Override
	public T method_31804(int p_156931_) {
		return null;
	}

	@Override
	public T method_31808(UUID pUuid) {
		return null;
	}

	@Override
	public Iterable<T> method_31803() {
		return Collections.emptyList();
	}

	@Override
	public <U extends T> void method_31806(class_5575<T, U> p_156935_, class_7927<U> p_156936_) {
	}

	@Override
	public void method_31807(class_238 p_156937_, Consumer<T> p_156938_) {
	}

	@Override
	public <U extends T> void method_31805(class_5575<T, U> p_156932_, class_238 p_156933_, class_7927<U> p_156934_) {
	}

}
