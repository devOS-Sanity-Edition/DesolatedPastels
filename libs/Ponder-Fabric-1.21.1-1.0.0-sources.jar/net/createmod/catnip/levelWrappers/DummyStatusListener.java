package net.createmod.catnip.levelWrappers;

import javax.annotation.Nullable;
import net.minecraft.class_1923;
import net.minecraft.class_2806;
import net.minecraft.class_3949;

public class DummyStatusListener implements class_3949 {

	@Override
	public void method_17669(class_1923 pCenter) {}

	@Override
	public void method_17670(class_1923 pChunkPosition, @Nullable class_2806 pNewStatus) {}

	@Override
	public void method_17675() {}

	@Override
	public void method_17671() {}

}
