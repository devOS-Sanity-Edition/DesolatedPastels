package net.createmod.catnip.levelWrappers;

import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;

import net.createmod.ponder.mixin.accessor.EntityAccessor;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1845;
import net.minecraft.class_1863;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_22;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_269;
import net.minecraft.class_2802;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3568;
import net.minecraft.class_3611;
import net.minecraft.class_4076;
import net.minecraft.class_5269;
import net.minecraft.class_5455;
import net.minecraft.class_5577;
import net.minecraft.class_5712;
import net.minecraft.class_6756;
import net.minecraft.class_6880;
import net.minecraft.class_7699;
import net.minecraft.class_8921;
import net.minecraft.class_9209;
import org.jetbrains.annotations.Nullable;

public class WrappedLevel extends class_1937 {

	protected class_1937 level;
	protected class_2802 chunkSource;

	protected class_5577<class_1297> entityGetter = new DummyLevelEntityGetter<>();

	public WrappedLevel(class_1937 level) {
		super((class_5269) level.method_8401(), level.method_27983(), level.method_30349(), level.method_40134(),
			  level::method_16107, level.field_9236, level.method_27982(), 0, 0);
		this.level = level;
	}

	public void setChunkSource(class_2802 source) {
		this.chunkSource = source;
	}

	public class_1937 getLevel() {
		return level;
	}

	@Override
	public class_3568 method_22336() {
		return level.method_22336();
	}

	@Override
	public class_2680 method_8320(@Nullable class_2338 pos) {
		return level.method_8320(pos);
	}

	@Override
	public boolean method_16358(class_2338 p_217375_1_, Predicate<class_2680> p_217375_2_) {
		return level.method_16358(p_217375_1_, p_217375_2_);
	}

	@Override
	@Nullable
	public class_2586 method_8321(class_2338 pos) {
		return level.method_8321(pos);
	}

	@Override
	public boolean method_8652(class_2338 pos, class_2680 newState, int flags) {
		return level.method_8652(pos, newState, flags);
	}

	@Override
	public int method_22339(class_2338 pos) {
		return 15;
	}

	@Override
	public void method_8413(class_2338 pos, class_2680 oldState, class_2680 newState, int flags) {
		level.method_8413(pos, oldState, newState, flags);
	}

	@Override
	public class_6756<class_2248> method_8397() {
		return level.method_8397();
	}

	@Override
	public class_6756<class_3611> method_8405() {
		return level.method_8405();
	}

	@Override
	public class_2802 method_8398() {
		return chunkSource != null ? chunkSource : level.method_8398();
	}

	@Override
	public void method_8444(@Nullable class_1657 player, int type, class_2338 pos, int data) {}

	@Override
	public List<? extends class_1657> method_18456() {
		return Collections.emptyList();
	}

	@Override
	public void method_8465(class_1657 pPlayer, double pX, double pY, double pZ, class_6880<class_3414> pSound,
								class_3419 pSource, float pVolume, float pPitch, long pSeed) {}

	@Override
	public void method_8449(class_1657 pPlayer, class_1297 pEntity, class_6880<class_3414> pSound, class_3419 pCategory,
								float pVolume, float pPitch, long pSeed) {}

	@Override
	public void method_43128(@Nullable class_1657 player, double x, double y, double z, class_3414 soundIn,
		class_3419 category, float volume, float pitch) {}

	@Override
	public void method_43129(@Nullable class_1657 p_217384_1_, class_1297 p_217384_2_, class_3414 p_217384_3_,
		class_3419 p_217384_4_, float p_217384_5_, float p_217384_6_) {}

	@Override
	public class_1297 method_8469(int id) {
		return null;
	}

	@Override
	public class_8921 method_54719() {
		return level.method_54719();
	}

	@Nullable
	@Override
	public class_22 method_17891(class_9209 mapId) {
		return null;
	}

	@Override
	public boolean method_8649(class_1297 entityIn) {
		((EntityAccessor) entityIn).catnip$callSetLevel(level);
		return level.method_8649(entityIn);
	}

	@Override
	public void method_17890(class_9209 mapId, class_22 mapItemSavedData) {}

	@Override
	public class_9209 method_17889() {
		return level.method_17889();
	}

	@Override
	public void method_8517(int breakerId, class_2338 pos, int progress) {}

	@Override
	public class_269 method_8428() {
		return level.method_8428();
	}

	@Override
	public class_1863 method_8433() {
		return level.method_8433();
	}

	@Override
	public class_6880<class_1959> method_22387(int p_225604_1_, int p_225604_2_, int p_225604_3_) {
		return level.method_22387(p_225604_1_, p_225604_2_, p_225604_3_);
	}

	@Override
	public class_5455 method_30349() {
		return level.method_30349();
	}

	@Override
	public class_1845 method_59547() {
		return level.method_59547();
	}

	@Override
	public float method_24852(class_2350 p_230487_1_, boolean p_230487_2_) {
		return level.method_24852(p_230487_1_, p_230487_2_);
	}

	@Override
	public void method_8455(class_2338 p_175666_1_, class_2248 p_175666_2_) {}

	@Override
	public void method_43275(@Nullable class_1297 entity, class_6880<class_5712> gameEvent, class_243 pos) {}

	@Override
	public void method_32888(class_6880<class_5712> holder, class_243 vec3, class_5712.class_7397 context) {}

	@Override
	public String method_31419() {
		return level.method_31419();
	}

	@Override
	protected class_5577<class_1297> method_31592() {
		return entityGetter;
	}

	// Intentionally copied from LevelHeightAccessor. Workaround for issues caused
	// when other mods (such as Lithium)
	// override the vanilla implementations in ways which cause WrappedWorlds to
	// return incorrect, default height info.
	// WrappedWorld subclasses should implement their own getMinBuildHeight and
	// getHeight overrides where they deviate
	// from the defaults for their dimension.

	@Override
	public int method_31600() {
		return this.method_31607() + this.method_31605();
	}

	@Override
	public int method_32890() {
		return this.method_31597() - this.method_32891();
	}

	@Override
	public int method_32891() {
		return class_4076.method_18675(this.method_31607());
	}

	@Override
	public int method_31597() {
		return class_4076.method_18675(this.method_31600() - 1) + 1;
	}

	@Override
	public boolean method_31606(class_2338 pos) {
		return this.method_31601(pos.method_10264());
	}

	@Override
	public boolean method_31601(int y) {
		return y < this.method_31607() || y >= this.method_31600();
	}

	@Override
	public int method_31602(int y) {
		return this.method_31603(class_4076.method_18675(y));
	}

	@Override
	public int method_31603(int sectionY) {
		return sectionY - this.method_32891();
	}

	@Override
	public int method_31604(int sectionIndex) {
		return sectionIndex + this.method_32891();
	}

	@Override
	public class_7699 method_45162() {
		return level.method_45162();
	}

	// Neo's patched methods
	public void setDayTimeFraction(float var1) {}

	public float getDayTimeFraction() { return 0; }

	public float getDayTimePerTick() { return 0; }

	public void setDayTimePerTick(float var1) {}
}
