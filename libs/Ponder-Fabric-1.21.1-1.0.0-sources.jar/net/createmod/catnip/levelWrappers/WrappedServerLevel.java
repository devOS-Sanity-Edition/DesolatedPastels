package net.createmod.catnip.levelWrappers;

import java.util.Collections;
import java.util.List;

import javax.annotation.Nullable;

import net.createmod.ponder.mixin.accessor.BiomeManagerAccessor;
import net.createmod.ponder.mixin.accessor.EntityAccessor;
import net.createmod.ponder.mixin.accessor.MinecraftServerAccessor;
import net.minecraft.class_1297;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1863;
import net.minecraft.class_1953;
import net.minecraft.class_1959;
import net.minecraft.class_22;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3611;
import net.minecraft.class_5268;
import net.minecraft.class_5363;
import net.minecraft.class_6757;
import net.minecraft.class_6880;
import net.minecraft.class_9209;

public class WrappedServerLevel extends class_3218 {

	protected class_3218 level;

	public WrappedServerLevel(class_3218 level) {
		super(level.method_8503(), class_156.method_18349(), ((MinecraftServerAccessor) level.method_8503()).catnip$getStorageSource(),
			  (class_5268) level.method_8401(), level.method_27983(),
			  new class_5363(level.method_40134(), level.method_14178().method_12129()),
			  new DummyStatusListener(), level.method_27982(), ((BiomeManagerAccessor) level.method_22385()).catnip$getBiomeZoomSeed(),
			  Collections.emptyList(), false, level.method_52168());
		this.level = level;
	}

	@Override
	public float method_8442(float p_72826_1_) {
		return 0;
	}

	@Override
	public int method_22339(class_2338 pos) {
		return 15;
	}

	@Override
	public void method_8413(class_2338 pos, class_2680 oldState, class_2680 newState, int flags) {
		level.method_8413(pos, oldState, newState, flags);
	}

	@Override
	public class_6757<class_2248> method_8397() {
		return super.method_14196();
	}

	@Override
	public class_6757<class_3611> method_8405() {
		return super.method_14179();
	}

	@Override
	public void method_39279(class_2338 pos, class_2248 block, int delay) {}

	@Override
	public void method_39281(class_2338 pos, class_3611 fluid, int delay) {}

	@Override
	public void method_39280(class_2338 pos, class_2248 block, int delay, class_1953 priority) {}

	@Override
	public void method_39282(class_2338 pos, class_3611 fluid, int delay, class_1953 priority) {}

	@Override
	public void method_8444(@Nullable class_1657 player, int type, class_2338 pos, int data) {}

	@Override
	public List<class_3222> method_18456() {
		return Collections.emptyList();
	}

	@Override
	public void method_43128(@Nullable class_1657 player, double x, double y, double z, class_3414 soundIn, class_3419 category,
		float volume, float pitch) {}

	@Override
	public void method_43129(@Nullable class_1657 p_217384_1_, class_1297 p_217384_2_, class_3414 p_217384_3_, class_3419 p_217384_4_,
		float p_217384_5_, float p_217384_6_) {}

	@Override
	public class_1297 method_8469(int id) {
		return null;
	}

	@Override
	public @Nullable class_22 method_17891(class_9209 mapId) {
		return null;
	}

	@Override
	public boolean method_8649(class_1297 entityIn) {
		((EntityAccessor) entityIn).catnip$callSetLevel(level);
		return level.method_8649(entityIn);
	}

	@Override
	public void method_17890(class_9209 mapId, class_22 mapData) {}

	@Override
	public class_9209 method_17889() {
		return new class_9209(0);
	}

	@Override
	public void method_8517(int breakerId, class_2338 pos, int progress) {}

	@Override
	public class_1863 method_8433() {
		return level.method_8433();
	}

	@Override
	public class_6880<class_1959> method_22387(int p_225604_1_, int p_225604_2_, int p_225604_3_) {
		return level.method_22387(p_225604_1_, p_225604_2_, p_225604_3_);
	}



}
