package net.createmod.catnip.levelWrappers;

import net.minecraft.class_1936;
import net.minecraft.class_2960;
import net.minecraft.class_7924;

public class WorldHelper {
	public static class_2960 getDimensionID(class_1936 world) {
		return world.method_30349()
			.method_30530(class_7924.field_41241)
			.method_10221(world.method_8597());
	}
}
