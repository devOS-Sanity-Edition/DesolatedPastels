package net.createmod.catnip.levelWrappers;

import java.util.HashMap;
import java.util.function.Predicate;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3610;

public class PlacementSimulationServerLevel extends WrappedServerLevel {
	public HashMap<class_2338, class_2680> blocksAdded;

	public PlacementSimulationServerLevel(class_3218 wrapped) {
		super(wrapped);
		blocksAdded = new HashMap<>();
	}

	public void clear() {
		blocksAdded.clear();
	}

	@Override
	public boolean method_8652(class_2338 pos, class_2680 newState, int flags) {
		blocksAdded.put(pos.method_10062(), newState);
		return true;
	}

	@Override
	public boolean method_8501(class_2338 pos, class_2680 state) {
		return method_8652(pos, state, 0);
	}

	@Override
	public boolean method_16358(class_2338 pos, Predicate<class_2680> condition) {
		return condition.test(method_8320(pos));
	}

	@Override
	public boolean method_8477(class_2338 pos) {
		return true;
	}

	public boolean isAreaLoaded(class_2338 center, int range) {
		return true;
	}

	@Override
	public class_2680 method_8320(class_2338 pos) {
		if (blocksAdded.containsKey(pos))
			return blocksAdded.get(pos);
		return class_2246.field_10124.method_9564();
	}

	@Override
	public class_3610 method_8316(class_2338 pos) {
		return method_8320(pos).method_26227();
	}

}
