package net.createmod.catnip.levelWrappers;

import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3341;

public interface SchematicLevelAccessor extends class_1936 {
	Set<class_2338> getAllPositions();

	List<class_1297> getEntityList();

	Map<class_2338, class_2680> getBlockMap();

	class_3341 getBounds();

	void setBounds(class_3341 bounds);

	Iterable<class_2586> getBlockEntities();

	Iterable<class_2586> getRenderedBlockEntities();
}
