package net.createmod.catnip.levelWrappers;

import java.util.List;

import javax.annotation.Nullable;

import net.createmod.ponder.mixin.accessor.BiomeManagerAccessor;
import net.createmod.ponder.mixin.client.accessor.ClientPacketListenerAccessor;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3610;
import net.minecraft.class_4051;
import net.minecraft.class_638;
import net.minecraft.class_6539;

public class WrappedClientLevel extends class_638 {
	private static final class_310 mc = class_310.method_1551();
	protected class_1937 level;

	private WrappedClientLevel(class_1937 level) {
		super(mc.method_1562(), mc.field_1687.method_28104(), level.method_27983(), level.method_40134(),
			((ClientPacketListenerAccessor) mc.method_1562()).catnip$getServerChunkRadius(), mc.field_1687.method_39024(), level.method_24367(),
			mc.field_1769, level.method_27982(), ((BiomeManagerAccessor) level.method_22385()).catnip$getBiomeZoomSeed());
		this.level = level;
	}

	public static WrappedClientLevel of(class_1937 level) {
		return new WrappedClientLevel(level);
	}

	@Override
	public boolean method_22340(class_2338 pos) {
		return level.method_22340(pos);
	}

	@Override
	public boolean method_8477(class_2338 pos) {
		return level.method_8477(pos);
	}

	@Override
	public class_2680 method_8320(class_2338 pos) {
		return level.method_8320(pos);
	}
	
	@Override
	public class_1922 method_22338(int x, int z) {
		return level.method_22338(x, z);
	}

	// FIXME: blockstate#getCollisionShape with WrappedClientWorld gives unreliable
	// data (maybe)

	@Override
	public int method_8314(class_1944 type, class_2338 pos) {
		return level.method_8314(type, pos);
	}

	@Override
	public int method_8317(class_2338 pos) {
		return level.method_8317(pos);
	}

	@Override
	public class_3610 method_8316(class_2338 pos) {
		return level.method_8316(pos);
	}

	@Nullable
	@Override
	public <T extends class_1309> T method_18468(List<? extends T> p_217361_1_, class_4051 p_217361_2_,
		@Nullable class_1309 p_217361_3_, double p_217361_4_, double p_217361_6_, double p_217361_8_) {
		return level.method_18468(p_217361_1_, p_217361_2_, p_217361_3_, p_217361_4_, p_217361_6_, p_217361_8_);
	}

	@Override
	public int method_23752(class_2338 p_225525_1_, class_6539 p_225525_2_) {
		return level.method_23752(p_225525_1_, p_225525_2_);
	}

	// FIXME: Emissive Lighting might not light stuff properly

	@Override
	public void method_8406(class_2394 p_195594_1_, double p_195594_2_, double p_195594_4_, double p_195594_6_,
		double p_195594_8_, double p_195594_10_, double p_195594_12_) {
		level.method_8406(p_195594_1_, p_195594_2_, p_195594_4_, p_195594_6_, p_195594_8_, p_195594_10_, p_195594_12_);
	}

	@Override
	public void method_8466(class_2394 p_195590_1_, boolean p_195590_2_, double p_195590_3_, double p_195590_5_,
		double p_195590_7_, double p_195590_9_, double p_195590_11_, double p_195590_13_) {
		level.method_8466(p_195590_1_, p_195590_2_, p_195590_3_, p_195590_5_, p_195590_7_, p_195590_9_, p_195590_11_,
						  p_195590_13_);
	}

	@Override
	public void method_8494(class_2394 p_195589_1_, double p_195589_2_, double p_195589_4_,
		double p_195589_6_, double p_195589_8_, double p_195589_10_, double p_195589_12_) {
		level.method_8494(p_195589_1_, p_195589_2_, p_195589_4_, p_195589_6_, p_195589_8_, p_195589_10_,
									   p_195589_12_);
	}

	@Override
	public void method_17452(class_2394 p_217404_1_, boolean p_217404_2_, double p_217404_3_,
		double p_217404_5_, double p_217404_7_, double p_217404_9_, double p_217404_11_, double p_217404_13_) {
		level.method_17452(p_217404_1_, p_217404_2_, p_217404_3_, p_217404_5_, p_217404_7_, p_217404_9_,
									   p_217404_11_, p_217404_13_);
	}

	@Override
	public void method_8486(double p_184134_1_, double p_184134_3_, double p_184134_5_, class_3414 p_184134_7_,
		class_3419 p_184134_8_, float p_184134_9_, float p_184134_10_, boolean p_184134_11_) {
		level.method_8486(p_184134_1_, p_184134_3_, p_184134_5_, p_184134_7_, p_184134_8_, p_184134_9_, p_184134_10_,
							 p_184134_11_);
	}

	@Override
	public void method_43128(@Nullable class_1657 p_184148_1_, double p_184148_2_, double p_184148_4_, double p_184148_6_,
		class_3414 p_184148_8_, class_3419 p_184148_9_, float p_184148_10_, float p_184148_11_) {
		level.method_43128(p_184148_1_, p_184148_2_, p_184148_4_, p_184148_6_, p_184148_8_, p_184148_9_, p_184148_10_,
						p_184148_11_);
	}

	@Nullable
	@Override
	public class_2586 method_8321(class_2338 p_175625_1_) {
		return level.method_8321(p_175625_1_);
	}

	public class_1937 getWrappedLevel() {
		return level;
	}
}
