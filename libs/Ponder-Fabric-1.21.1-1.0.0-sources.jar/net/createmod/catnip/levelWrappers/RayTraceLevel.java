package net.createmod.catnip.levelWrappers;

import java.util.function.BiFunction;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3610;

public class RayTraceLevel implements class_1922 {

	private final class_1936 template;
	private final BiFunction<class_2338, class_2680, class_2680> stateGetter;

	public RayTraceLevel(class_1936 template, BiFunction<class_2338, class_2680, class_2680> stateGetter) {
		this.template = template;
		this.stateGetter = stateGetter;
	}

	@Override
	public class_2586 method_8321(class_2338 pos) {
		return template.method_8321(pos);
	}

	@Override
	public class_2680 method_8320(class_2338 pos) {
		return stateGetter.apply(pos, template.method_8320(pos));
	}

	@Override
	public class_3610 method_8316(class_2338 pos) {
		return template.method_8316(pos);
	}

	@Override
	public int method_31605() {
		return template.method_31605();
	}

	@Override
	public int method_31607() {
		return template.method_31607();
	}

}
