package net.createmod.catnip.outliner;

import net.createmod.catnip.render.SuperRenderTypeBuffer;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_765;
import net.minecraft.class_811;

public class ItemOutline extends Outline {

	protected class_243 pos;
	protected class_1799 stack;

	public ItemOutline(class_243 pos, class_1799 stack) {
		this.pos = pos;
		this.stack = stack;
	}

	@Override
	public void render(class_4587 ms, SuperRenderTypeBuffer buffer, class_243 camera, float pt) {
		class_310 mc = class_310.method_1551();
		ms.method_22903();

		ms.method_22904(pos.field_1352 - camera.field_1352, pos.field_1351 - camera.field_1351, pos.field_1350 - camera.field_1350);
		ms.method_22905(params.alpha, params.alpha, params.alpha);

		mc.method_1480().method_23179(stack, class_811.field_4319, false, ms,
									buffer, class_765.field_32767, class_4608.field_21444,
									mc.method_1480().method_4019(stack, null, null, 0));

		ms.method_22909();
	}
}
