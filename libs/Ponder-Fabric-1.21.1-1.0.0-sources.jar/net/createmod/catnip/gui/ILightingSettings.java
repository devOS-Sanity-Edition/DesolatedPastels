package net.createmod.catnip.gui;

import net.minecraft.class_308;

public interface ILightingSettings {

	void applyLighting();

	static final ILightingSettings DEFAULT_3D = class_308::method_24211;
	static final ILightingSettings DEFAULT_FLAT = class_308::method_24210;

}
