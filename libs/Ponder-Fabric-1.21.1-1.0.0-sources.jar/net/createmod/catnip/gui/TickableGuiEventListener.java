package net.createmod.catnip.gui;

import net.minecraft.class_364;

public interface TickableGuiEventListener extends class_364 {
	void tick();
}
