package net.createmod.catnip.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import javax.annotation.Nonnull;

import org.lwjgl.opengl.GL30;

import com.mojang.blaze3d.systems.RenderSystem;
import net.createmod.catnip.gui.element.BoxElement;
import net.createmod.catnip.gui.element.TextStencilElement;
import net.createmod.catnip.gui.widget.AbstractSimiWidget;
import net.createmod.catnip.gui.widget.BoxWidget;
import net.createmod.catnip.platform.CatnipClientServices;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_5348;

public class ConfirmationScreen extends AbstractSimiScreen {

	private class_437 source;
	private Consumer<Response> action = _success -> {};
	private final List<class_5348> text = new ArrayList<>();
	private boolean centered = false;
	private int x;
	private int y;
	private int textWidth;
	private int textHeight;
	private boolean tristate;

	private BoxWidget confirm;
	private BoxWidget confirmDontSave;
	private BoxWidget cancel;
	private BoxElement textBackground;

	public enum Response {
		Confirm, ConfirmDontSave, Cancel
	}

	/*
	 * Removes text lines from the back of the list
	 * */
	public ConfirmationScreen removeTextLines(int amount) {
		if (amount > text.size())
			return clearText();

		text.subList(text.size() - amount, text.size()).clear();
		return this;
	}

	public ConfirmationScreen clearText() {
		this.text.clear();
		return this;
	}

	public ConfirmationScreen addText(class_5348 text) {
		this.text.add(text);
		return this;
	}

	public ConfirmationScreen withText(class_5348 text) {
		return clearText().addText(text);
	}

	public ConfirmationScreen at(int x, int y) {
		this.x = Math.max(x, 0);
		this.y = Math.max(y, 0);
		this.centered = false;
		return this;
	}

	public ConfirmationScreen centered() {
		this.centered = true;
		return this;
	}

	public ConfirmationScreen withAction(Consumer<Boolean> action) {
		this.action = r -> action.accept(r == Response.Confirm);
		return this;
	}

	public ConfirmationScreen withThreeActions(Consumer<Response> action) {
		this.action = action;
		this.tristate = true;
		return this;
	}

	public void open(@Nonnull class_437 source) {
		this.source = source;
		class_310 client = CatnipClientServices.CLIENT_HOOKS.getMinecraftFromScreen(source);
		this.method_25423(client, client.method_22683().method_4486(), client.method_22683().method_4502());
		this.field_22787.field_1755 = this;
	}

	@Override
	public void method_25393() {
		super.method_25393();
		source.method_25393();
	}

	@Override
	protected void method_25426() {
		super.method_25426();

		ArrayList<class_5348> copy = new ArrayList<>(text);
		text.clear();
		copy.forEach(t -> text.addAll(field_22793.method_27527().method_27495(t, 300, class_2583.field_24360)));

		textHeight = text.size() * (field_22793.field_2000 + 1) + 4;
		textWidth = 300;

		if (centered) {
			x = field_22789/2 - textWidth/2 - 2;
			y = field_22790/2 - textHeight/2 - 16;
		} else {
			x = Math.max(0, x - textWidth / 2);
			y = Math.max(0, y -= textHeight);
		}

		if (x + textWidth > field_22789) {
			x = field_22789 - textWidth;
		}

		if (y + textHeight + 30 > field_22790) {
			y = field_22790 - textHeight - 30;
		}

		int buttonX = x + textWidth / 2 - 6 - (int) (70 * (tristate ? 1.5f : 1));

		TextStencilElement confirmText =
				new TextStencilElement(field_22793, tristate ? "Save" : "Confirm").centered(true, true);
		confirm = new BoxWidget(buttonX, y + textHeight + 6, 70, 16).withCallback(() -> accept(Response.Confirm));
		confirm.showingElement(confirmText.withElementRenderer(BoxWidget.gradientFactory.apply(confirm)));
		method_37063(confirm);

		buttonX += 12 + 70;

		if (tristate) {
			TextStencilElement confirmDontSaveText =
					new TextStencilElement(field_22793, "Don't Save").centered(true, true);
			confirmDontSave =
					new BoxWidget(buttonX, y + textHeight + 6, 70, 16).withCallback(() -> accept(Response.ConfirmDontSave));
			confirmDontSave.showingElement(
					confirmDontSaveText.withElementRenderer(BoxWidget.gradientFactory.apply(confirmDontSave)));
			method_37063(confirmDontSave);
			buttonX += 12 + 70;
		}

		TextStencilElement cancelText = new TextStencilElement(field_22793, "Cancel").centered(true, true);
		cancel = new BoxWidget(buttonX, y + textHeight + 6, 70, 16)
				.withCallback(() -> accept(Response.Cancel));
		cancel.showingElement(cancelText.withElementRenderer(BoxWidget.gradientFactory.apply(cancel)));
		method_37063(cancel);

		textBackground = new BoxElement()
				.withBackground(BoxElement.COLOR_BACKGROUND_FLAT)
				.gradientBorder(AbstractSimiWidget.COLOR_DISABLED)
				.withBounds(field_22789 + 10, textHeight + 35)
				.at(-5, y - 5);

		if (text.size() == 1)
			x = (field_22789 - field_22793.method_27525(text.get(0))) / 2;
	}

	@Override
	public void method_25419() {
		accept(Response.Cancel);
	}

	private void accept(Response success) {
		field_22787.field_1755 = source;
		action.accept(success);
	}

	@Override
	protected void renderWindow(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		textBackground.render(graphics);
		int offset = field_22793.field_2000 + 1;
		int lineY = y - offset;

		class_4587 poseStack = graphics.method_51448();
		poseStack.method_22903();
		poseStack.method_46416(0, 0, 200);

		for (class_5348 line : text) {
			lineY += offset;
			if (line == null)
				continue;
			graphics.method_51433(field_22793, line.getString(), x, lineY, 0xeaeaea, false);
		}

		poseStack.method_22909();
	}

	@Override
	protected void renderWindowBackground(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		endFrame();

		source.method_25394(graphics, 0, 0, 10); // zero mouse coords to prevent further tooltips

		prepareFrame();

		graphics.method_25296(0, 0, this.field_22789, this.field_22790, 0x70101010, 0x80101010);
	}


	@Override
	protected void prepareFrame() {
		UIRenderHelper.swapAndBlitColor(field_22787.method_1522(), UIRenderHelper.framebuffer);
		RenderSystem.clear(GL30.GL_STENCIL_BUFFER_BIT | GL30.GL_DEPTH_BUFFER_BIT, class_310.field_1703);
	}

	@Override
	protected void endFrame() {
		UIRenderHelper.swapAndBlitColor(UIRenderHelper.framebuffer, field_22787.method_1522());
	}

	@Override
	public void method_25410(@Nonnull class_310 client, int width, int height) {
		super.method_25410(client, width, height);
		source.method_25410(client, width, height);
	}

	@Override
	public boolean method_25421() {
		return true;
	}
}
