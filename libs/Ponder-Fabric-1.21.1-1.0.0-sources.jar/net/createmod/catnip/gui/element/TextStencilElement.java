package net.createmod.catnip.gui.element;

import net.createmod.catnip.theme.Color;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_5250;

public class TextStencilElement extends DelegatedStencilElement {

	protected class_327 font;
	protected class_5250 component = class_2561.method_43473();
	protected boolean centerVertically = false;
	protected boolean centerHorizontally = false;

	public TextStencilElement(class_327 font) {
		super();
		this.font = font;
		height = 10;
	}

	public TextStencilElement(class_327 font, String text) {
		this(font);
		component = class_2561.method_43470(text);
	}

	public TextStencilElement(class_327 font, class_5250 component) {
		this(font);
		this.component = component;
	}

	public TextStencilElement withText(String text) {
		component = class_2561.method_43470(text);
		return this;
	}

	public TextStencilElement withText(class_5250 component) {
		this.component = component;
		return this;
	}

	public TextStencilElement centered(boolean vertical, boolean horizontal) {
		this.centerVertically = vertical;
		this.centerHorizontally = horizontal;
		return this;
	}

	@Override
	public void renderStencil(class_332 graphics) {

		float x = 0, y = 0;
		if (centerHorizontally)
			x = width / 2f - font.method_27525(component) / 2f;

		if (centerVertically)
			y = height / 2f - (font.field_2000 - 1) / 2f;

		graphics.method_51439(font, component, Math.round(x), Math.round(y), Color.BLACK.getRGB(), false);
		graphics.method_51452();
	}

	@Override
	public void renderElement(class_332 graphics) {
		float x = 0, y = 0;
		if (centerHorizontally)
			x = width / 2f - font.method_27525(component) / 2f;

		if (centerVertically)
			y = height / 2f - (font.field_2000 - 1) / 2f;

		class_4587 poseStack = graphics.method_51448();
		poseStack.method_22903();
		poseStack.method_46416(x, y, 0);
		element.render(graphics, font.method_27525(component), font.field_2000 + 2, alpha);
		poseStack.method_22909();
	}

	public class_5250 getComponent() {
		return component;
	}
}
