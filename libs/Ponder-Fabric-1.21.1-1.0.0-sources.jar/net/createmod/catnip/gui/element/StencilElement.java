package net.createmod.catnip.gui.element;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_310;
import net.minecraft.class_332;
import org.lwjgl.opengl.GL11;

public interface StencilElement extends RenderElement {

	@Override
	default void render(class_332 graphics) {
		graphics.method_51448().method_22903();
		transform(graphics);
		prepareStencil(graphics);
		renderStencil(graphics);
		prepareElement(graphics);
		renderElement(graphics);
		cleanUp(graphics);
		graphics.method_51448().method_22909();
	}

	void renderStencil(class_332 graphics);

	void renderElement(class_332 graphics);

	default void transform(class_332 graphics) {
		graphics.method_51448().method_46416(getX(), getY(), getZ());
	}

	default void prepareStencil(class_332 graphics) {
		graphics.method_51452();
		GL11.glDisable(GL11.GL_STENCIL_TEST);
		RenderSystem.stencilMask(~0);
		RenderSystem.clear(GL11.GL_STENCIL_BUFFER_BIT, class_310.field_1703);
		GL11.glEnable(GL11.GL_STENCIL_TEST);
		RenderSystem.stencilOp(GL11.GL_REPLACE, GL11.GL_KEEP, GL11.GL_KEEP);
		RenderSystem.stencilMask(0xFF);
		RenderSystem.stencilFunc(GL11.GL_NEVER, 1, 0xFF);
	}

	default void prepareElement(class_332 graphics) {
		GL11.glEnable(GL11.GL_STENCIL_TEST);
		RenderSystem.stencilOp(GL11.GL_KEEP, GL11.GL_KEEP, GL11.GL_KEEP);
		RenderSystem.stencilFunc(GL11.GL_EQUAL, 1, 0xFF);
	}

	default void cleanUp(class_332 graphics) {
		GL11.glDisable(GL11.GL_STENCIL_TEST);
		graphics.method_51452();

	}
}
