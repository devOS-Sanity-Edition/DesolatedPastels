package net.createmod.catnip.gui.element;

import net.minecraft.class_332;

@FunctionalInterface
public interface FadableScreenElement extends ScreenElement {

	@Override
	default void render(class_332 graphics, int x, int y) {
		render(graphics, x, y, 1f);
	}

	void render(class_332 graphics, int x, int y, float alpha);

}
