package net.createmod.catnip.gui.element;

import org.joml.Matrix4f;

import com.mojang.blaze3d.systems.RenderSystem;
import net.createmod.catnip.data.Couple;
import net.createmod.catnip.theme.Color;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_757;

public class BoxElement extends AbstractRenderElement {

	public static final Couple<Color> COLOR_VANILLA_BORDER = Couple.create(
		new Color(0x50_5000ff, true),
		new Color(0x50_28007f, true)
	).map(Color::setImmutable);
	public static final Color COLOR_VANILLA_BACKGROUND = new Color(0xf0_100010, true).setImmutable();
	public static final Color COLOR_BACKGROUND_FLAT = new Color(0xff_000000, true).setImmutable();
	public static final Color COLOR_BACKGROUND_TRANSPARENT = new Color(0xdd_000000, true).setImmutable();

	protected Color background = COLOR_VANILLA_BACKGROUND;
	protected Color borderTop = COLOR_VANILLA_BORDER.getFirst();
	protected Color borderBot = COLOR_VANILLA_BORDER.getSecond();
	protected int borderOffset = 2;

	public <T extends BoxElement> T withBackground(Color color) {
		this.background = color;
		//noinspection unchecked
		return (T) this;
	}

	public <T extends BoxElement> T withBackground(int color) {
		return withBackground(new Color(color, true));
	}

	public <T extends BoxElement> T flatBorder(Color color) {
		this.borderTop = color;
		this.borderBot = color;
		//noinspection unchecked
		return (T) this;
	}

	public <T extends BoxElement> T flatBorder(int color) {
		return flatBorder(new Color(color, true));
	}

	public <T extends BoxElement> T gradientBorder(Couple<Color> colors) {
		this.borderTop = colors.getFirst();
		this.borderBot = colors.getSecond();
		//noinspection unchecked
		return (T) this;
	}

	public <T extends BoxElement> T gradientBorder(Color top, Color bot) {
		this.borderTop = top;
		this.borderBot = bot;
		//noinspection unchecked
		return (T) this;
	}

	public <T extends BoxElement> T gradientBorder(int top, int bot) {
		return gradientBorder(new Color(top, true), new Color(bot, true));
	}

	public <T extends BoxElement> T withBorderOffset(int offset) {
		this.borderOffset = offset;
		//noinspection unchecked
		return (T) this;
	}

	@Override
	public void render(class_332 graphics) {
		renderBox(graphics);
	}

	//total box width = 1 * 2 (outer border) + 1 * 2 (inner color border) + 2 * borderOffset + width
	//defaults to 2 + 2 + 4 + 16 = 24px
	//batch everything together to save a bunch of gl calls over ScreenUtils
	protected void renderBox(class_332 graphics) {
		/*
		 *          _____________
		 *        _|_____________|_
		 *       | | ___________ | |
		 *       | | |  |      | | |
		 *       | | |  |      | | |
		 *       | | |--*   |  | | |
		 *       | | |      h  | | |
		 *       | | |  --w-+  | | |
		 *       | | |         | | |
		 *       | | |_________| | |
		 *       |_|_____________|_|
		 *         |_____________|
		 *
		 * */
		//RenderSystem.disableTexture();
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.setShader(class_757::method_34540);

		class_4587 ms = graphics.method_51448();
		Matrix4f model = ms.method_23760().method_23761();
		int f = borderOffset;
		Color c1 = background.copy().scaleAlpha(alpha);
		Color c2 = borderTop.copy().scaleAlpha(alpha);
		Color c3 = borderBot.copy().scaleAlpha(alpha);
		class_289 tesselator = class_289.method_1348();
		class_287 b = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1576);

		//outer top
		b.method_22918(model, x - f - 1        , y - f - 2         , z).method_1336(c1.getRed(), c1.getGreen(), c1.getBlue(), c1.getAlpha());
		b.method_22918(model, x - f - 1        , y - f - 1         , z).method_1336(c1.getRed(), c1.getGreen(), c1.getBlue(), c1.getAlpha());
		b.method_22918(model, x + f + 1 + width, y - f - 1         , z).method_1336(c1.getRed(), c1.getGreen(), c1.getBlue(), c1.getAlpha());
		b.method_22918(model, x + f + 1 + width, y - f - 2         , z).method_1336(c1.getRed(), c1.getGreen(), c1.getBlue(), c1.getAlpha());
		//outer left
		b.method_22918(model, x - f - 2        , y - f - 1         , z).method_1336(c1.getRed(), c1.getGreen(), c1.getBlue(), c1.getAlpha());
		b.method_22918(model, x - f - 2        , y + f + 1 + height, z).method_1336(c1.getRed(), c1.getGreen(), c1.getBlue(), c1.getAlpha());
		b.method_22918(model, x - f - 1        , y + f + 1 + height, z).method_1336(c1.getRed(), c1.getGreen(), c1.getBlue(), c1.getAlpha());
		b.method_22918(model, x - f - 1        , y - f - 1         , z).method_1336(c1.getRed(), c1.getGreen(), c1.getBlue(), c1.getAlpha());
		//outer bottom
		b.method_22918(model, x - f - 1        , y + f + 1 + height, z).method_1336(c1.getRed(), c1.getGreen(), c1.getBlue(), c1.getAlpha());
		b.method_22918(model, x - f - 1        , y + f + 2 + height, z).method_1336(c1.getRed(), c1.getGreen(), c1.getBlue(), c1.getAlpha());
		b.method_22918(model, x + f + 1 + width, y + f + 2 + height, z).method_1336(c1.getRed(), c1.getGreen(), c1.getBlue(), c1.getAlpha());
		b.method_22918(model, x + f + 1 + width, y + f + 1 + height, z).method_1336(c1.getRed(), c1.getGreen(), c1.getBlue(), c1.getAlpha());
		//outer right
		b.method_22918(model, x + f + 1 + width, y - f - 1         , z).method_1336(c1.getRed(), c1.getGreen(), c1.getBlue(), c1.getAlpha());
		b.method_22918(model, x + f + 1 + width, y + f + 1 + height, z).method_1336(c1.getRed(), c1.getGreen(), c1.getBlue(), c1.getAlpha());
		b.method_22918(model, x + f + 2 + width, y + f + 1 + height, z).method_1336(c1.getRed(), c1.getGreen(), c1.getBlue(), c1.getAlpha());
		b.method_22918(model, x + f + 2 + width, y - f - 1         , z).method_1336(c1.getRed(), c1.getGreen(), c1.getBlue(), c1.getAlpha());
		//inner background - also render behind the inner edges
		b.method_22918(model, x - f - 1        , y - f - 1         , z).method_1336(c1.getRed(), c1.getGreen(), c1.getBlue(), c1.getAlpha());
		b.method_22918(model, x - f - 1        , y + f + 1 + height, z).method_1336(c1.getRed(), c1.getGreen(), c1.getBlue(), c1.getAlpha());
		b.method_22918(model, x + f + 1 + width, y + f + 1 + height, z).method_1336(c1.getRed(), c1.getGreen(), c1.getBlue(), c1.getAlpha());
		b.method_22918(model, x + f + 1 + width, y - f - 1         , z).method_1336(c1.getRed(), c1.getGreen(), c1.getBlue(), c1.getAlpha());
		class_286.method_43433(b.method_60800());
		b = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1576);
		//inner top - includes corners
		b.method_22918(model, x - f - 1        , y - f - 1         , z).method_1336(c2.getRed(), c2.getGreen(), c2.getBlue(), c2.getAlpha());
		b.method_22918(model, x - f - 1        , y - f             , z).method_1336(c2.getRed(), c2.getGreen(), c2.getBlue(), c2.getAlpha());
		b.method_22918(model, x + f + 1 + width, y - f             , z).method_1336(c2.getRed(), c2.getGreen(), c2.getBlue(), c2.getAlpha());
		b.method_22918(model, x + f + 1 + width, y - f - 1         , z).method_1336(c2.getRed(), c2.getGreen(), c2.getBlue(), c2.getAlpha());
		//inner left - excludes corners
		b.method_22918(model, x - f - 1        , y - f             , z).method_1336(c2.getRed(), c2.getGreen(), c2.getBlue(), c2.getAlpha());
		b.method_22918(model, x - f - 1        , y + f     + height, z).method_1336(c3.getRed(), c3.getGreen(), c3.getBlue(), c3.getAlpha());
		b.method_22918(model, x - f            , y + f     + height, z).method_1336(c3.getRed(), c3.getGreen(), c3.getBlue(), c3.getAlpha());
		b.method_22918(model, x - f            , y - f             , z).method_1336(c2.getRed(), c2.getGreen(), c2.getBlue(), c2.getAlpha());
		//inner bottom - includes corners
		b.method_22918(model, x - f - 1        , y + f     + height, z).method_1336(c3.getRed(), c3.getGreen(), c3.getBlue(), c3.getAlpha());
		b.method_22918(model, x - f - 1        , y + f + 1 + height, z).method_1336(c3.getRed(), c3.getGreen(), c3.getBlue(), c3.getAlpha());
		b.method_22918(model, x + f + 1 + width, y + f + 1 + height, z).method_1336(c3.getRed(), c3.getGreen(), c3.getBlue(), c3.getAlpha());
		b.method_22918(model, x + f + 1 + width, y + f     + height, z).method_1336(c3.getRed(), c3.getGreen(), c3.getBlue(), c3.getAlpha());
		//inner right - excludes corners
		b.method_22918(model, x + f     + width, y - f             , z).method_1336(c2.getRed(), c2.getGreen(), c2.getBlue(), c2.getAlpha());
		b.method_22918(model, x + f     + width, y + f     + height, z).method_1336(c3.getRed(), c3.getGreen(), c3.getBlue(), c3.getAlpha());
		b.method_22918(model, x + f + 1 + width, y + f     + height, z).method_1336(c3.getRed(), c3.getGreen(), c3.getBlue(), c3.getAlpha());
		b.method_22918(model, x + f + 1 + width, y - f             , z).method_1336(c2.getRed(), c2.getGreen(), c2.getBlue(), c2.getAlpha());

		class_286.method_43433(b.method_60800());

		RenderSystem.disableBlend();
		//RenderSystem.enableTexture();
	}
}
