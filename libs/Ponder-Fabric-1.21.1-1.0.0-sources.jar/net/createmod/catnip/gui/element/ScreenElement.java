package net.createmod.catnip.gui.element;

import net.minecraft.class_332;

public interface ScreenElement {

	void render(class_332 graphics, int x, int y);
}
