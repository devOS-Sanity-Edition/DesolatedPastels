package net.createmod.catnip.gui;

import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nullable;

import net.createmod.catnip.data.Couple;
import net.createmod.catnip.theme.Color;
import net.minecraft.class_1041;
import net.minecraft.class_276;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_5944;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import net.minecraft.class_8251;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import com.mojang.blaze3d.platform.GlConst;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.createmod.catnip.platform.CatnipClientServices;

public class UIRenderHelper {

	public static final Couple<Color> COLOR_TEXT = Couple.create(
		new Color(0xff_eeeeee),
		new Color(0xff_a3a3a3)
	).map(Color::setImmutable);
	public static final Couple<Color> COLOR_TEXT_DARKER = Couple.create(
		new Color(0xff_a3a3a3),
		new Color(0xff_808080)
	).map(Color::setImmutable);
	public static final Couple<Color> COLOR_TEXT_ACCENT = Couple.create(
		new Color(0xff_ddeeff),
		new Color(0xff_a0b0c0)
	).map(Color::setImmutable);
	public static final Couple<Color> COLOR_TEXT_STRONG_ACCENT = Couple.create(
		new Color(0xff_8ab6d6),
		new Color(0xff_6e92ab)
	).map(Color::setImmutable);

	public static final Color COLOR_STREAK = new Color(0x101010, false).setImmutable();

	/**
	 * An FBO that has a stencil buffer for use wherever stencil are necessary. Forcing the main FBO to have a stencil
	 * buffer will cause GL error spam when using fabulous graphics.
	 */
	@Nullable
	public static CustomRenderTarget framebuffer;

	public static void init() {
		RenderSystem.recordRenderCall(() -> {
			class_1041 mainWindow = class_310.method_1551().method_22683();
			framebuffer = CustomRenderTarget.create(mainWindow);
		});
	}

	public static void updateWindowSize(class_1041 mainWindow) {
		if (framebuffer != null)
			framebuffer.method_1234(mainWindow.method_4489(), mainWindow.method_4506(), class_310.field_1703);
	}

	public static void drawFramebuffer(class_4587 poseStack, float alpha) {
		if (framebuffer != null)
			framebuffer.renderWithAlpha(poseStack, alpha);
	}

	/**
	 * Switch from src to dst, after copying the contents of src to dst.
	 */
	public static void swapAndBlitColor(class_276 src, class_276 dst) {
		GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, src.field_1476);
		GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, dst.field_1476);
		GlStateManager._glBlitFrameBuffer(0, 0, src.field_1480, src.field_1477, 0, 0, dst.field_1480, dst.field_1477, GL30.GL_COLOR_BUFFER_BIT, GL20.GL_LINEAR);

		GlStateManager._glBindFramebuffer(GlConst.GL_FRAMEBUFFER, dst.field_1476);
	}

	/**
	 * @param angle angle in degrees, 0 means fading to the right
	 * @param x x-position of the starting edge middle point
	 * @param y y-position of the starting edge middle point
	 * @param breadth total width of the streak
	 * @param length total length of the streak
	 */
	public static void streak(class_332 graphics, float angle, int x, int y, int breadth, int length) {
		streak(graphics, angle, x, y, breadth, length, COLOR_STREAK);
	}

	public static void streak(class_332 graphics, float angle, int x, int y, int breadth, int length, Color c) {
		Color color = c.copy().setImmutable();
		Color c1 = color.scaleAlpha(0.625f);
		Color c2 = color.scaleAlpha(0.5f);
		Color c3 = color.scaleAlpha(0.0625f);
		Color c4 = color.scaleAlpha(0f);

		class_4587 poseStack = graphics.method_51448();
		poseStack.method_22903();
		poseStack.method_46416(x, y, 0);
		poseStack.method_22907(class_7833.field_40718.rotationDegrees(angle - 90));

		streak(graphics, breadth / 2, length, c1, c2, c3, c4);

		poseStack.method_22909();
	}

	private static void streak(class_332 graphics, int width, int height, Color c1, Color c2, Color c3, Color c4) {
		if (NavigatableSimiScreen.isCurrentlyRenderingPreviousScreen())
			return;

		double split1 = .5;
		double split2 = .75;
		graphics.method_25296(-width, 0, width, (int) (split1 * height), c1.getRGB(), c2.getRGB());
		graphics.method_25296(-width, (int) (split1 * height), width, (int) (split2 * height), c2.getRGB(), c3.getRGB());
		graphics.method_25296(-width, (int) (split2 * height), width, height, c3.getRGB(), c4.getRGB());
	}

	/**
	 * @see #angledGradient(class_332, float, int, int, int, float, float, Color, Color)
	 */
	public static void angledGradient(class_332 graphics, float angle, int x, int y, float breadth, float length, Couple<Color> c) {
		angledGradient(graphics, angle, x, y, 0, breadth, length, c);
	}

	/**
	 * @see #angledGradient(class_332, float, int, int, int, float, float, Color, Color)
	 */
	public static void angledGradient(class_332 graphics, float angle, int x, int y, int z, float breadth, float length, Couple<Color> c) {
		angledGradient(graphics, angle, x, y, z, breadth, length, c.getFirst(), c.getSecond());
	}

	/**
	 * @see #angledGradient(class_332, float, int, int, int, float, float, Color, Color)
	 */
	public static void angledGradient(class_332 graphics, float angle, int x, int y, float breadth, float length, Color color1, Color color2) {
		angledGradient(graphics, angle, x, y, 0, breadth, length, color1, color2);
	}

	/**
	 * x and y specify the middle point of the starting edge
	 *
	 * @param angle   the angle of the gradient in degrees; 0° means from left to right
	 * @param startColor  the color at the starting edge
	 * @param endColor  the color at the ending edge
	 * @param breadth the total width of the gradient
	 */
	public static void angledGradient(class_332 graphics, float angle, int x, int y, int z, float breadth, float length, Color startColor, Color endColor) {
		class_4587 poseStack = graphics.method_51448();
		poseStack.method_22903();
		poseStack.method_46416(x, y, z);
		poseStack.method_22907(class_7833.field_40718.rotationDegrees(angle - 90));

		float w = breadth / 2;
		//graphics.fillGradient(-w, 0, w, length, startColor.getRGB(), endColor.getRGB());
		drawGradientRect(poseStack.method_23760().method_23761(), 0, -w, 0f, w, length, startColor, endColor);

		poseStack.method_22909();
	}

	public static void drawGradientRect(Matrix4f mat, int zLevel, float left, float top, float right, float bottom, Color startColor, Color endColor) {
		RenderSystem.enableDepthTest();
		//RenderSystem.disableTexture();
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.setShader(class_757::method_34540);

		class_289 tesselator = class_289.method_1348();
		class_287 buffer = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1576);
		buffer.method_22918(mat, right,    top, zLevel).method_1336(startColor.getRed(), startColor.getGreen(), startColor.getBlue(), startColor.getAlpha());
		buffer.method_22918(mat,  left,    top, zLevel).method_1336(startColor.getRed(), startColor.getGreen(), startColor.getBlue(), startColor.getAlpha());
		buffer.method_22918(mat,  left, bottom, zLevel).method_1336(  endColor.getRed(),   endColor.getGreen(),   endColor.getBlue(),   endColor.getAlpha());
		buffer.method_22918(mat, right, bottom, zLevel).method_1336(  endColor.getRed(),   endColor.getGreen(),   endColor.getBlue(),   endColor.getAlpha());
		class_286.method_43433(buffer.method_60800());

		RenderSystem.disableBlend();
		//RenderSystem.enableTexture();
	}

	public static void breadcrumbArrow(class_332 graphics, int x, int y, int z, int width, int height, int indent, Couple<Color> colors) {breadcrumbArrow(graphics, x, y, z, width, height, indent, colors.getFirst(), colors.getSecond());}

	// draws a wide chevron-style breadcrumb arrow pointing left
	public static void breadcrumbArrow(class_332 graphics, int x, int y, int z, int width, int height, int indent, Color startColor, Color endColor) {
		class_4587 poseStack = graphics.method_51448();
		poseStack.method_22903();
		poseStack.method_46416(x - indent, y, z);

		breadcrumbArrow(graphics, width, height, indent, startColor, endColor);

		poseStack.method_22909();
	}

	private static void breadcrumbArrow(class_332 graphics, int width, int height, int indent, Color c1, Color c2) {

		/*
		 * 0,0       x1,y0 ********************* x2,y0 ***** x3,y0
		 *       ****                                     ****
		 *   ****                                     ****
		 * x0,y1     x1,y1                       x2,y1
		 *   ****                                     ****
		 *       ****                                     ****
		 *           x1,y2 ********************* x2,y2 ***** x3,y2
		 *
		 */

		float x0 = 0;
		float x1 = indent;
		float x2 = width;
		float x3 = indent + width;

		float y0 = 0;
		float y1 = height / 2f;
		float y2 = height;

		indent = Math.abs(indent);
		width = Math.abs(width);
		Color fc1 = Color.mixColors(c1, c2, 0);
		Color fc2 = Color.mixColors(c1, c2, (indent) / (width + 2f * indent));
		Color fc3 = Color.mixColors(c1, c2, (indent + width) / (width + 2f * indent));
		Color fc4 = Color.mixColors(c1, c2, 1);

		RenderSystem.disableDepthTest();
		RenderSystem.enableBlend();
		RenderSystem.disableCull();
		RenderSystem.defaultBlendFunc();
		RenderSystem.setShader(class_757::method_34540);

		class_289 tessellator = class_289.method_1348();
		class_287 bufferbuilder = tessellator.method_60827(class_293.class_5596.field_27379, class_290.field_1576);
		Matrix4f model = graphics.method_51448().method_23760().method_23761();

		bufferbuilder.method_22918(model, x0, y1, 0).method_1336(fc1.getRed(), fc1.getGreen(), fc1.getBlue(), fc1.getAlpha());
		bufferbuilder.method_22918(model, x1, y0, 0).method_1336(fc2.getRed(), fc2.getGreen(), fc2.getBlue(), fc2.getAlpha());
		bufferbuilder.method_22918(model, x1, y1, 0).method_1336(fc2.getRed(), fc2.getGreen(), fc2.getBlue(), fc2.getAlpha());

		bufferbuilder.method_22918(model, x0, y1, 0).method_1336(fc1.getRed(), fc1.getGreen(), fc1.getBlue(), fc1.getAlpha());
		bufferbuilder.method_22918(model, x1, y1, 0).method_1336(fc2.getRed(), fc2.getGreen(), fc2.getBlue(), fc2.getAlpha());
		bufferbuilder.method_22918(model, x1, y2, 0).method_1336(fc2.getRed(), fc2.getGreen(), fc2.getBlue(), fc2.getAlpha());

		bufferbuilder.method_22918(model, x1, y2, 0).method_1336(fc2.getRed(), fc2.getGreen(), fc2.getBlue(), fc2.getAlpha());
		bufferbuilder.method_22918(model, x1, y0, 0).method_1336(fc2.getRed(), fc2.getGreen(), fc2.getBlue(), fc2.getAlpha());
		bufferbuilder.method_22918(model, x2, y0, 0).method_1336(fc3.getRed(), fc3.getGreen(), fc3.getBlue(), fc3.getAlpha());

		bufferbuilder.method_22918(model, x1, y2, 0).method_1336(fc2.getRed(), fc2.getGreen(), fc2.getBlue(), fc2.getAlpha());
		bufferbuilder.method_22918(model, x2, y0, 0).method_1336(fc3.getRed(), fc3.getGreen(), fc3.getBlue(), fc3.getAlpha());
		bufferbuilder.method_22918(model, x2, y2, 0).method_1336(fc3.getRed(), fc3.getGreen(), fc3.getBlue(), fc3.getAlpha());

		bufferbuilder.method_22918(model, x2, y1, 0).method_1336(fc3.getRed(), fc3.getGreen(), fc3.getBlue(), fc3.getAlpha());
		bufferbuilder.method_22918(model, x2, y0, 0).method_1336(fc3.getRed(), fc3.getGreen(), fc3.getBlue(), fc3.getAlpha());
		bufferbuilder.method_22918(model, x3, y0, 0).method_1336(fc4.getRed(), fc4.getGreen(), fc4.getBlue(), fc4.getAlpha());

		bufferbuilder.method_22918(model, x2, y2, 0).method_1336(fc3.getRed(), fc3.getGreen(), fc3.getBlue(), fc3.getAlpha());
		bufferbuilder.method_22918(model, x2, y1, 0).method_1336(fc3.getRed(), fc3.getGreen(), fc3.getBlue(), fc3.getAlpha());
		bufferbuilder.method_22918(model, x3, y2, 0).method_1336(fc4.getRed(), fc4.getGreen(), fc4.getBlue(), fc4.getAlpha());

		class_286.method_43433(bufferbuilder.method_60800());
		RenderSystem.enableCull();
		RenderSystem.disableBlend();
		//RenderSystem.enableTexture();
	}

	/**
	 * centered on 0, 0
	 *
	 * @param arcAngle length of the sector arc
	 */
	public static void drawRadialSector(class_332 graphics, float innerRadius, float outerRadius, float startAngle, float arcAngle, Color innerColor, Color outerColor) {
		List<Point2D> innerPoints = getPointsForCircleArc(innerRadius, startAngle, arcAngle);
		List<Point2D> outerPoints = getPointsForCircleArc(outerRadius, startAngle, arcAngle);

		// if arcAngle > 0, start with inner. otherwise start with outer

		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.setShader(class_757::method_34540);

		class_287 builder = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);

		Matrix4f pose = graphics.method_51448().method_23760().method_23761();
		Matrix3f n = graphics.method_51448().method_23760().method_23762();

		for (int i = 0; i < innerPoints.size(); i++) {
			Point2D point = outerPoints.get(i);
			//builder.addVertex(pose, (float) point.getX(), (float) point.getY(), 0).setColor(innerColor.getRGB()).normal(n, 1, 1, 0);
			builder.method_22918(pose, (float) point.getX(), (float) point.getY(), 0).method_39415(outerColor.getRGB());

			point = innerPoints.get(i);
			builder.method_22918(pose, (float) point.getX(), (float) point.getY(), 0).method_39415(innerColor.getRGB());
		}

		class_286.method_43433(builder.method_60800());

		RenderSystem.disableBlend();

	}

	private static List<Point2D> getPointsForCircleArc(float radius, float startAngle, float arcAngle) {
		int segmentCount = Math.abs(arcAngle) <= 90 ? 16 : 32;
		List<Point2D> points = new ArrayList<>(segmentCount);


		float theta = (class_3532.field_29847 * arcAngle) / (float) (segmentCount - 1);
		float t = class_3532.field_29847 * startAngle;

		for (int i = 0; i < segmentCount; i++) {
			points.add(new Point2D.Float(
					(float) (radius * Math.cos(t)),
					(float) (radius * Math.sin(t))
			));

			t += theta;
		}

		return points;
	}


	//just like AbstractGui#drawTexture, but with a color at every vertex
	public static void drawColoredTexture(class_332 graphics, Color c, int x, int y, int tex_left, int tex_top, int width, int height) {
		drawColoredTexture(graphics, c, x, y, 0, (float) tex_left, (float) tex_top, width, height, 256, 256);
	}

	public static void drawColoredTexture(class_332 graphics, Color c, int x, int y, int z, float tex_left, float tex_top, int width, int height, int sheet_width, int sheet_height) {
		drawColoredTexture(graphics, c, x, x + width, y, y + height, z, width, height, tex_left, tex_top, sheet_width, sheet_height);
	}

	public static void drawStretched(class_332 graphics, int left, int top, int w, int h, int z, TextureSheetSegment tex) {
		tex.bind();
		drawTexturedQuad(graphics.method_51448().method_23760()
						.method_23761(), Color.WHITE, left, left + w, top, top + h, z, tex.getStartX() / 256f, (tex.getStartX() + tex.getWidth()) / 256f,
				tex.getStartY() / 256f, (tex.getStartY() + tex.getHeight()) / 256f);
	}

	public static void drawCropped(class_332 graphics, int left, int top, int w, int h, int z, TextureSheetSegment tex) {
		tex.bind();
		drawTexturedQuad(graphics.method_51448().method_23760()
						.method_23761(), Color.WHITE, left, left + w, top, top + h, z, tex.getStartX() / 256f, (tex.getStartX() + w) / 256f,
				tex.getStartY() / 256f, (tex.getStartY() + h) / 256f);
	}

	private static void drawColoredTexture(class_332 graphics, Color c, int left, int right, int top, int bot, int z, int tex_width, int tex_height, float tex_left, float tex_top, int sheet_width, int sheet_height) {
		drawTexturedQuad(graphics.method_51448().method_23760().method_23761(), c, left, right, top, bot, z, (tex_left + 0.0F) / (float) sheet_width, (tex_left + (float) tex_width) / (float) sheet_width, (tex_top + 0.0F) / (float) sheet_height, (tex_top + (float) tex_height) / (float) sheet_height);
	}

	private static void drawTexturedQuad(Matrix4f m, Color c, int left, int right, int top, int bot, int z, float u1, float u2, float v1, float v2) {
		class_289 tesselator = class_289.method_1348();
		class_287 bufferbuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1575);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.setShader(class_757::method_34543);
		bufferbuilder.method_22918(m, (float) left , (float) bot, (float) z).method_1336(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).method_22913(u1, v2);
		bufferbuilder.method_22918(m, (float) right, (float) bot, (float) z).method_1336(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).method_22913(u2, v2);
		bufferbuilder.method_22918(m, (float) right, (float) top, (float) z).method_1336(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).method_22913(u2, v1);
		bufferbuilder.method_22918(m, (float) left , (float) top, (float) z).method_1336(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()).method_22913(u1, v1);
		class_286.method_43433(bufferbuilder.method_60800());
		RenderSystem.disableBlend();
	}

	public static void flipForGuiRender(class_4587 poseStack) {
		poseStack.method_34425(new Matrix4f().scaling(1, -1, 1));
	}

	public static class CustomRenderTarget extends class_276 {

		public CustomRenderTarget(boolean useDepth) {
			super(useDepth);
		}

		public static CustomRenderTarget create(class_1041 mainWindow) {
			CustomRenderTarget framebuffer = new CustomRenderTarget(true);
			framebuffer.method_1234(mainWindow.method_4489(), mainWindow.method_4506(), class_310.field_1703);
			framebuffer.method_1236(0, 0, 0, 0);
			CatnipClientServices.CLIENT_HOOKS.enableStencilBuffer(framebuffer);
			return framebuffer;
		}

		public void renderWithAlpha(class_4587 poseStack, float alpha) {
			class_1041 window = class_310.method_1551().method_22683();

			float guiScaledWidth = window.method_4486();
			float guiScaledHeight = window.method_4502();

			float vx = guiScaledWidth;
			float vy = guiScaledHeight;
			float tx = (float) field_1480 / (float) field_1482;
			float ty = (float) field_1477 / (float) field_1481;

			RenderSystem.disableDepthTest();

			class_310 minecraft = class_310.method_1551();
			class_5944 shaderinstance = minecraft.field_1773.field_29403;
			shaderinstance.method_34583("DiffuseSampler", field_1475);
			//Matrix4f matrix4f = Matrix4f.orthographic(guiScaledWidth, -guiScaledHeight, 1000.0F, 3000.0F);
			Matrix4f matrix4f = poseStack.method_23760().method_23761();
			Matrix4f projectionMatrix = RenderSystem.getProjectionMatrix();
			RenderSystem.setProjectionMatrix(matrix4f, class_8251.field_43361);
			if (shaderinstance.field_29470 != null) {
				shaderinstance.field_29470.method_1250(new Matrix4f().translation(0.0F, 0.0F, -2000.0F));
			}

			if (shaderinstance.field_29471 != null) {
				shaderinstance.field_29471.method_1250(matrix4f);
			}

			shaderinstance.method_34586();

			//bindRead();

			class_289 tesselator = RenderSystem.renderThreadTesselator();
			class_287 bufferbuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1575);

			bufferbuilder.method_22912(0 , vy, 0).method_22913(0 , 0 ).method_22915(1, 1, 1, alpha);
			bufferbuilder.method_22912(vx, vy, 0).method_22913(tx, 0 ).method_22915(1, 1, 1, alpha);
			bufferbuilder.method_22912(vx, 0 , 0).method_22913(tx, ty).method_22915(1, 1, 1, alpha);
			bufferbuilder.method_22912(0 , 0 , 0).method_22913(0 , ty).method_22915(1, 1, 1, alpha);

			class_286.method_43437(bufferbuilder.method_60800());

			shaderinstance.method_34585();
			RenderSystem.setProjectionMatrix(projectionMatrix, class_8251.field_43361);
			//unbindRead();
		}

	}

}
