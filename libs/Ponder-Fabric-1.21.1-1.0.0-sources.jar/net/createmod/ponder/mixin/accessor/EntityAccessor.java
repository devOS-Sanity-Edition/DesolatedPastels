package net.createmod.ponder.mixin.accessor;

import net.minecraft.class_1297;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1297.class)
public interface EntityAccessor {
	@Invoker("setLevel")
	void catnip$callSetLevel(class_1937 level);
}
