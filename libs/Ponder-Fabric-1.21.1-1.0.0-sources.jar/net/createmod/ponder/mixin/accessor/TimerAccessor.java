package net.createmod.ponder.mixin.accessor;

import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_9779.class_9781.class)
public interface TimerAccessor {
	@Accessor("deltaTickResidual")
	float catnip$getDeltaTickResidual();
}
