package net.createmod.ponder.mixin.accessor;

import net.minecraft.class_4543;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_4543.class)
public interface BiomeManagerAccessor {
	@Accessor("biomeZoomSeed")
	long catnip$getBiomeZoomSeed();
}
