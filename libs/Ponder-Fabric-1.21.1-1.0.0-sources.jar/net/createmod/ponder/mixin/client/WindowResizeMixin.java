package net.createmod.ponder.mixin.client;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.createmod.catnip.gui.UIRenderHelper;
import net.minecraft.class_1041;
import net.minecraft.class_310;

@Mixin(class_310.class)
public class WindowResizeMixin {
	@Shadow @Final private class_1041 window;

	@Inject(at = @At("TAIL"), method = "resizeDisplay")
	private void catnip$updateWindowSize(CallbackInfo ci) {
		UIRenderHelper.updateWindowSize(window);
	}
}
