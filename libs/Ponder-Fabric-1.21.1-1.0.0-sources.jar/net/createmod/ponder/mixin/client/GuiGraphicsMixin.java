package net.createmod.ponder.mixin.client;

import org.spongepowered.asm.mixin.Mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;

import net.createmod.ponder.FabricPonderClient;
import net.createmod.ponder.foundation.PonderTooltipHandler;
import net.minecraft.class_1799;
import net.minecraft.class_327;
import net.minecraft.class_332;

@Mixin(class_332.class)
public class GuiGraphicsMixin {
	@WrapMethod(method = "renderTooltip(Lnet/minecraft/client/gui/Font;Lnet/minecraft/world/item/ItemStack;II)V")
	private void setBorderColorOverride(class_327 font, class_1799 itemStack, int i, int j, Operation<Void> original) {
		FabricPonderClient.tooltipBorderColorOverride = PonderTooltipHandler.handleTooltipColor(itemStack).orElse(null);
		original.call(font, itemStack, i, j);
		FabricPonderClient.tooltipBorderColorOverride = null;
	}
}
