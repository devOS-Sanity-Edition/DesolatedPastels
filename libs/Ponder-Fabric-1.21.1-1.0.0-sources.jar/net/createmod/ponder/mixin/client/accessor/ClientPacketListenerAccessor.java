package net.createmod.ponder.mixin.client.accessor;

import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_634.class)
public interface ClientPacketListenerAccessor {
	@Accessor("serverChunkRadius")
	int catnip$getServerChunkRadius();
}
