package net.createmod.ponder.mixin.client.accessor;

import net.minecraft.class_1921;
import net.minecraft.class_293;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1921.class)
public interface RenderTypeAccessor {
	@Invoker("create")
	static class_1921.class_4687 catnip$create(String string, class_293 vertexFormat, class_293.class_5596 mode, int i, boolean bl, boolean bl2, class_1921.class_4688 compositeState) {
		throw new AssertionError("Mixin application failed!");
	}
}

