package net.createmod.ponder.mixin.client.accessor;

import net.minecraft.class_1060;
import net.minecraft.class_918;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_918.class)
public interface ItemRendererAccessor {
	@Accessor("textureManager")
	class_1060 catnip$getTextureManager();
}
