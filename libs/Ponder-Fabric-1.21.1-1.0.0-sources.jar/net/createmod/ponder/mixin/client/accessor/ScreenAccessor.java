package net.createmod.ponder.mixin.client.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_4068;
import net.minecraft.class_437;

@Mixin(class_437.class)
public interface ScreenAccessor {
	@Accessor("renderables")
	List<class_4068> catnip$getRenderables();
}
