package net.createmod.ponder.mixin.client;

import net.minecraft.class_2394;
import net.minecraft.class_702;
import net.minecraft.class_703;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_702.class)
public interface ParticleEngineAccessor {
	@Invoker("makeParticle")
	<T extends class_2394> class_703 catnip$makeParticle(T particleOptions, double x, double y, double z, double mx, double my, double mz);
}
