package net.createmod.ponder.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.createmod.catnip.render.StitchedSprite;
import net.minecraft.class_1059;
import net.minecraft.class_7766;

@Mixin(class_1059.class)
public class TextureAtlasMixin {
	@Inject(method = "upload(Lnet/minecraft/client/renderer/texture/SpriteLoader$Preparations;)V", at = @At("TAIL"))
	private void onTailReload(class_7766.class_7767 preparations, CallbackInfo ci) {
		StitchedSprite.onTextureStitchPost((class_1059) (Object) this);
	}
}
