package net.createmod.ponder.mixin.client;

import java.util.List;
import java.util.Optional;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;

import net.createmod.ponder.FabricPonderClient;
import net.createmod.ponder.foundation.PonderTooltipHandler;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_5632;

@Mixin(class_465.class)
public class AbstractContainerScreenMixin {
	@WrapOperation(
		method = "renderTooltip",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/client/gui/GuiGraphics;renderTooltip(Lnet/minecraft/client/gui/Font;Ljava/util/List;Ljava/util/Optional;II)V"
		)
	)
	private void setBorderColorOverride(
		class_332 graphics, class_327 font, List<class_2561> lines, Optional<class_5632> component, int x, int y,
		Operation<Void> original, @Local class_1799 stack
	) {
		FabricPonderClient.tooltipBorderColorOverride = PonderTooltipHandler.handleTooltipColor(stack).orElse(null);
		original.call(graphics, font, lines, component, x, y);
		FabricPonderClient.tooltipBorderColorOverride = null;
	}
}
