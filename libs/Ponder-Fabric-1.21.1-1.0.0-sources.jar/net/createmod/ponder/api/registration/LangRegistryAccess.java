package net.createmod.ponder.api.registration;

import java.util.function.BiConsumer;
import net.minecraft.class_2960;

public interface LangRegistryAccess {

	/**
	 * Generate all Lang-entries with their enUS defaults that were declared in code and have them consumed by the passed BiConsumer
	 *
	 * @param modId the ModId (or namespace) that you want to collect the lang entries for
	 */
	void provideLang(String modId, BiConsumer<String, String> consumer);

	String getShared(class_2960 key);

	String getTagName(class_2960 key);

	String getTagDescription(class_2960 key);

	String getSpecific(class_2960 sceneId, String k);

}
