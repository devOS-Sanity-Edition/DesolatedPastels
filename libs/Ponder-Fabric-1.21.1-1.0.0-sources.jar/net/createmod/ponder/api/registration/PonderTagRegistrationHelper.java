package net.createmod.ponder.api.registration;

import java.util.function.Function;
import net.minecraft.class_2960;

public interface PonderTagRegistrationHelper<T> {

	<S> PonderTagRegistrationHelper<S> withKeyFunction(Function<S, T> keyGen);

	TagBuilder registerTag(class_2960 location);

	TagBuilder registerTag(String id);

	void addTagToComponent(T component, class_2960 tag);

	MultiTagBuilder.Tag<T> addToTag(class_2960 tag);

	MultiTagBuilder.Tag<T> addToTag(class_2960... tags);

	MultiTagBuilder.Component addToComponent(T component);

	MultiTagBuilder.Component addToComponent(T... component);

}
