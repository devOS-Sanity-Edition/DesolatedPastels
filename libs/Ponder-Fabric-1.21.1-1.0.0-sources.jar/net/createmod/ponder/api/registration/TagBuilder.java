package net.createmod.ponder.api.registration;

import net.minecraft.class_1935;
import net.minecraft.class_2960;

public interface TagBuilder {

	TagBuilder title(String title);

	TagBuilder description(String description);

	TagBuilder addToIndex();

	TagBuilder icon(class_2960 location);

	TagBuilder icon(String path);

	TagBuilder idAsIcon();

	TagBuilder item(class_1935 item, boolean useAsIcon, boolean useAsMainItem);

	default TagBuilder item(class_1935 item){
		return item(item, true, true);
	}

	void register();

}
