package net.createmod.ponder.api.registration;

import java.util.List;
import java.util.Set;

import net.createmod.ponder.foundation.PonderTag;
import net.minecraft.class_2960;

public interface TagRegistryAccess {

	PonderTag getRegisteredTag(class_2960 tagLocation);

	List<PonderTag> getListedTags();

	Set<PonderTag> getTags(class_2960 item);

	Set<class_2960> getItems(class_2960 tag);
	Set<class_2960> getItems(PonderTag tag);

}
