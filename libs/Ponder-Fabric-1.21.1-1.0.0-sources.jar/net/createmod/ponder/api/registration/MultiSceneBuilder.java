package net.createmod.ponder.api.registration;

import java.util.function.Consumer;

import net.createmod.ponder.api.scene.PonderStoryBoard;
import net.minecraft.class_2960;

public interface MultiSceneBuilder {
	MultiSceneBuilder addStoryBoard(class_2960 schematicLocation,
									PonderStoryBoard storyBoard);

	MultiSceneBuilder addStoryBoard(class_2960 schematicLocation,
									PonderStoryBoard storyBoard, class_2960... tags);

	MultiSceneBuilder addStoryBoard(class_2960 schematicLocation,
									PonderStoryBoard storyBoard,
									Consumer<StoryBoardEntry> extras);

	MultiSceneBuilder addStoryBoard(String schematicPath, PonderStoryBoard storyBoard);

	MultiSceneBuilder addStoryBoard(String schematicPath, PonderStoryBoard storyBoard,
									class_2960... tags);

	MultiSceneBuilder addStoryBoard(String schematicPath, PonderStoryBoard storyBoard,
									Consumer<StoryBoardEntry> extras);
}
