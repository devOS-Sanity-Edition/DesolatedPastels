package net.createmod.ponder.api.registration;

import net.minecraft.class_2960;

public interface MultiTagBuilder {

	interface Tag<T> {

		Tag<T> add(T component);

	}

	interface Component {

		Component add(class_2960 tag);

	}

}
