package net.createmod.ponder.api.registration;

import java.util.function.Predicate;
import net.minecraft.class_1792;
import net.minecraft.class_1935;
import net.minecraft.class_2248;

public interface IndexExclusionHelper {

	IndexExclusionHelper exclude(class_1935 item);

	IndexExclusionHelper excludeItemVariants(Class<? extends class_1792> itemClazz, class_1792 originalVariant);

	IndexExclusionHelper excludeBlockVariants(Class<? extends class_2248> blockClazz, class_2248 originalVariant);

	IndexExclusionHelper exclude(Predicate<class_1935> predicate);

}
