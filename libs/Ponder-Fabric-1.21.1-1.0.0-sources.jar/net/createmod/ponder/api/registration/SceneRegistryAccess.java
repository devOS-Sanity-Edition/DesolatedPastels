package net.createmod.ponder.api.registration;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import net.createmod.ponder.foundation.PonderScene;
import net.minecraft.class_2960;

public interface SceneRegistryAccess {

	boolean doScenesExistForId(class_2960 id);

	Collection<Map.Entry<class_2960, StoryBoardEntry>> getRegisteredEntries();

	List<PonderScene> compile(class_2960 id);

	List<PonderScene> compile(Collection<StoryBoardEntry> entries);

}
