@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package net.createmod.ponder.api.registration;

import javax.annotation.ParametersAreNonnullByDefault;
