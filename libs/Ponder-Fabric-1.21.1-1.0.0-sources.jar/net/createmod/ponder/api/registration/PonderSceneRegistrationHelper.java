package net.createmod.ponder.api.registration;

import java.util.function.Function;

import net.createmod.ponder.api.scene.PonderStoryBoard;
import net.minecraft.class_2960;

public interface PonderSceneRegistrationHelper<T> {

	<S> PonderSceneRegistrationHelper<S> withKeyFunction(Function<S, T> keyGen);

	StoryBoardEntry addStoryBoard(T component, class_2960 schematicLocation, PonderStoryBoard storyBoard,
								  class_2960... tags);

	StoryBoardEntry addStoryBoard(T component, String schematicPath, PonderStoryBoard storyBoard,
								  class_2960... tags);

	MultiSceneBuilder forComponents(T... components);

	MultiSceneBuilder forComponents(Iterable<? extends T> components);

	class_2960 asLocation(String path);
}
