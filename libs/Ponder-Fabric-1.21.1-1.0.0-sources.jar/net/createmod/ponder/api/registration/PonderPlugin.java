package net.createmod.ponder.api.registration;

import net.createmod.ponder.api.level.PonderLevel;
import net.minecraft.class_2960;

public interface PonderPlugin {

	/**
	 * @return the modID of the mod that added this plugin
	 */
	String getModId();

	/**
	 * Register all the Ponder Scenes added by your Mod
	 */
	default void registerScenes(PonderSceneRegistrationHelper<class_2960> helper) {}

	/**
	 * Register all the Ponder Tags added by your Mod
	 */
	default void registerTags(PonderTagRegistrationHelper<class_2960> helper) {}

	default void registerSharedText(SharedTextRegistrationHelper helper) {}

	default void onPonderLevelRestore(PonderLevel ponderLevel) {}

	default void indexExclusions(IndexExclusionHelper helper) {}

}
