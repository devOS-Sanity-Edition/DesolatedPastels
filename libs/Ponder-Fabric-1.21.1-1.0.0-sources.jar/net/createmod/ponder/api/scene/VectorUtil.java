package net.createmod.ponder.api.scene;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;

public interface VectorUtil {
	class_243 centerOf(int x, int y, int z);

	class_243 centerOf(class_2338 pos);

	class_243 topOf(int x, int y, int z);

	class_243 topOf(class_2338 pos);

	class_243 blockSurface(class_2338 pos, class_2350 face);

	class_243 blockSurface(class_2338 pos, class_2350 face, float margin);

	class_243 of(double x, double y, double z);
}
