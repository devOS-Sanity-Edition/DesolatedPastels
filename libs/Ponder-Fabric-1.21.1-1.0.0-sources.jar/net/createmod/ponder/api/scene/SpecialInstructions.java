package net.createmod.ponder.api.scene;

import java.util.function.Supplier;

import net.createmod.ponder.api.element.AnimatedSceneElement;
import net.createmod.ponder.api.element.ElementLink;
import net.createmod.ponder.api.element.MinecartElement;
import net.createmod.ponder.api.element.ParrotElement;
import net.createmod.ponder.api.element.ParrotPose;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;

public interface SpecialInstructions {
	ElementLink<ParrotElement> createBirb(class_243 location, Supplier<? extends ParrotPose> pose);

	void changeBirbPose(ElementLink<ParrotElement> birb, Supplier<? extends ParrotPose> pose);

	void movePointOfInterest(class_243 location);

	void movePointOfInterest(class_2338 location);

	void rotateParrot(ElementLink<ParrotElement> link, double xRotation, double yRotation, double zRotation,
					  int duration);

	void moveParrot(ElementLink<ParrotElement> link, class_243 offset, int duration);

	ElementLink<MinecartElement> createCart(class_243 location, float angle, MinecartElement.MinecartConstructor type);

	void rotateCart(ElementLink<MinecartElement> link, float yRotation, int duration);

	void moveCart(ElementLink<MinecartElement> link, class_243 offset, int duration);

	<T extends AnimatedSceneElement> void hideElement(ElementLink<T> link, class_2350 direction);
}
