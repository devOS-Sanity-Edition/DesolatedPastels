package net.createmod.ponder.api.scene;

import java.util.function.Consumer;
import java.util.function.Predicate;

import net.createmod.catnip.outliner.Outline;
import net.createmod.catnip.outliner.Outliner;
import net.minecraft.class_2338;
import net.minecraft.class_243;

public interface Selection extends Predicate<class_2338> {

	Selection add(Selection other);

	Selection substract(Selection other);

	Selection copy();

	class_243 getCenter();

	void forEach(Consumer<class_2338> callback);

	Outline.OutlineParams makeOutline(Outliner outliner, Object slot);

	default Outline.OutlineParams makeOutline(Outliner outliner) {
		return makeOutline(outliner, this);
	}
}
