package net.createmod.ponder.api.scene;

import net.minecraft.class_2338;

public interface PositionUtil {
	class_2338 at(int x, int y, int z);

	class_2338 zero();
}
