package net.createmod.ponder.api.scene;

import net.minecraft.class_2338;
import net.minecraft.class_2382;

public interface SelectionUtil {
	Selection everywhere();

	Selection position(int x, int y, int z);

	Selection position(class_2338 pos);

	Selection fromTo(int x, int y, int z, int x2, int y2, int z2);

	Selection fromTo(class_2338 pos1, class_2338 pos2);

	Selection column(int x, int z);

	Selection layer(int y);

	Selection layersFrom(int y);

	Selection layers(int y, int height);

	Selection cuboid(class_2338 origin, class_2382 size);
}
