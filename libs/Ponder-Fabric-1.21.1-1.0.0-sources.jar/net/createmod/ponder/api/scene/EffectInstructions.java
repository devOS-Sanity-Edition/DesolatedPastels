package net.createmod.ponder.api.scene;

import net.createmod.ponder.api.ParticleEmitter;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_243;

public interface EffectInstructions {
	void emitParticles(class_243 location, ParticleEmitter emitter, float amountPerCycle, int cycles);

	<T extends class_2394> ParticleEmitter simpleParticleEmitter(T data, class_243 motion);

	<T extends class_2394> ParticleEmitter particleEmitterWithinBlockSpace(T data, class_243 motion);

	void indicateRedstone(class_2338 pos);

	void indicateSuccess(class_2338 pos);

	void createRedstoneParticles(class_2338 pos, int color, int amount);
}
