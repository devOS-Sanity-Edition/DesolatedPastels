package net.createmod.ponder.api.scene;

import net.createmod.catnip.math.Pointing;
import net.createmod.ponder.api.PonderPalette;
import net.createmod.ponder.api.element.InputElementBuilder;
import net.createmod.ponder.api.element.TextElementBuilder;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;

public interface OverlayInstructions {
	TextElementBuilder showText(int duration);

	TextElementBuilder showOutlineWithText(Selection selection, int duration);

	InputElementBuilder showControls(class_243 sceneSpace, Pointing direction, int duration);

	void chaseBoundingBoxOutline(PonderPalette color, Object slot, class_238 boundingBox, int duration);

	void showCenteredScrollInput(class_2338 pos, class_2350 side, int duration);

	void showScrollInput(class_243 location, class_2350 side, int duration);

	void showRepeaterScrollInput(class_2338 pos, int duration);

	void showFilterSlotInput(class_243 location, int duration);

	void showFilterSlotInput(class_243 location, class_2350 side, int duration);

	void showLine(PonderPalette color, class_243 start, class_243 end, int duration);

	void showBigLine(PonderPalette color, class_243 start, class_243 end, int duration);

	void showOutline(PonderPalette color, Object slot, Selection selection, int duration);
}
