package net.createmod.ponder.api.level;

import java.util.List;
import org.jetbrains.annotations.Nullable;

import net.createmod.catnip.levelWrappers.DummyLevelEntityGetter;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1845;
import net.minecraft.class_1863;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_22;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_269;
import net.minecraft.class_2802;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3611;
import net.minecraft.class_5455;
import net.minecraft.class_5577;
import net.minecraft.class_5712;
import net.minecraft.class_6754;
import net.minecraft.class_6756;
import net.minecraft.class_6880;
import net.minecraft.class_7134;
import net.minecraft.class_7699;
import net.minecraft.class_7887;
import net.minecraft.class_7924;
import net.minecraft.class_8921;
import net.minecraft.class_9209;

public class EmptyLevel extends class_1937 {
	public EmptyLevel() {
		super(
				null,
				null,
				null,//TODO
				class_7887.method_46817().method_46758().method_46751(class_7924.field_41241).method_46747(class_7134.field_37666),
				null,
				false,
				false,
				0,
				0
		);
	}

	@Override
	public void method_8413(class_2338 blockPos, class_2680 blockState, class_2680 blockState1, int i) {}

	@Override
	public void method_8465(@Nullable class_1657 player, double v, double v1, double v2, class_6880<class_3414> soundEvent, class_3419 soundSource, float v3, float v4, long l) {}

	@Override
	public void method_8449(@Nullable class_1657 player, class_1297 entity, class_6880<class_3414> soundEvent, class_3419 soundSource, float v, float v1, long l) {}

	@Override
	public String method_31419() {
		return "null";
	}

	@Nullable
	@Override
	public class_1297 method_8469(int i) {
		return null;
	}

	@Override
	public class_8921 method_54719() {
		return null;
	}

	@Nullable
	@Override
	public class_22 method_17891(class_9209 mapId) {
		return null;
	}

	@Override
	public void method_17890(class_9209 mapId, class_22 mapItemSavedData) {}

	@Override
	public class_9209 method_17889() {
		return new class_9209(0);
	}

	@Override
	public void method_8517(int i, class_2338 blockPos, int i1) {}

	@Override
	public class_269 method_8428() {
		return null;
	}

	@Override
	public class_1863 method_8433() {
		return null;
	}

	@Override
	protected class_5577<class_1297> method_31592() {
		return new DummyLevelEntityGetter<>();
	}

	@Override
	public class_6756<class_2248> method_8397() {
		return class_6754.method_39362();
	}

	@Override
	public class_6756<class_3611> method_8405() {
		return class_6754.method_39362();
	}

	@Override
	public class_2802 method_8398() {
		return null;
	}

	@Override
	public void method_8444(@Nullable class_1657 player, int i, class_2338 blockPos, int i1) {}

	@Override
	public void method_32888(class_6880<class_5712> holder, class_243 vec3, class_5712.class_7397 context) {}

	@Override
	public class_5455 method_30349() {
		return null;
	}

	@Override
	public class_1845 method_59547() {
		return null;
	}

	@Override
	public class_7699 method_45162() {
		return class_7699.method_45397();
	}

	@Override
	public float method_24852(class_2350 direction, boolean b) {
		return 0;
	}

	@Override
	public List<? extends class_1657> method_18456() {
		return List.of();
	}

	@Override
	public class_6880<class_1959> method_22387(int i, int i1, int i2) {
		return null;
	}

	// Neo's patched methods
	public void setDayTimeFraction(float var1) {}

	public float getDayTimeFraction() { return 0; }

	public float getDayTimePerTick() { return 0; }

	public void setDayTimePerTick(float var1) {}
}
