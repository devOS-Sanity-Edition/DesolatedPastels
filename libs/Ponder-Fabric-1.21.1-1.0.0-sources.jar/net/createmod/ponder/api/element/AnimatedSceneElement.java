package net.createmod.ponder.api.element;

import net.minecraft.class_243;

public interface AnimatedSceneElement extends PonderSceneElement {
	void forceApplyFade(float fade);

	void setFade(float fade);

	void setFadeVec(class_243 fadeVec);
}
