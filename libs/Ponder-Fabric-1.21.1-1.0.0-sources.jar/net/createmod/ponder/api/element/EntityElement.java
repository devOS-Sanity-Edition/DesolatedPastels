package net.createmod.ponder.api.element;

import net.minecraft.class_1297;

public interface EntityElement extends TrackedElement<class_1297> {}
