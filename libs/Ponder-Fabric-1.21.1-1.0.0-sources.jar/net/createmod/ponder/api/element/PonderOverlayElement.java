package net.createmod.ponder.api.element;

import net.createmod.ponder.foundation.PonderScene;
import net.createmod.ponder.foundation.ui.PonderUI;
import net.minecraft.class_332;

public interface PonderOverlayElement extends PonderElement {

    void render(PonderScene scene, PonderUI screen, class_332 graphics, float partialTicks);

}
