package net.createmod.ponder.api.element;

import net.createmod.catnip.math.AngleHelper;
import net.createmod.ponder.Ponder;
import net.createmod.ponder.api.level.PonderLevel;
import net.createmod.ponder.foundation.PonderScene;
import net.createmod.ponder.foundation.ui.PonderUI;
import net.minecraft.class_1041;
import net.minecraft.class_1299;
import net.minecraft.class_1453;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public abstract class ParrotPose {

	private static final class_1453.class_7989[] VARIANTS = new class_1453.class_7989[]{
		class_1453.class_7989.field_41550,
		class_1453.class_7989.field_41552,
		class_1453.class_7989.field_41553,
		class_1453.class_7989.field_41554,
	}; // blue parrots are kinda hard to see

	public abstract void tick(PonderScene scene, class_1453 entity, class_243 location);

	public class_1453 create(PonderLevel world) {
		class_1453 entity = new class_1453(class_1299.field_6104, world);
		int nextInt = Ponder.RANDOM.nextInt(VARIANTS.length);
		entity.method_47848(VARIANTS[nextInt]);
		return entity;
	}

	public static class DancePose extends ParrotPose {

		@Override
		public class_1453 create(PonderLevel world) {
			class_1453 entity = super.create(world);
			entity.method_6006(class_2338.field_10980, true);
			return entity;
		}

		@Override
		public void tick(PonderScene scene, class_1453 entity, class_243 location) {
			entity.field_5982 = entity.method_36454();
			entity.method_36456(entity.method_36454() - 2);
		}

	}

	public static class FlappyPose extends ParrotPose {

		@Override
		public void tick(PonderScene scene, class_1453 entity, class_243 location) {
			double length = entity.method_19538()
				.method_1023(entity.field_6038, entity.field_5971, entity.field_5989)
				.method_1033();
			entity.method_24830(false);
			double phase = Math.min(length * 15, 8);
			float f = (float) ((PonderUI.ponderTicks % 100) * phase);
			entity.field_6819 = class_3532.method_15374(f) + 1;
			if (length == 0)
				entity.field_6819 = 0;
		}

	}

	public static abstract class FaceVecPose extends ParrotPose {

		@Override
		public void tick(PonderScene scene, class_1453 entity, class_243 location) {
			class_243 p_200602_2_ = getFacedVec(scene);
			class_243 Vector3d = location.method_1019(entity.method_5836(0));
			double d0 = p_200602_2_.field_1352 - Vector3d.field_1352;
			double d1 = p_200602_2_.field_1351 - Vector3d.field_1351;
			double d2 = p_200602_2_.field_1350 - Vector3d.field_1350;
			double d3 = class_3532.method_15355((float) (d0 * d0 + d2 * d2));
			float targetPitch = class_3532.method_15393((float) -(class_3532.method_15349(d1, d3) * (double) (180F / (float) Math.PI)));
			float targetYaw = class_3532.method_15393((float) -(class_3532.method_15349(d2, d0) * (double) (180F / (float) Math.PI)) + 90);

			entity.method_36457(AngleHelper.angleLerp(.4f, entity.method_36455(), targetPitch));
			entity.method_36456(AngleHelper.angleLerp(.4f, entity.method_36454(), targetYaw));
		}

		protected abstract class_243 getFacedVec(PonderScene scene);

	}

	public static class FacePointOfInterestPose extends FaceVecPose {

		@Override
		protected class_243 getFacedVec(PonderScene scene) {
			return scene.getPointOfInterest();
		}

	}

	public static class FaceCursorPose extends FaceVecPose {

		@Override
		protected class_243 getFacedVec(PonderScene scene) {
			class_310 minecraft = class_310.method_1551();
			class_1041 w = minecraft.method_22683();
			double mouseX = minecraft.field_1729.method_1603() * w.method_4486() / w.method_4480();
			double mouseY = minecraft.field_1729.method_1604() * w.method_4502() / w.method_4507();
			return scene.getTransform()
				.screenToScene(mouseX, mouseY, 300, 0);
		}

	}
}
