package net.createmod.ponder.api.element;

import net.minecraft.class_1688;
import net.minecraft.class_1937;
import net.minecraft.class_243;

public interface MinecartElement extends AnimatedSceneElement {
	void setPositionOffset(class_243 position, boolean immediate);

	void setRotation(float angle, boolean immediate);

	class_243 getPositionOffset();

	class_243 getRotation();

	interface MinecartConstructor {
		class_1688 create(class_1937 w, double x, double y, double z);
	}
}
