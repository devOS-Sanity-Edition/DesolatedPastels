package net.createmod.ponder.api.element;

import net.createmod.catnip.gui.element.ScreenElement;
import net.minecraft.class_1799;

public interface InputElementBuilder {

	InputElementBuilder withItem(class_1799 stack);

	InputElementBuilder leftClick();

	InputElementBuilder rightClick();

	InputElementBuilder scroll();

	InputElementBuilder showing(ScreenElement icon);

	InputElementBuilder whileSneaking();

	InputElementBuilder whileCTRL();
}
