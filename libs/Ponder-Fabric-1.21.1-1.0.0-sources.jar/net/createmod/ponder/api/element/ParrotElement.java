package net.createmod.ponder.api.element;

import net.minecraft.class_243;

public interface ParrotElement extends AnimatedSceneElement {
	void setPositionOffset(class_243 position, boolean immediate);

	void setRotation(class_243 eulers, boolean immediate);

	class_243 getPositionOffset();

	class_243 getRotation();

	void setPose(ParrotPose pose);
}
