package net.createmod.ponder.api.element;

import net.createmod.ponder.api.level.PonderLevel;
import net.minecraft.class_1921;
import net.minecraft.class_332;
import net.minecraft.class_4597;

public interface PonderSceneElement extends PonderElement {

	void renderFirst(PonderLevel world, class_4597 buffer, class_332 graphics, float pt);

	void renderLayer(PonderLevel world, class_4597 buffer, class_1921 type, class_332 graphics, float pt);

	void renderLast(PonderLevel world, class_4597 buffer, class_332 graphics, float pt);

}
