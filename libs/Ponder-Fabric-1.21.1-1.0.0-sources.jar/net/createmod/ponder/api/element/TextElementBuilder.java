package net.createmod.ponder.api.element;

import net.createmod.ponder.api.PonderPalette;
import net.minecraft.class_243;
import net.minecraft.class_2960;

public interface TextElementBuilder {

	TextElementBuilder colored(PonderPalette color);

	TextElementBuilder pointAt(class_243 vec);

	TextElementBuilder independent(int y);

	default TextElementBuilder independent() {
		return independent(0);
	}

	TextElementBuilder text(String defaultText);

	TextElementBuilder sharedText(class_2960 key);

	TextElementBuilder sharedText(String key);

	TextElementBuilder placeNearTarget();

	TextElementBuilder attachKeyFrame();
}
