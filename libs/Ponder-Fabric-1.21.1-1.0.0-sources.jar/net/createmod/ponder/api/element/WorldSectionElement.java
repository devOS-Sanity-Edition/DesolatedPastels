package net.createmod.ponder.api.element;

import net.createmod.catnip.data.Pair;
import net.createmod.ponder.api.level.PonderLevel;
import net.createmod.ponder.api.scene.Selection;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3965;

public interface WorldSectionElement extends AnimatedSceneElement {

	void mergeOnto(WorldSectionElement other);

	void set(Selection selection);

	void add(Selection toAdd);

	void erase(Selection toErase);

	void setCenterOfRotation(class_243 center);

	void stabilizeRotation(class_243 anchor);

	void selectBlock(class_2338 pos);

	void resetSelectedBlock();

	void queueRedraw();

	boolean isEmpty();

	void setEmpty();

	void setAnimatedRotation(class_243 eulerAngles, boolean force);

	class_243 getAnimatedRotation();

	void setAnimatedOffset(class_243 offset, boolean force);

	class_243 getAnimatedOffset();

	Pair<class_243, class_3965> rayTrace(PonderLevel world, class_243 source, class_243 target);
}
