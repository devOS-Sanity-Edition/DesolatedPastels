@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package net.createmod.ponder.enums;

import javax.annotation.ParametersAreNonnullByDefault;