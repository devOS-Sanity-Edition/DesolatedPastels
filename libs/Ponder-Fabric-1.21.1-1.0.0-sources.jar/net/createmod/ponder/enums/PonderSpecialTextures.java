package net.createmod.ponder.enums;

import com.mojang.blaze3d.systems.RenderSystem;

import net.createmod.catnip.render.BindableTexture;
import net.createmod.ponder.Ponder;
import net.minecraft.class_2960;

public enum PonderSpecialTextures implements BindableTexture {

	BLANK("blank.png"),

	;

	public static final String ASSET_PATH = "textures/special/";
	private final class_2960 location;

	PonderSpecialTextures(String filename) {
		location = Ponder.asResource(ASSET_PATH + filename);
	}

	@Override
	public void bind() {
		RenderSystem.setShaderTexture(0, location);
	}

	@Override
	public class_2960 getLocation() {
		return location;
	}

}
