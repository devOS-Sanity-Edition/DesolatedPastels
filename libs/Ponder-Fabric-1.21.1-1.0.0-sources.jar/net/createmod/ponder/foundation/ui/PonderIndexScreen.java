package net.createmod.ponder.foundation.ui;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

import javax.annotation.Nullable;
import net.createmod.catnip.gui.NavigatableSimiScreen;
import net.createmod.catnip.gui.ScreenOpener;
import net.createmod.catnip.gui.UIRenderHelper;
import net.createmod.catnip.gui.widget.BoxWidget;
import net.createmod.catnip.layout.LayoutHelper;
import net.createmod.catnip.layout.PaginationState;
import net.createmod.catnip.registry.RegisteredObjectsHelper;
import net.createmod.ponder.enums.PonderGuiTextures;
import net.createmod.ponder.foundation.PonderIndex;
import net.createmod.ponder.foundation.registration.PonderIndexExclusionHelper;
import net.minecraft.class_1041;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_364;
import net.minecraft.class_4587;
import net.minecraft.class_768;

public class PonderIndexScreen extends AbstractPonderScreen {

	protected final List<ItemEntry> items;
	protected List<PonderButton> paginatedWidgets = new ArrayList<>();
	protected PaginationState paginationState = new PaginationState();
	protected class_768 maxScreenArea = new class_768(0, 0, 0, 0);
	protected class_768 usedArea = new class_768(0, 0, 0, 0);
	protected int maxItemRows;
	protected int maxItemsPerRow;
	protected int maxItemsPerPage;

	@Nullable protected PonderButton nextPage;
	@Nullable protected PonderButton prevPage;

	private class_1799 hoveredItem = class_1799.field_8037;

	private final List<Predicate<class_1935>> exclusions;

	public PonderIndexScreen() {
		items = new ArrayList<>();
		// collect exclusions once at screen creation instead of every time they are needed
		exclusions = PonderIndex.streamPlugins()
				.flatMap(PonderIndexExclusionHelper::pluginToExclusions)
				.toList();
	}

	@Override
	protected void method_25426() {
		super.method_25426();

		items.clear();
		PonderIndex.getSceneAccess()
				.getRegisteredEntries()
				.stream()
				.map(Map.Entry::getKey)
				.distinct()
				.map(key -> new ItemEntry(RegisteredObjectsHelper.getItemOrBlock(key), key))
				.filter(entry -> entry.item != null)
				.filter(this::isItemIncluded)
				.forEach(items::add);

		items.sort(Comparator.comparing(ItemEntry::key));

		int centerX = field_22789 / 2;
		int centerY = field_22790 / 2;
		int targetWidth = class_3532.method_15340(field_22789 - 180, 250, 400);
		int targetHeight = class_3532.method_15340(field_22790 - 140, 150, 300);

		maxScreenArea = new class_768(centerX - targetWidth / 2, centerY - targetHeight / 2, targetWidth, targetHeight);

		// height/width = 28 per item + 8 spacing between
		maxItemRows = (maxScreenArea.method_3320() + 8) / 36;
		maxItemsPerRow = (maxScreenArea.method_3319() + 8) / 36;
		maxItemsPerPage = maxItemRows * maxItemsPerRow;

		paginationState = new PaginationState(items.size() > maxItemsPerPage, maxItemsPerPage, items.size());

		setupItemsForPage();

		if (!paginationState.usesPagination())
			return;

		method_37063(prevPage = new PonderButton(centerX - 100, maxScreenArea.method_3322() + maxScreenArea.method_3320() + 10)
				.showing(PonderGuiTextures.ICON_PONDER_LEFT)
				.withCallback(() -> {
					paginationState.previousPage();
					updateAfterPaginationChange();
				})
				.setActive(false)
		);

		method_37063(nextPage = new PonderButton(centerX + 80, maxScreenArea.method_3322() + maxScreenArea.method_3320() + 10)
				.showing(PonderGuiTextures.ICON_PONDER_RIGHT)
				.withCallback(() -> {
					paginationState.nextPage();
					updateAfterPaginationChange();
				})
				.setActive(true)
		);

		prevPage.updateGradientFromState();
		nextPage.updateGradientFromState();
	}

	protected void setupItemsForPage() {
		removeWidgets(paginatedWidgets);

		int itemCount = paginationState.getCurrentPageElementCount();
		int actualItemRows = class_3532.method_15340((int) Math.ceil((double) itemCount / maxItemsPerRow), 1, maxItemRows);
		LayoutHelper layoutHelper = LayoutHelper.centeredHorizontal(itemCount, actualItemRows, 28, 28, 8);
		usedArea = layoutHelper.getArea();

		int centerX = field_22789 / 2;
		int centerY = field_22790 / 2;

		paginationState.iterateForCurrentPage((iPage, iOverall) -> {
			ItemEntry entry = items.get(iOverall);
			PonderButton b = new PonderButton(centerX + layoutHelper.getX() + 4, centerY + layoutHelper.getY() + 4)
					.showing(new class_1799(entry.item))
					.withCallback((x, y) -> {
						if (!PonderIndex.getSceneAccess().doScenesExistForId(entry.key))
							return;

						centerScalingOn(x, y);
						ScreenOpener.transitionTo(PonderUI.of(new class_1799(entry.item)));
					});
			paginatedWidgets.add(b);
			method_37063(b);
			layoutHelper.next();

		});

	}

	protected void updateAfterPaginationChange() {
		setupItemsForPage();

		prevPage.<PonderButton>setActive(paginationState.hasPreviousPage()).animateGradientFromState();
		nextPage.<PonderButton>setActive(paginationState.hasNextPage()).animateGradientFromState();
	}

	@Override
	protected void initBackTrackIcon(BoxWidget backTrack) {
		backTrack.showing(PonderGuiTextures.ICON_PONDER_IDENTIFY);
	}

	private boolean isItemIncluded(ItemEntry entry) {
		return exclusions
				.stream()
				.noneMatch(predicate -> predicate.test(entry.item));
	}

	@Override
	public void method_25393() {
		super.method_25393();
		PonderUI.ponderTicks++;

		hoveredItem = class_1799.field_8037;
		class_1041 w = field_22787.method_22683();
		double mouseX = field_22787.field_1729.method_1603() * w.method_4486() / w.method_4480();
		double mouseY = field_22787.field_1729.method_1604() * w.method_4502() / w.method_4507();
		for (class_364 child : method_25396()) {
			if (child instanceof PonderButton button) {
				if (button.method_25405(mouseX, mouseY)) {
					hoveredItem = button.getItem() != null ? button.getItem() : class_1799.field_8037;
				}
			}
		}
	}

	@Override
	protected void renderWindow(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		super.renderWindow(graphics, mouseX, mouseY, partialTicks);
		int centerX = field_22789 / 2;
		int centerY = field_22790 / 2;

		class_4587 poseStack = graphics.method_51448();

		poseStack.method_22903();
		poseStack.method_46416(centerX, centerY, 0);

		UIRenderHelper.streak(graphics, 0, usedArea.method_3321() - 10, usedArea.method_3322() - 20, 20, 220);
		graphics.method_51433(field_22793, "Items to inspect", usedArea.method_3321() - 5, usedArea.method_3322() - 25, UIRenderHelper.COLOR_TEXT.getFirst().getRGB(), false);

		poseStack.method_22909();

		if (!paginationState.usesPagination())
			return;

		poseStack.method_22903();
		poseStack.method_46416(centerX, maxScreenArea.method_3322() + maxScreenArea.method_3320() + 14, 0);
		poseStack.method_22905(1.5f, 1.5f, 1);

		String pageString = "Page " + (paginationState.getPageIndex() + 1) + "/" + paginationState.getMaxPages();
		int stringWidth = field_22793.method_1727(pageString);

		UIRenderHelper.streak(graphics, 0, 0, 4, 14, 85);
		UIRenderHelper.streak(graphics, 180, 0, 4, 14, 85);
		graphics.method_51433(field_22793, pageString, (int) (-stringWidth / 2f), 0, UIRenderHelper.COLOR_TEXT.getFirst().getRGB(), false);

		poseStack.method_22909();
	}

	@Override
	protected void renderWindowForeground(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		if (hoveredItem.method_7960())
			return;

		class_4587 poseStack = graphics.method_51448();
		poseStack.method_22903();
		poseStack.method_46416(0, 0, 200);

		graphics.method_51446(field_22793, hoveredItem, mouseX, mouseY);

		poseStack.method_22909();
	}

	@Override
	public boolean isEquivalentTo(NavigatableSimiScreen other) {
		return other instanceof PonderIndexScreen;
	}

	public class_1799 getHoveredTooltipItem() {
		return hoveredItem;
	}

	@Override
	public boolean method_25421() {
		return true;
	}

	public record ItemEntry(@Nullable class_1935 item, class_2960 key) {}

}
