package net.createmod.ponder.foundation.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import javax.annotation.Nullable;
import com.mojang.blaze3d.systems.RenderSystem;
import net.createmod.catnip.config.ui.ConfigScreen;
import net.createmod.catnip.gui.ScreenOpener;
import net.createmod.catnip.gui.UIRenderHelper;
import net.createmod.catnip.gui.element.BoxElement;
import net.createmod.catnip.gui.widget.BoxWidget;
import net.createmod.catnip.lang.ClientFontHelper;
import net.createmod.catnip.lang.FontHelper;
import net.createmod.catnip.lang.FontHelper.Palette;
import net.createmod.catnip.layout.LayoutHelper;
import net.createmod.catnip.layout.PaginationState;
import net.createmod.ponder.Ponder;
import net.createmod.ponder.enums.PonderGuiTextures;
import net.createmod.ponder.foundation.PonderIndex;
import net.createmod.ponder.foundation.PonderTag;
import net.minecraft.class_1041;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_364;
import net.minecraft.class_4587;
import net.minecraft.class_768;

public class PonderTagIndexScreen extends AbstractPonderScreen {

	protected List<ModTagsEntry> currentModTagEntries = new LinkedList<>();
	protected List<Map.Entry<String, List<PonderTag>>> sortedModTags = List.of();
	protected PaginationState paginationState = new PaginationState();

	@Nullable protected PonderButton pageNext;
	@Nullable protected PonderButton pagePrev;

	@Nullable private PonderTag hoveredItem = null;

	// The main ponder entry point from menus.
	public PonderTagIndexScreen() {}

	@Override
	protected void method_25426() {
		super.method_25426();

		Map<String, List<PonderTag>> tagsByModID = PonderIndex.getTagAccess().getListedTags().stream().collect(Collectors.groupingBy(tag -> tag.getId().method_12836()));
		sortedModTags = new TreeMap<>(tagsByModID).entrySet().stream().toList();

		int modCount = sortedModTags.size();
		int maxModsOnScreen = (field_22790 - 140 - 40) / 58;

		paginationState = new PaginationState(modCount > 1 && modCount > maxModsOnScreen, maxModsOnScreen, modCount);

		setupModTagEntries();

		if (!paginationState.usesPagination())
			return;

		int xOffset = (int) (field_22789 * 0.5);

		method_37063(pagePrev = new PonderButton(xOffset - 120, field_22790 - 32)
				.showing(PonderGuiTextures.ICON_PONDER_LEFT)
				.withCallback(() -> {
					paginationState.previousPage();
					updateAfterPaginationChange();
				})
				.setActive(false)
		);

		pagePrev.updateGradientFromState();

		method_37063(pageNext = new PonderButton(xOffset + 100, field_22790 - 32)
				.showing(PonderGuiTextures.ICON_PONDER_RIGHT)
				.withCallback(() -> {
					paginationState.nextPage();
					updateAfterPaginationChange();
				})
				.setActive(true)
		);

	}

	protected void setupModTagEntries() {
		removeWidgets(method_25396().stream().filter(widget -> {
			if (!(widget instanceof PonderButton ponderButton))
				return false;

			return ponderButton.tag != null;
		}).toList());

		currentModTagEntries.clear();

		AtomicInteger yOffset = new AtomicInteger(140);
		int xOffset = (int) (field_22789 * 0.5);

		paginationState.iterateForCurrentPage((iPage, iOverall) -> {
			Map.Entry<String, List<PonderTag>> entry = sortedModTags.get(iOverall);
			String modName = ConfigScreen.getModDisplayName(entry.getKey()).orElse(entry.getKey());
			List<PonderTag> tags = entry.getValue();

			LayoutHelper layout = LayoutHelper.centeredHorizontal(tags.size(), 1, 28, 28, 8);
			class_768 layoutArea = layout.getArea();

			for (PonderTag tag : tags) {
				PonderButton button = new PonderButton(xOffset + layout.getX() + 4, yOffset.get() + layout.getY() + 18)
						.showingTag(tag)
						.withCallback((mouseX, mouseY) -> {
							centerScalingOn(mouseX, mouseY);
							ScreenOpener.transitionTo(new PonderTagScreen(tag));
						});
				method_37063(button);
				layout.next();
			}

			currentModTagEntries.add(new ModTagsEntry(
					modName,
					tags.size(),
					layoutArea,
					yOffset.get()
			));

			yOffset.addAndGet(58 + 10);
		});

		for (int i = 0; i < paginationState.getElementsPerPage(); i++) {
			if (paginationState.getStartIndex() + i >= sortedModTags.size())
				break;


		}
	}

	protected void updateAfterPaginationChange() {
		setupModTagEntries();

		pagePrev.<PonderButton>setActive(paginationState.hasPreviousPage()).animateGradientFromState();
		pageNext.<PonderButton>setActive(paginationState.hasNextPage()).animateGradientFromState();
	}

	@Override
	protected void initBackTrackIcon(BoxWidget backTrack) {
		backTrack.showing(PonderGuiTextures.ICON_PONDER_IDENTIFY);
	}

	@Override
	public void method_25393() {
		super.method_25393();
		PonderUI.ponderTicks++;

		hoveredItem = null;
		class_1041 w = field_22787.method_22683();
		double mouseX = field_22787.field_1729.method_1603() * w.method_4486() / w.method_4480();
		double mouseY = field_22787.field_1729.method_1604() * w.method_4502() / w.method_4507();
		for (class_364 child : method_25396()) {
			if (child == backTrack)
				continue;
			if (child instanceof PonderButton button)
				if (button.method_25405(mouseX, mouseY))
					hoveredItem = button.getTag();
		}
	}

	@Override
	protected void renderWindow(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		super.renderWindow(graphics, mouseX, mouseY, partialTicks);
		class_4587 poseStack = graphics.method_51448();

		poseStack.method_22903();
		poseStack.method_22904(field_22789 / 2d, 30, 0);

		//title, box for icon and streak
		poseStack.method_22903();
		poseStack.method_46416(-120, 0, 0);

		String title = Ponder.lang().translate(AbstractPonderScreen.WELCOME).string();

		new BoxElement().withBackground(PonderUI.BACKGROUND_FLAT)
			.gradientBorder(PonderUI.COLOR_IDLE)
			.at(0, 0, 0)
			.withBounds(30, 30)
			.render(graphics);

		PonderGuiTextures.LOGO.render(graphics, -1, -1);

		//34 = 30 bounds + 2 padding + 2 box width
		//-3 = 2 padding + 1 pixel of the box
		poseStack.method_46416(34, -3, 0);

		int streakHeight = 36;
		UIRenderHelper.streak(graphics, 0, 0, (streakHeight / 2), streakHeight, 280);

		poseStack.method_22905(2f, 2f, 2f);
		graphics.method_51433(field_22793, title, 3, 5, UIRenderHelper.COLOR_TEXT.getFirst().getRGB(), false);

		poseStack.method_22909();
		poseStack.method_46416(0, 50, 0);
		poseStack.method_22903();
		//at the middle, 80px from the top now

		int maxWidth = (int) (field_22789 * .5f);
		String desc = Ponder.lang().translate(AbstractPonderScreen.DESCRIPTION).string();

		int descWidth = field_22793.method_1727(desc);
		if (descWidth + 2 < maxWidth)
			maxWidth = descWidth + 2;

		int descHeight = field_22793.method_1713(desc, maxWidth);

		poseStack.method_46416(-maxWidth / 2f, 0, 0);

		new BoxElement().withBackground(PonderUI.BACKGROUND_FLAT)
				.gradientBorder(PonderUI.COLOR_IDLE)
				.at(-3, -3, 0)
				.withBounds(maxWidth + 6, descHeight + 5)
				.render(graphics);

		ClientFontHelper.drawSplitString(graphics, poseStack, field_22793, desc, 0, 0, maxWidth, UIRenderHelper.COLOR_TEXT.getFirst().getRGB());
		poseStack.method_22909();

		poseStack.method_46416(0, -80, 0);
		//at the middle of top edge now

		for(ModTagsEntry entry : currentModTagEntries) {
			poseStack.method_22903();
			renderTagsEntry(graphics, entry);
			poseStack.method_22909();
		}

		poseStack.method_22909();

	}

	protected void renderTagsEntry(class_332 graphics, ModTagsEntry entry) {
		class_4587 poseStack = graphics.method_51448();

		int layoutWidth = entry.layoutArea().method_3319();
		int layoutHeight = entry.layoutArea().method_3320();

		poseStack.method_46416(0, entry.yPos(), 0);

		String categories = Ponder.lang().translate(AbstractPonderScreen.CATEGORIES, entry.modName()).string();
		int stringWidth = field_22793.method_1727(categories);
		poseStack.method_22903();
		poseStack.method_46416(-stringWidth / 2f, -20, 0);

		new BoxElement().withBackground(PonderUI.BACKGROUND_FLAT)
				.gradientBorder(PonderUI.COLOR_IDLE)
				.at(-3, -1, 0)
				.withBounds(stringWidth + 6, 10)
				.render(graphics);

		graphics.method_51433(field_22793, categories, 0, 0, UIRenderHelper.COLOR_TEXT.getFirst().getRGB(), false);

		poseStack.method_22909();

		int extraLength = class_3532.method_15340(entry.tagCount, 2, 8);

		UIRenderHelper.streak(graphics,   0, 0, layoutHeight / 2, layoutHeight + 6, layoutWidth / 2 + extraLength * 15);
		UIRenderHelper.streak(graphics, 180, 0, layoutHeight / 2, layoutHeight + 6, layoutWidth / 2 + extraLength * 15);

	}

	@Override
	protected void renderWindowForeground(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		RenderSystem.disableDepthTest();
		class_4587 poseStack = graphics.method_51448();
		poseStack.method_22903();
		poseStack.method_46416(0, 0, 200);

		if (hoveredItem != null) {
			List<class_2561> list = FontHelper.cutStringTextComponent(hoveredItem.getDescription(), Palette.ALL_GRAY);
			list.add(0, class_2561.method_43470(hoveredItem.getTitle()));
			graphics.method_51434(field_22793, list, mouseX, mouseY);
		}

		poseStack.method_22909();
		RenderSystem.enableDepthTest();
	}

	@Override
	public boolean method_25421() {
		return true;
	}

	@Override
	public void method_25432() {
		super.method_25432();
		hoveredItem = null;
	}

	public record ModTagsEntry(
			String modName,
			int tagCount,
			class_768 layoutArea,
			int yPos
	) {}

}
