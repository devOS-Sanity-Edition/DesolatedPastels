package net.createmod.ponder.foundation.ui;

import java.util.function.BiConsumer;

import net.createmod.catnip.gui.UIRenderHelper;
import net.createmod.catnip.gui.widget.AbstractSimiWidget;
import net.createmod.ponder.foundation.PonderChapter;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class ChapterLabel extends AbstractSimiWidget {

	private final PonderChapter chapter;
	private final PonderButton button;

	public ChapterLabel(PonderChapter chapter, int x, int y, BiConsumer<Integer, Integer> onClick) {
		super(x, y, 175, 38);

		this.button = new PonderButton(x + 4, y + 4, 30, 30)
				.showing(chapter)
				.withCallback(onClick);

		this.chapter = chapter;
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		UIRenderHelper.streak(graphics, 0, method_46426(), method_46427() + field_22759 / 2, field_22759 - 2, field_22758);
		graphics.method_25303(class_310.method_1551().field_1772, chapter.getTitle(), method_46426() + 50,
			method_46427() + 20, UIRenderHelper.COLOR_TEXT_ACCENT.getFirst().getRGB());

		button.doRender(graphics, mouseX, mouseY, partialTicks);
		super.method_25394(graphics, mouseX, mouseY, partialTicks);
	}

	@Override
	public void method_25348(double x, double y) {
		if (!button.method_25405(x, y))
			return;

		button.runCallback(x, y);
	}
}
