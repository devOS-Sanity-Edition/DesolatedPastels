package net.createmod.ponder.foundation;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Queue;

import com.google.common.collect.EvictingQueue;
import com.google.common.collect.Maps;
import com.google.common.collect.Queues;
import com.mojang.blaze3d.systems.RenderSystem;
import net.createmod.ponder.api.level.PonderLevel;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_310;
import net.minecraft.class_3999;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_703;
import net.minecraft.class_757;
import net.minecraft.class_765;
import net.minecraft.class_9801;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4fStack;

public class PonderWorldParticles {

	private final Map<class_3999, Queue<class_703>> byType = Maps.newIdentityHashMap();
	private final Queue<class_703> queue = Queues.newArrayDeque();

	PonderLevel world;

	public PonderWorldParticles(PonderLevel world) {
		this.world = world;
	}

	public void addParticle(class_703 p) {
		this.queue.add(p);
	}

	public void tick() {
		this.byType.forEach((p_228347_1_, p_228347_2_) -> this.tickParticleList(p_228347_2_));

		class_703 particle;
		if (queue.isEmpty())
			return;
		while ((particle = this.queue.poll()) != null)
			this.byType.computeIfAbsent(particle.method_18122(), $ -> EvictingQueue.create(16384))
				.add(particle);
	}

	private void tickParticleList(Collection<class_703> p_187240_1_) {
		if (p_187240_1_.isEmpty())
			return;

		Iterator<class_703> iterator = p_187240_1_.iterator();
		while (iterator.hasNext()) {
			class_703 particle = iterator.next();
			particle.method_3070();
			if (!particle.method_3086())
				iterator.remove();
		}
	}

	public void renderParticles(class_4587 ms, class_4597 buffer, class_4184 renderInfo, float pt) {
		class_310 mc = class_310.method_1551();
		class_765 lightTexture = mc.field_1773.method_22974();

		lightTexture.method_3316();
		RenderSystem.enableDepthTest();
		Matrix4fStack stack = RenderSystem.getModelViewStack();
		stack.pushMatrix();
		stack.mul(ms.method_23760().method_23761());
		RenderSystem.applyModelViewMatrix();

		for (class_3999 iparticlerendertype : this.byType.keySet()) {
			if (iparticlerendertype == class_3999.field_17832)
				continue;
			Iterable<class_703> iterable = this.byType.get(iparticlerendertype);
			if (iterable != null) {
				RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
				RenderSystem.setShader(class_757::method_34546);

				class_289 tesselator = class_289.method_1348();
				class_287 bufferBuilder = iparticlerendertype.method_18130(tesselator, mc.method_1531());

				if (bufferBuilder != null) {
					for (class_703 particle : iterable)
						particle.method_3074(bufferBuilder, renderInfo, pt);

					class_9801 meshData = bufferBuilder.method_60794();
					if (meshData != null)
						class_286.method_43433(meshData);
				}
			}
		}

		stack.popMatrix();
		RenderSystem.applyModelViewMatrix();
		RenderSystem.depthMask(true);
		RenderSystem.disableBlend();
		lightTexture.method_3315();
	}

	public void clearEffects() {
		this.byType.clear();
	}

}
