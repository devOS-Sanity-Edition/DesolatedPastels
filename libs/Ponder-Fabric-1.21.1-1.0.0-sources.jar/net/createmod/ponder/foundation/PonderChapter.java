package net.createmod.ponder.foundation;

import com.mojang.blaze3d.systems.RenderSystem;
import net.createmod.catnip.gui.element.ScreenElement;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import javax.annotation.Nonnull;

public class PonderChapter implements ScreenElement {

	private final class_2960 id;
	private final class_2960 icon;

	private PonderChapter(class_2960 id) {
		this.id = id;
		icon = class_2960.method_60655(id.method_12836(), "textures/ponder/chapter/" + id.method_12832() + ".png");
	}

	public class_2960 getId() {
		return id;
	}

	public String getTitle() {
		return "";
	}

	@Override
	public void render(class_332 graphics, int x, int y) {
		class_4587 ms = graphics.method_51448();
		ms.method_22903();
		RenderSystem.setShaderTexture(0, icon);
		ms.method_22905(0.25f, 0.25f, 1);
		//x and y offset, blit z offset, tex x and y, tex width and height, entire tex sheet width and height
		graphics.method_25291(icon, x, y, 0, 0, 0, 64, 64, 64, 64);
		ms.method_22909();
	}

	@Deprecated
	public static PonderChapter of(class_2960 id) {
		/*PonderChapter chapter = PonderRegistry.CHAPTERS.getChapter(id);
		if (chapter == null) {
			 chapter = PonderRegistry.CHAPTERS.addChapter(new PonderChapter(id));
		}

		return chapter;*/
		return null;
	}
}
