package net.createmod.ponder.foundation.instruction;

import net.createmod.ponder.foundation.PonderScene;
import net.minecraft.class_243;

public class MovePoiInstruction extends PonderInstruction {

	private class_243 poi;

	public MovePoiInstruction(class_243 poi) {
		this.poi = poi;
	}
	
	@Override
	public boolean isComplete() {
		return true;
	}

	@Override
	public void tick(PonderScene scene) {
		scene.setPointOfInterest(poi);
	}

}
