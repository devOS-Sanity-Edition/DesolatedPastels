package net.createmod.ponder.foundation.instruction;

import java.util.function.UnaryOperator;

import net.createmod.ponder.api.level.PonderLevel;
import net.createmod.ponder.api.scene.Selection;
import net.createmod.ponder.foundation.PonderScene;
import net.minecraft.class_2487;
import net.minecraft.class_2586;

public class BlockEntityDataInstruction extends WorldModifyInstruction {

	private boolean redraw;
	private UnaryOperator<class_2487> data;
	private Class<? extends class_2586> type;

	public BlockEntityDataInstruction(Selection selection, Class<? extends class_2586> type,
									  UnaryOperator<class_2487> data, boolean redraw) {
		super(selection);
		this.type = type;
		this.data = data;
		this.redraw = redraw;
	}

	@Override
	protected void runModification(Selection selection, PonderScene scene) {
		PonderLevel level = scene.getWorld();
		selection.forEach(pos -> {
			if (!level.getBounds()
					.method_14662(pos))
				return;
			class_2586 blockEntity = level.method_8321(pos);
			if (!type.isInstance(blockEntity))
				return;
			class_2487 apply = data.apply(blockEntity.method_38242(level.method_30349()));
			//if (blockEntity instanceof SyncedBlockEntity) //TODO
			//	((SyncedBlockEntity) blockEntity).readClient(apply);
			blockEntity.method_58690(apply, level.method_30349());
		});
	}

	@Override
	protected boolean needsRedraw() {
		return redraw;
	}

}
