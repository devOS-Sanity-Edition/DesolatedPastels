package net.createmod.ponder.foundation.instruction;

import net.createmod.ponder.api.element.ParrotElement;
import net.minecraft.class_2350;

public class CreateParrotInstruction extends FadeIntoSceneInstruction<ParrotElement> {

	public CreateParrotInstruction(int fadeInTicks, class_2350 fadeInFrom, ParrotElement element) {
		super(fadeInTicks, fadeInFrom, element);
	}

	@Override
	protected Class<ParrotElement> getElementClass() {
		return ParrotElement.class;
	}

}
