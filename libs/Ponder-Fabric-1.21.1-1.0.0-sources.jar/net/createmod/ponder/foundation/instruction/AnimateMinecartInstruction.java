package net.createmod.ponder.foundation.instruction;

import java.util.function.BiConsumer;
import java.util.function.Function;

import net.createmod.ponder.api.element.ElementLink;
import net.createmod.ponder.api.element.MinecartElement;
import net.minecraft.class_243;

public class AnimateMinecartInstruction extends AnimateElementInstruction<MinecartElement> {

	public static AnimateMinecartInstruction rotate(ElementLink<MinecartElement> link, float rotation, int ticks) {
		return new AnimateMinecartInstruction(link, new class_243(0, rotation, 0), ticks,
			(wse, v) -> wse.setRotation((float) v.field_1351, ticks == 0), MinecartElement::getRotation);
	}

	public static AnimateMinecartInstruction move(ElementLink<MinecartElement> link, class_243 offset, int ticks) {
		return new AnimateMinecartInstruction(link, offset, ticks, (wse, v) -> wse.setPositionOffset(v, ticks == 0),
			MinecartElement::getPositionOffset);
	}

	protected AnimateMinecartInstruction(ElementLink<MinecartElement> link, class_243 totalDelta, int ticks,
		BiConsumer<MinecartElement, class_243> setter, Function<MinecartElement, class_243> getter) {
		super(link, totalDelta, ticks, setter, getter);
	}

}
