package net.createmod.ponder.foundation.instruction;

import net.createmod.ponder.api.PonderPalette;
import net.createmod.ponder.foundation.PonderScene;
import net.minecraft.class_238;
import net.minecraft.class_243;

public class HighlightValueBoxInstruction extends TickingInstruction {

	private class_243 vec;
	private class_243 expands;

	public HighlightValueBoxInstruction(class_243 vec, class_243 expands, int duration) {
		super(false, duration);
		this.vec = vec;
		this.expands = expands;
	}

	@Override
	public void tick(PonderScene scene) {
		super.tick(scene);
		class_238 point = new class_238(vec, vec);
		class_238 expanded = point.method_1009(expands.field_1352, expands.field_1351, expands.field_1350);
		scene.getOutliner()
			.chaseAABB(vec, remainingTicks + 1 >= totalTicks ? point : expanded)
			.lineWidth(1 / 15f)
			.colored(PonderPalette.WHITE.getColor());
	}

}
