package net.createmod.ponder.foundation.instruction;

import java.util.function.BiConsumer;
import java.util.function.Function;

import net.createmod.ponder.api.element.ElementLink;
import net.createmod.ponder.api.element.WorldSectionElement;
import net.minecraft.class_243;

public class AnimateWorldSectionInstruction extends AnimateElementInstruction<WorldSectionElement> {

	public static AnimateWorldSectionInstruction rotate(ElementLink<WorldSectionElement> link, class_243 rotation,
		int ticks) {
		return new AnimateWorldSectionInstruction(link, rotation, ticks,
			(wse, v) -> wse.setAnimatedRotation(v, ticks == 0), WorldSectionElement::getAnimatedRotation);
	}

	public static AnimateWorldSectionInstruction move(ElementLink<WorldSectionElement> link, class_243 offset, int ticks) {
		return new AnimateWorldSectionInstruction(link, offset, ticks, (wse, v) -> wse.setAnimatedOffset(v, ticks == 0),
			WorldSectionElement::getAnimatedOffset);
	}

	protected AnimateWorldSectionInstruction(ElementLink<WorldSectionElement> link, class_243 totalDelta, int ticks,
		BiConsumer<WorldSectionElement, class_243> setter, Function<WorldSectionElement, class_243> getter) {
		super(link, totalDelta, ticks, setter, getter);
	}

}
