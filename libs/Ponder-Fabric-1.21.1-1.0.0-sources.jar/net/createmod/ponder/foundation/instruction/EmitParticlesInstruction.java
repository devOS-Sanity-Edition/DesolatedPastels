package net.createmod.ponder.foundation.instruction;

import net.createmod.ponder.Ponder;
import net.createmod.ponder.api.ParticleEmitter;
import net.createmod.ponder.foundation.PonderScene;
import net.minecraft.class_243;

public class EmitParticlesInstruction extends TickingInstruction {

	private class_243 anchor;
	private ParticleEmitter emitter;
	private float runsPerTick;

	public EmitParticlesInstruction(class_243 anchor, ParticleEmitter emitter, float runsPerTick, int ticks) {
		super(false, ticks);
		this.anchor = anchor;
		this.emitter = emitter;
		this.runsPerTick = runsPerTick;
	}

	@Override
	public void tick(PonderScene scene) {
		super.tick(scene);
		int runs = (int) runsPerTick;
		if (Ponder.RANDOM.nextFloat() < (runsPerTick - runs))
			runs++;
		for (int i = 0; i < runs; i++)
			emitter.create(scene.getWorld(), anchor.field_1352, anchor.field_1351, anchor.field_1350);
	}

}
