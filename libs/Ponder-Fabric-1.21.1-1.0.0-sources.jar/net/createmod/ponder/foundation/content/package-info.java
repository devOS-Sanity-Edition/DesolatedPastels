@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package net.createmod.ponder.foundation.content;

import javax.annotation.ParametersAreNonnullByDefault;