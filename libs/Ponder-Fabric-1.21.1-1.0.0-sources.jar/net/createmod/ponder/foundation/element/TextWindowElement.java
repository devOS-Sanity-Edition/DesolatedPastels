package net.createmod.ponder.foundation.element;

import java.util.List;
import java.util.function.Supplier;

import javax.annotation.Nullable;
import net.createmod.catnip.gui.element.BoxElement;
import net.createmod.catnip.data.Couple;
import net.createmod.catnip.theme.Color;
import net.createmod.ponder.api.PonderPalette;
import net.createmod.ponder.api.element.TextElementBuilder;
import net.createmod.ponder.foundation.PonderIndex;
import net.createmod.ponder.foundation.PonderScene;
import net.createmod.ponder.foundation.PonderScene.SceneTransform;
import net.createmod.ponder.foundation.ui.PonderUI;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_5348;

public class TextWindowElement extends AnimatedOverlayElementBase {

	public static final Couple<Color> COLOR_WINDOW_BORDER = Couple.create(
		new Color(0x607a6000, true),
		new Color(0x207a6000, true)
	).map(Color::setImmutable);

	Supplier<String> textGetter = () -> "(?) No text was provided";
	@Nullable String bakedText;

	// from 0 to 200
	int y;

	@Nullable class_243 vec;

	boolean nearScene = false;
	PonderPalette palette = PonderPalette.WHITE;

	public TextElementBuilder builder(PonderScene scene) {
		return new Builder(scene);
	}

	private class Builder implements TextElementBuilder {

		private final PonderScene scene;

		public Builder(PonderScene scene) {
			this.scene = scene;
		}

		@Override
		public Builder colored(PonderPalette color) {
			TextWindowElement.this.palette = color;
			return this;
		}

		@Override
		public Builder pointAt(class_243 vec) {
			TextWindowElement.this.vec = vec;
			return this;
		}

		@Override
		public Builder independent(int y) {
			TextWindowElement.this.y = y;
			return this;
		}

		@Override
		public Builder text(String defaultText) {
			textGetter = scene.registerText(defaultText);
			return this;
		}

		@Override
		public Builder sharedText(class_2960 key) {
			textGetter = () -> PonderIndex.getLangAccess().getShared(key);
			return this;
		}

		@Override
		public Builder sharedText(String key) {
			return sharedText(class_2960.method_60655(scene.getNamespace(), key));
		}

		@Override
		public Builder placeNearTarget() {
			TextWindowElement.this.nearScene = true;
			return this;
		}

		@Override
		public Builder attachKeyFrame() {
			scene.builder()
				.addLazyKeyframe();
			return this;
		}
	}

	@Override
	public void render(PonderScene scene, PonderUI screen, class_332 graphics, float partialTicks, float fade) {
		if (bakedText == null)
			bakedText = textGetter.get();

        if (fade < 1 / 16f)
			return;
		SceneTransform transform = scene.getTransform();
		class_241 sceneToScreen = vec != null ? transform.sceneToScreen(vec, partialTicks)
				: new class_241(screen.field_22789 / 2f, (screen.field_22790 - 200) / 2f + y - 8);

		boolean settled = transform.xRotation.settled() && transform.yRotation.settled();
		float pY = settled ? (int) sceneToScreen.field_1342 : sceneToScreen.field_1342;

		float yDiff = (screen.field_22790 / 2f - sceneToScreen.field_1342 - 10) / 100f;
		float targetX = (screen.field_22789 * class_3532.method_16439(yDiff * yDiff, 6f / 8, 5f / 8));

		if (nearScene)
			targetX = Math.min(targetX, sceneToScreen.field_1343 + 50);

		if (settled)
			targetX = (int) targetX;

		int textWidth = (int) Math.min(screen.field_22789 - targetX, 180);

		List<class_5348> lines = screen.getFontRenderer()
				.method_27527()
				.method_27498(bakedText, textWidth, class_2583.field_24360);

		int boxWidth = 0;
		for (class_5348 line : lines)
			boxWidth = Math.max(boxWidth, screen.getFontRenderer()
					.method_27525(line));

		int boxHeight = screen.getFontRenderer()
				.method_1713(bakedText, boxWidth);

		class_4587 poseStack = graphics.method_51448();
		poseStack.method_22903();
		poseStack.method_46416(0, pY, 400);

		new BoxElement()
				.withBackground(PonderUI.BACKGROUND_FLAT)
				.gradientBorder(COLOR_WINDOW_BORDER)
				.at(targetX - 10, 3, -101)
				.withBounds(boxWidth, boxHeight - 1)
				.render(graphics);

		Color brighter = palette.getColorObject().mixWith(new Color(0xff_ffffdd), 0.5f).setImmutable();
		Color c1 = new Color(0xff_494949);
		Color c2 = new Color(0xff_393939);
		if (vec != null) {
			poseStack.method_22903();
			poseStack.method_46416(sceneToScreen.field_1343, 0, 0);
			double lineTarget = (targetX - sceneToScreen.field_1343) * fade;
			poseStack.method_22905((float) lineTarget, 1, 1);
			graphics.method_33284(0, 0, 1, 1, -100, brighter.getRGB(), brighter.getRGB());
			graphics.method_33284(0, 1, 1, 2, -100, c1.getRGB(), c2.getRGB());
			poseStack.method_22909();
		}

		poseStack.method_46416(0, 0, 400);
		for (int i = 0; i < lines.size(); i++) {
			graphics.method_51433(screen.getFontRenderer(), lines.get(i).getString(), (int) (targetX - 10), 3 + 9 * i, brighter.scaleAlphaForText(fade).getRGB(), false);
		}
		poseStack.method_22909();
	}

	public PonderPalette getPalette() {
		return palette;
	}

}
