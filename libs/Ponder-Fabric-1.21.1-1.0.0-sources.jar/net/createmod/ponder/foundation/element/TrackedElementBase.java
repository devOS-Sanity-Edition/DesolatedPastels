package net.createmod.ponder.foundation.element;

import java.lang.ref.WeakReference;
import java.util.function.Consumer;

import net.createmod.ponder.api.element.TrackedElement;
import net.createmod.ponder.api.level.PonderLevel;
import net.minecraft.class_1921;
import net.minecraft.class_332;
import net.minecraft.class_4597;

public abstract class TrackedElementBase<T> extends PonderElementBase implements TrackedElement<T> {

	private final WeakReference<T> reference;

	public TrackedElementBase(T wrapped) {
		this.reference = new WeakReference<>(wrapped);
	}

	@Override
	public void ifPresent(Consumer<T> func) {
		T resolved = reference.get();
		if (resolved == null)
			return;
		func.accept(resolved);
	}

	@Override
	public void renderFirst(PonderLevel world, class_4597 buffer, class_332 graphics, float pt) {}

	@Override
	public void renderLayer(PonderLevel world, class_4597 buffer, class_1921 type, class_332 graphics, float pt) {}

	@Override
	public void renderLast(PonderLevel world, class_4597 buffer, class_332 graphics, float pt) {}

}
