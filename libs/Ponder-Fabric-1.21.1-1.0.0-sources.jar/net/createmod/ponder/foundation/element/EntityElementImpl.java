package net.createmod.ponder.foundation.element;

import net.createmod.ponder.api.element.EntityElement;
import net.minecraft.class_1297;

public class EntityElementImpl extends TrackedElementBase<class_1297> implements EntityElement {

	public EntityElementImpl(class_1297 wrapped) {
		super(wrapped);
	}

	@Override
	public boolean isStillValid(class_1297 element) {
		return element.method_5805();
	}

}
