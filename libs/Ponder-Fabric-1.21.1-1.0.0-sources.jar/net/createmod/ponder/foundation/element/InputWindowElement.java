package net.createmod.ponder.foundation.element;

import javax.annotation.Nullable;

import com.mojang.blaze3d.systems.RenderSystem;
import net.createmod.catnip.gui.element.GuiGameElement;
import net.createmod.catnip.gui.element.ScreenElement;
import net.createmod.catnip.math.Pointing;
import net.createmod.ponder.Ponder;
import net.createmod.ponder.api.PonderPalette;
import net.createmod.ponder.api.element.InputElementBuilder;
import net.createmod.ponder.enums.PonderGuiTextures;
import net.createmod.ponder.foundation.PonderIndex;
import net.createmod.ponder.foundation.PonderScene;
import net.createmod.ponder.foundation.ui.PonderUI;
import net.minecraft.class_1799;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public class InputWindowElement extends AnimatedOverlayElementBase {

	private final class_243 sceneSpace;
	private final Pointing direction;
	@Nullable class_2960 key;
	@Nullable ScreenElement icon;
	class_1799 item = class_1799.field_8037;

	public InputWindowElement(class_243 sceneSpace, Pointing direction) {
		this.sceneSpace = sceneSpace;
		this.direction = direction;
	}

	public InputElementBuilder builder() {
		return new Builder();
	}

	private class Builder implements InputElementBuilder {

		@Override
		public InputElementBuilder withItem(class_1799 stack) {
			item = stack;
			return this;
		}

		@Override
		public InputElementBuilder leftClick() {
			icon = PonderGuiTextures.ICON_LMB;
			return this;
		}

		@Override
		public InputElementBuilder scroll() {
			icon = PonderGuiTextures.ICON_SCROLL;
			return this;
		}

		@Override
		public InputElementBuilder rightClick() {
			icon = PonderGuiTextures.ICON_RMB;
			return this;
		}

		@Override
		public InputElementBuilder showing(ScreenElement icon) {
			InputWindowElement.this.icon = icon;
			return this;
		}

		@Override
		public InputElementBuilder whileSneaking() {
			key = Ponder.asResource("sneak_and");
			return this;
		}

		@Override
		public InputElementBuilder whileCTRL() {
			key = Ponder.asResource("ctrl_and");
			return this;
		}

	}

	@Override
	public void render(PonderScene scene, PonderUI screen, class_332 graphics, float partialTicks, float fade) {
		class_327 font = screen.getFontRenderer();
		int width = 0;
		int height = 0;

		float xFade = direction == Pointing.RIGHT ? -1 : direction == Pointing.LEFT ? 1 : 0;
		float yFade = direction == Pointing.DOWN ? -1 : direction == Pointing.UP ? 1 : 0;
		xFade *= 10 * (1 - fade);
		yFade *= 10 * (1 - fade);

		boolean hasItem = !item.method_7960();
		boolean hasText = key != null;
		boolean hasIcon = icon != null;
		int keyWidth = 0;
		String text = hasText ? PonderIndex.getLangAccess().getShared(key) : "";

		if (fade < 1 / 16f)
			return;
		class_241 sceneToScreen = scene.getTransform()
			.sceneToScreen(sceneSpace, partialTicks);

		if (hasIcon) {
			width += 24;
			height = 24;
		}

		if (hasText) {
			keyWidth = font.method_1727(text);
			width += keyWidth;
		}

		if (hasItem) {
			width += 24;
			height = 24;
		}

		class_4587 poseStack = graphics.method_51448();
		poseStack.method_22903();
		poseStack.method_46416(sceneToScreen.field_1343 + xFade, sceneToScreen.field_1342 + yFade, 400);

		PonderUI.renderSpeechBox(graphics, 0, 0, width, height, false, direction, true);

		poseStack.method_46416(0, 0, 100);

		if (hasText)
			graphics.method_51433(font, text, 2, (int) ((height - font.field_2000) / 2f + 2),
								PonderPalette.WHITE.getColorObject().scaleAlpha(fade).getRGB(), false);

		if (hasIcon) {
			poseStack.method_22903();
			poseStack.method_46416(keyWidth, 0, 0);
			poseStack.method_22905(1.5f, 1.5f, 1.5f);
			icon.render(graphics, 0, 0);
			poseStack.method_22909();
		}

		if (hasItem) {
			GuiGameElement.of(item)
				.<GuiGameElement.GuiRenderBuilder>at(keyWidth + (hasIcon ? 24 : 0), 0)
				.scale(1.5)
				.render(graphics);
			RenderSystem.disableDepthTest();
		}

		poseStack.method_22909();
	}

}
