package net.createmod.ponder.foundation.element;

import net.createmod.catnip.animation.LerpedFloat;
import net.createmod.ponder.api.element.AnimatedSceneElement;
import net.createmod.ponder.api.level.PonderLevel;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_765;

public abstract class AnimatedSceneElementBase extends PonderElementBase implements AnimatedSceneElement {

	protected class_243 fadeVec;
	protected LerpedFloat fade;

	public AnimatedSceneElementBase() {
		fade = LerpedFloat.linear()
			.startWithValue(0);
	}

	@Override
	public void forceApplyFade(float fade) {
		this.fade.startWithValue(fade);
	}

	@Override
	public void setFade(float fade) {
		this.fade.setValue(fade);
	}

	@Override
	public void setFadeVec(class_243 fadeVec) {
		this.fadeVec = fadeVec;
	}

	@Override
	public final void renderFirst(PonderLevel world, class_4597 buffer, class_332 graphics, float pt) {
		class_4587 poseStack = graphics.method_51448();
		poseStack.method_22903();
		float currentFade = applyFade(poseStack, pt);
		renderFirst(world, buffer, graphics, currentFade, pt);
		poseStack.method_22909();
	}

	@Override
	public final void renderLayer(PonderLevel world, class_4597 buffer, class_1921 type, class_332 graphics,
								  float pt) {
		class_4587 poseStack = graphics.method_51448();
		poseStack.method_22903();
		float currentFade = applyFade(poseStack, pt);
		renderLayer(world, buffer, type, graphics, currentFade, pt);
		poseStack.method_22909();
	}

	@Override
	public final void renderLast(PonderLevel world, class_4597 buffer, class_332 graphics, float pt) {
		class_4587 poseStack = graphics.method_51448();
		poseStack.method_22903();
		float currentFade = applyFade(poseStack, pt);
		renderLast(world, buffer, graphics, currentFade, pt);
		poseStack.method_22909();
	}

	protected float applyFade(class_4587 ms, float pt) {
		float currentFade = fade.getValue(pt);
		if (fadeVec != null) {
			class_243 scaled = fadeVec.method_1021(-1 + currentFade);
			ms.method_22904(scaled.field_1352, scaled.field_1351, scaled.field_1350);
		}

		return currentFade;
	}

	protected void renderLayer(PonderLevel world, class_4597 buffer, class_1921 type, class_332 graphics, float fade,
							   float pt) {}

	protected void renderFirst(PonderLevel world, class_4597 buffer, class_332 graphics, float fade, float pt) {}

	protected void renderLast(PonderLevel world, class_4597 buffer, class_332 graphics, float fade, float pt) {}

	protected int lightCoordsFromFade(float fade) {
		int light = class_765.field_32767;
		if (fade != 1) {
			light = (int) (class_3532.method_16439(fade, 5, 0xF));
			light = class_765.method_23687(light, light);
		}
		return light;
	}

}
