package net.createmod.ponder.foundation.registration;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;

import net.createmod.catnip.data.Couple;
import net.createmod.ponder.Ponder;
import net.createmod.ponder.api.registration.LangRegistryAccess;
import net.createmod.ponder.foundation.PonderIndex;
import net.createmod.ponder.foundation.PonderTooltipHandler;
import net.createmod.ponder.foundation.ui.AbstractPonderScreen;
import net.minecraft.class_1074;
import net.minecraft.class_2960;

public class PonderLocalization implements LangRegistryAccess {

	public static final String LANG_PREFIX = "ponder.";
	public static final String UI_PREFIX = "ui.";

	public final Map<class_2960, String> shared = new HashMap<>();
	public final Map<class_2960, Couple<String>> tag = new HashMap<>();
	public final Map<class_2960, Map<String, String>> specific = new HashMap<>();

	//

	public void clearAll() {
		shared.clear();
		tag.clear();
		specific.clear();
	}

	public void clearShared() {
		shared.clear();
	}

	public void registerShared(class_2960 key, String enUS) {
		shared.put(key, enUS);
	}

	public void registerTag(class_2960 key, String title, String description) {
		tag.put(key, Couple.create(title, description));
	}

	public void registerSpecific(class_2960 sceneId, String key, String enUS) {
		specific.computeIfAbsent(sceneId, $ -> new HashMap<>())
				.put(key, enUS);
	}

	//

	protected static String langKeyForShared(class_2960 k) {
		return k.method_12836() + "." + LANG_PREFIX + "shared." + k.method_12832();
	}

	protected static String langKeyForTag(class_2960 k) {
		return k.method_12836() + "." + LANG_PREFIX + "tag." + k.method_12832();
	}

	protected static String langKeyForTagDescription(class_2960 k) {
		return k.method_12836() + "." + LANG_PREFIX + "tag." + k.method_12832() + ".description";
	}

	protected static String langKeyForSpecific(class_2960 sceneId, String k) {
		return sceneId.method_12836() + "." + LANG_PREFIX + sceneId.method_12832() + "." + k;
	}

	//

	@Override
	public String getShared(class_2960 key) {
		if (PonderIndex.editingModeActive())
			return shared.containsKey(key) ? shared.get(key) : ("unregistered shared entry: " + key);
		return class_1074.method_4662(langKeyForShared(key));
	}

	@Override
	public String getTagName(class_2960 key) {
		if (PonderIndex.editingModeActive())
			return tag.containsKey(key) ? tag.get(key)
					.getFirst() : ("unregistered tag entry: " + key);
		return class_1074.method_4662(langKeyForTag(key));
	}

	@Override
	public String getTagDescription(class_2960 key) {
		if (PonderIndex.editingModeActive())
			return tag.containsKey(key) ? tag.get(key)
					.getSecond() : ("unregistered tag entry: " + key);
		return class_1074.method_4662(langKeyForTagDescription(key));
	}

	@Override
	public String getSpecific(class_2960 sceneId, String k) {
		if (PonderIndex.editingModeActive())
			try {
				return specific.get(sceneId).get(k);
			} catch (Exception e) {
				return "MISSING_SPECIFIC";
			}
		return class_1074.method_4662(langKeyForSpecific(sceneId, k));
	}

	//

	private void recordGeneral(BiConsumer<String, String> consumer) {
		addGeneral(consumer, PonderTooltipHandler.HOLD_TO_PONDER, "Hold [%1$s] to Ponder");
		addGeneral(consumer, PonderTooltipHandler.SUBJECT, "Subject of this scene");
		addGeneral(consumer, AbstractPonderScreen.PONDERING, "Pondering about...");
		addGeneral(consumer, AbstractPonderScreen.IDENTIFY_MODE, "Identify mode active.\nUnpause with [%1$s]");
		addGeneral(consumer, AbstractPonderScreen.ASSOCIATED, "Associated Entries");

		addGeneral(consumer, AbstractPonderScreen.CLOSE, "Close");
		addGeneral(consumer, AbstractPonderScreen.IDENTIFY, "Identify");
		addGeneral(consumer, AbstractPonderScreen.NEXT, "Next Scene");
		addGeneral(consumer, AbstractPonderScreen.NEXT_UP, "Up Next:");
		addGeneral(consumer, AbstractPonderScreen.PREVIOUS, "Previous Scene");
		addGeneral(consumer, AbstractPonderScreen.REPLAY, "Replay");
		addGeneral(consumer, AbstractPonderScreen.THINK_BACK, "Think Back");
		addGeneral(consumer, AbstractPonderScreen.SLOW_TEXT, "Comfy Reading");

		addGeneral(consumer, AbstractPonderScreen.EXIT, "Exit");
		addGeneral(consumer, AbstractPonderScreen.WELCOME, "Welcome to Ponder");
		addGeneral(consumer, AbstractPonderScreen.CATEGORIES, "Available Categories for %1$s");
		addGeneral(consumer, AbstractPonderScreen.DESCRIPTION, "Click one of the icons below to learn about its associated Items and Blocks");
		addGeneral(consumer, AbstractPonderScreen.INDEX_TITLE, "Ponder Index");
	}

	private void addGeneral(BiConsumer<String, String> consumer, String key, String enUS) {
		consumer.accept(Ponder.MOD_ID + "." + key, enUS);
	}

	public void generateSceneLang() {
		PonderIndex.getSceneAccess()
				.getRegisteredEntries()
				.forEach(entry -> PonderSceneRegistry.compileScene(this, entry.getValue(), null));
	}

	@Override
	public void provideLang(String modId, BiConsumer<String, String> consumer) {
		PonderIndex.registerAll();
		PonderIndex.gatherSharedText();

		generateSceneLang();

		if (modId.equals(Ponder.MOD_ID))
			recordGeneral(consumer);

		shared.forEach((k, v) -> {
			if (k.method_12836().equals(modId)) {
				consumer.accept(langKeyForShared(k), v);
			}
		});

		tag.forEach((k, v) -> {
			if (k.method_12836().equals(modId)) {
				consumer.accept(langKeyForTag(k), v.getFirst());
				consumer.accept(langKeyForTagDescription(k), v.getSecond());
			}
		});

		specific.entrySet()
				.stream()
				.filter(entry -> entry.getKey().method_12836().equals(modId))
				.sorted(Map.Entry.comparingByKey())
				.forEach(entry -> {
					entry.getValue()
							.entrySet()
							.stream()
							.sorted(Map.Entry.comparingByKey())
							.forEach(subEntry -> consumer.accept(
									langKeyForSpecific(entry.getKey(), subEntry.getKey()), subEntry.getValue()));
				});
	}
}
