package net.createmod.ponder.foundation.registration;

import java.util.function.Predicate;
import java.util.stream.Stream;

import net.createmod.ponder.api.registration.IndexExclusionHelper;
import net.createmod.ponder.api.registration.PonderPlugin;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1935;
import net.minecraft.class_2248;

public class PonderIndexExclusionHelper implements IndexExclusionHelper {

	private final Stream.Builder<Predicate<class_1935>> exclusions = Stream.builder();

	public static Stream<Predicate<class_1935>> pluginToExclusions(PonderPlugin plugin) {
		PonderIndexExclusionHelper helper = new PonderIndexExclusionHelper();
		plugin.indexExclusions(helper);
		return helper.getExclusions();
	}

	public Stream<Predicate<class_1935>> getExclusions() {
		return exclusions.build();
	}

	@Override
	public IndexExclusionHelper exclude(class_1935 item) {
		exclusions.add(itemLike -> itemLike.method_8389() == item.method_8389());
		return this;
	}

	@Override
	public IndexExclusionHelper excludeItemVariants(Class<? extends class_1792> itemClazz, class_1792 originalVariant) {
		exclusions.add(itemLike -> {
			if (!(itemClazz.isInstance(itemLike)))
				return false;

			return itemLike.method_8389() != originalVariant.method_8389();
		});
		return this;
	}

	@Override
	public IndexExclusionHelper excludeBlockVariants(Class<? extends class_2248> blockClazz, class_2248 originalVariant) {
		exclusions.add(itemLike -> {
			if (!(itemLike instanceof class_1747 blockItem))
				return false;

			class_2248 block = blockItem.method_7711();
			if (!(blockClazz.isInstance(block)))
				return false;

			return block.method_8389() != originalVariant.method_8389();
		});
		return this;
	}

	@Override
	public IndexExclusionHelper exclude(Predicate<class_1935> predicate) {
		exclusions.add(predicate);
		return this;
	}
}
