@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package net.createmod.ponder.foundation.registration;

import javax.annotation.ParametersAreNonnullByDefault;
