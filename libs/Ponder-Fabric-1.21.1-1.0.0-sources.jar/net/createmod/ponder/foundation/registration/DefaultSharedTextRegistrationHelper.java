package net.createmod.ponder.foundation.registration;

import net.createmod.ponder.api.registration.SharedTextRegistrationHelper;
import net.minecraft.class_2960;

public class DefaultSharedTextRegistrationHelper implements SharedTextRegistrationHelper {

	private final String namespace;
	private final PonderLocalization localization;

	public DefaultSharedTextRegistrationHelper(String namespace, PonderLocalization localization) {
		this.namespace = namespace;
		this.localization = localization;
	}

	@Override
	public void registerSharedText(String key, String en_us) {
		localization.registerShared(class_2960.method_60655(namespace, key), en_us);
	}
}
