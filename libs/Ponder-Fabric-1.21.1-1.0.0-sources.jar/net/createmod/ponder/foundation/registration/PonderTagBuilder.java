package net.createmod.ponder.foundation.registration;

import java.util.function.Consumer;

import javax.annotation.Nullable;

import net.createmod.ponder.api.registration.TagBuilder;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2960;

public class PonderTagBuilder implements TagBuilder {

	final class_2960 id;
	private final Consumer<PonderTagBuilder> onFinish;

	String title = "NO_TITLE";
	String description = "NO_DESCRIPTION";
	boolean addToIndex = false;
	@Nullable class_2960 textureIconLocation;
	class_1799 itemIcon = class_1799.field_8037;
	class_1799 mainItem = class_1799.field_8037;

	public PonderTagBuilder(class_2960 id, Consumer<PonderTagBuilder> onFinish) {
		this.id = id;
		this.onFinish = onFinish;
	}

	@Override
	public TagBuilder title(String title) {
		this.title = title;
		return this;
	}

	@Override
	public TagBuilder description(String description) {
		this.description = description;
		return this;
	}

	@Override
	public TagBuilder addToIndex() {
		this.addToIndex = true;
		return this;
	}

	@Override
	public TagBuilder icon(class_2960 location) {
		this.textureIconLocation = class_2960.method_60655(location.method_12836(), "textures/ponder/tag/" + location.method_12832() + ".png");
		return this;
	}

	@Override
	public TagBuilder icon(String path) {
		this.textureIconLocation = class_2960.method_60655(id.method_12836(), "textures/ponder/tag/" + path + ".png");
		return this;
	}

	@Override
	public TagBuilder idAsIcon() {
		return icon(id);
	}

	@Override
	public TagBuilder item(class_1935 item, boolean useAsIcon, boolean useAsMainItem) {
		if (useAsIcon)
			this.itemIcon = new class_1799(item);
		if (useAsMainItem)
			this.mainItem = new class_1799(item);
		return this;
	}

	@Override
	public void register() {
		onFinish.accept(this);
	}
}
