package net.createmod.ponder.foundation;

import net.createmod.catnip.gui.element.GuiGameElement;
import net.createmod.catnip.gui.element.ScreenElement;
import net.createmod.ponder.Ponder;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import javax.annotation.Nullable;

public class PonderTag implements ScreenElement {

	/**
	 * Highlight.ALL is a special PonderTag, used to indicate that all Tags
	 * for a certain Scene should be highlighted instead of selected single ones
	 */
	public static final class Highlight {
		public static final class_2960 ALL = Ponder.asResource("_all");
	}

	private final class_2960 id;
	@Nullable private final class_2960 textureIconLocation;
	private final class_1799 itemIcon;
	private final class_1799 mainItem;


	public PonderTag(class_2960 id, @Nullable class_2960 textureIconLocation, class_1799 itemIcon,
					 class_1799 mainItem) {
		this.id = id;
		this.textureIconLocation = textureIconLocation;
		this.itemIcon = itemIcon;
		this.mainItem = mainItem;
	}

	public class_2960 getId() {
		return id;
	}

	public class_1799 getMainItem() {
		return mainItem;
	}

	public String getTitle() {
		return PonderIndex.getLangAccess().getTagName(id);
	}

	public String getDescription() {
		return PonderIndex.getLangAccess().getTagDescription(id);
	}

	public void render(class_332 graphics, int x, int y) {
		class_4587 poseStack = graphics.method_51448();
		poseStack.method_22903();
		poseStack.method_46416(x, y, 0);
		if (textureIconLocation != null) {
			//RenderSystem.setShaderTexture(0, icon);
			poseStack.method_22905(0.25f, 0.25f, 1);
			graphics.method_25291(textureIconLocation, 0, 0, 0, 0, 0, 64, 64, 64, 64);
		} else if (!itemIcon.method_7960()) {
			poseStack.method_46416(-2, -2, 0);
			poseStack.method_22905(1.25f, 1.25f, 1.25f);
			GuiGameElement.of(itemIcon)
				.render(graphics);
		}
		poseStack.method_22909();
	}

	@Override
	public boolean equals(Object other) {
		if (this == other)
			return true;

		if (!(other instanceof PonderTag otherTag))
			return false;

		return getId().equals(otherTag.getId());
	}
}
