@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package net.createmod.ponder.foundation;

import javax.annotation.ParametersAreNonnullByDefault;