package net.createmod.ponder.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.tree.CommandNode;
import net.minecraft.class_2168;

public class PonderCommands {

	public static void register(CommandDispatcher<class_2168> dispatcher) {
		CommandNode<class_2168> ponderRoot = PonderCommand.register().build();

		dispatcher.getRoot().addChild(ponderRoot);
	}

}
