package net.createmod.ponder.command;

import java.util.Collection;

import com.google.common.collect.ImmutableList;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.ArgumentBuilder;

import net.createmod.catnip.net.packets.ClientboundSimpleActionPacket;
import net.createmod.catnip.platform.CatnipServices;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2232;
import net.minecraft.class_3222;

public class PonderCommand {
	//public static final SuggestionProvider<CommandSourceStack> ITEM_PONDERS = SuggestionProviders.register(new ResourceLocation("all_ponders"), (iSuggestionProviderCommandContext, builder) -> SharedSuggestionProvider.suggestResource(PonderRegistry.ALL.keySet().stream(), builder));
	//TODO PonderRegistry can't be loaded on Server Dist

	static ArgumentBuilder<class_2168, ?> register() {
		return class_2170.method_9247("ponder")
				.requires(cs -> cs.method_9259(0))
				.executes(ctx -> openScene("ponder:tags", ctx.getSource().method_9207()))
				.then(class_2170.method_9247("reload")
							  .executes(ctx -> reloadPonderIndex(ctx.getSource().method_9207()))
				)
				.then(class_2170.method_9247("index")
							  .executes(ctx -> openScene("ponder:index", ctx.getSource().method_9207()))
				)
				.then(class_2170.method_9247("tags")
							  .executes(ctx -> openScene("ponder:tags", ctx.getSource().method_9207()))
				)
				.then(class_2170.method_9244("scene", class_2232.method_9441())
							  //.suggests(ITEM_PONDERS)
							  .executes(ctx -> openScene(class_2232.method_9443(ctx, "scene").toString(),
														 ctx.getSource().method_9207()))
							  .then(class_2170.method_9244("targets", class_2186.method_9308())
											.requires(cs -> cs.method_9259(2))
											.executes(ctx -> openScene(
													class_2232.method_9443(ctx, "scene").toString(),
													class_2186.method_9312(ctx, "targets")))
							  )
				);

	}

	private static int openScene(String sceneId, class_3222 player) {
		return openScene(sceneId, ImmutableList.of(player));
	}

	private static int openScene(String sceneId, Collection<? extends class_3222> players) {
		for (class_3222 player : players) {
			if (CatnipServices.HOOKS.isPlayerFake(player))
				continue;

			CatnipServices.NETWORK.sendToClient(
					player,
					new ClientboundSimpleActionPacket("openPonder", sceneId)
			);
		}
		return Command.SINGLE_SUCCESS;
	}

	private static int reloadPonderIndex(class_3222 player) {
		CatnipServices.NETWORK.simpleActionToClient(player, "reloadPonder", "");

		return Command.SINGLE_SUCCESS;
	}
}
